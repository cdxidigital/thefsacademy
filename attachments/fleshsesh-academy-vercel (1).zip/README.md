# fleshsesh academy — Vercel edition

This is the complete source export of the Academy, adapted for Vercel with native Next.js, Clerk sign-in and a durable Turso/libSQL database. It includes the curriculum, all learning APIs, the three tutor roles, isolated Plus demo, branding, original artwork and finished promotional video.

**Start with [DEPLOY_TO_VERCEL.md](DEPLOY_TO_VERCEL.md).** You can upload the ZIP at [Vercel Drop](https://vercel.com/drop). Vercel installs the locked dependencies and builds the application.

## What is ready

- Landing page, eCampus background, supplied brand assets and responsive layouts.
- New 25-second 1080p silent promo, autoplay once per browser-tab session when the adult-entry and motion settings allow it, with manual replay.
- Curriculum edition 1.1: 18 modules, 48 written lessons, fictional practice, knowledge checks and progress.
- Foundations Tutor, Practice Coach and Assessment Tutor with their distinct curriculum-guide behaviour and assessment boundaries.
- Native Next.js API routes, server-side learner ownership checks, XP, module assessment records and non-accredited completion certificates.
- Private two-hour Plus demonstration at `/demo`, including reset, exit and a visibly invalid sample certificate.
- Subscription, one-off purchase and optional AI integration code. These retain the pilot/release settings from the source application.

## Services you configure

| Service | Purpose | Required configuration |
| --- | --- | --- |
| Vercel | Host the application and video | Import this project; framework Next.js; Node.js 24.x |
| Clerk | Verified sign-in and sign-up | `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY` |
| Turso | Durable learner records, demo, progress and entitlements | `TURSO_DATABASE_URL`, `TURSO_AUTH_TOKEN`; run the supplied migrations |
| Stripe, optional | Real recurring and one-off payments | Reviewed price IDs, server keys, webhook configuration and existing release switches |
| OpenAI, optional | Generative replies for eligible opted-in learners | Server key, chosen model and existing AI release switch |

The public application builds without service credentials. **Sign-in, saved learning and the demo need Clerk and a migrated database.** Missing configuration does not grant a fake account or silently save records in temporary function storage. Tutors remain in clearly labelled curriculum-guide mode until the optional AI integration is configured; the demo never incurs external AI charges.

The ZIP contains application code and empty environment-variable examples. It does not contain existing learner records, accounts, subscriptions, payment details, API keys or live database exports. Existing ChatGPT Sites identities do not automatically become Clerk accounts. If continuing an existing production service, plan and verify an explicit account/data migration before moving its domain or accepting payments on the new deployment.

## Local commands

Use Node.js 24.x. Install dependencies with the supplied lockfile:

```sh
npm ci
cp .env.example .env.local
```

Add your own development Clerk and Turso values to `.env.local`, then:

```sh
npm run db:migrate
npm run dev
```

For the verification suite and production build:

```sh
npm test
npm run typecheck
npm run build
```

`npm start` serves a completed production build. `npm run db:migrate` is an explicit database operation: it does not run during install, build or normal page requests. Use a separate database for preview/test deployments.

## Project contents

| Folder/file | Contents |
| --- | --- |
| `app/` | Next.js pages, verified auth routes and API handlers |
| `components/academy/` | Academy interface and animations |
| `lib/server/`, `db/` | Learning services, storage adapter, billing and tutor logic |
| `data/` | Version 1.1 curriculum, assessments and source references; assessment answers are server-side |
| `drizzle/` | Database migrations and schema history |
| `public/` | Deployed logos, fonts, images, poster and video assets |
| `design/` | Original image and film source assets; not needed in the deployed function |
| `tests/` | Automated regressions, including Vercel auth/storage coverage |
| `docs/VERCEL_EXPORT_VERIFICATION.md` | Verification performed for this export and its limits |
| `docs/` | Curriculum, release, brand, demo and media documentation |
| `.env.example` | Variable names and safe defaults only |
| `vercel.json` | Vercel's Next.js build/install configuration |

The historical Sites release documents are retained for traceability. Where hosting or sign-in instructions differ, this README and `DEPLOY_TO_VERCEL.md` describe this export. This package has not itself been published to your Vercel account.

## Education and release status

This remains non-accredited adult education for people aged 18 or over. Packaging for another host does not constitute clinical, legal or specialist approval of the curriculum. Real payment processing and generative AI keep their existing opt-in/release requirements; no approval flag has been enabled by this export.

