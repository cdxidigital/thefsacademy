import Link from "next/link";
import type { ReactNode } from "react";

export function AuthShell({ title, description, children }: { title: string; description: string; children: ReactNode }) {
  return <main id="main" className="academy portable-auth" tabIndex={-1}>
    <section className="auth-layout" aria-labelledby="secure-account-title">
      <div className="auth-art">
        <img src="/images/academy-hero.webp" alt="" />
        <div><span className="eyebrow">FLESHSESH ACADEMY</span><h2>More understanding.<br />More confidence.<br /><em>More you.</em></h2></div>
      </div>
      <div className="auth-card">
        <Link className="text-link auth-back" href="/">← Back to the Academy</Link>
        <div className="auth-brand-lockup"><img src="/brand/glossy-master.png" width={1299} height={393} alt="fleshsesh academy" /></div>
        <span className="eyebrow">YOUR SECURE ACADEMY ACCOUNT</span>
        <h1 id="secure-account-title">{title}</h1>
        <p>{description}</p>
        <div className="auth-controls">{children}</div>
        <p className="microcopy">Secure sign-in is provided by Clerk. Your Academy learner profile and progress are stored separately.</p>
        <p className="small-text">For adults 18+. Learner setup includes acceptance of our <Link href="/terms">terms</Link> and <Link href="/privacy">privacy information</Link>.</p>
      </div>
    </section>
  </main>;
}

export function AuthUnavailable() {
  return <div className="panel auth-unavailable" role="status">
    <h2>Account setup is not available yet.</h2>
    <p>The site owner needs to finish secure account setup for this deployment before you can sign in or create an account.</p>
    <p>You can still explore the public course library and Academy information.</p>
    <Link className="button outline" href="/library">Explore the course library</Link>
  </div>;
}
