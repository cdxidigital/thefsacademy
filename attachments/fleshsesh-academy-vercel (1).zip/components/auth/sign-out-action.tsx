"use client";

import { useClerk } from "@clerk/nextjs";
import { useRef, useState } from "react";
import { safeRelativeReturnPath } from "@/lib/auth/paths";

export function SignOutAction({ returnTo }: { returnTo: string }) {
  const { signOut } = useClerk();
  const inFlight = useRef(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function submit() {
    if (inFlight.current) return;
    inFlight.current = true;
    setBusy(true);
    setError("");
    try {
      await signOut({ redirectUrl: safeRelativeReturnPath(returnTo) });
    } catch {
      setError("We couldn’t complete sign-out. Please try again.");
      inFlight.current = false;
      setBusy(false);
    }
  }
  return <>
    {error && <p className="auth-error" role="alert">{error}</p>}
    <button className="button primary full" type="button" onClick={submit} disabled={busy}>{busy ? "Signing out…" : "Sign out of the Academy"}</button>
    <noscript><p>Enable JavaScript to sign out securely.</p></noscript>
  </>;
}
