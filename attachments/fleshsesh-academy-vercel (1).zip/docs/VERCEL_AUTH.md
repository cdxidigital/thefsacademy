# Portable Academy authentication

This export uses **Clerk**, with `@clerk/nextjs` pinned to **7.9.17**, for secure accounts on Vercel. The historical function names in `app/chatgpt-auth.ts` remain as compatibility names for the Academy backend. They no longer read or trust ChatGPT identity headers.

## Configure the deployment

Set these variables for the Vercel environment you deploy:

| Variable | Purpose |
| --- | --- |
| `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` | Clerk's publishable key for the matching application. Set it before building, because Next.js includes public variables in the client build. |
| `CLERK_SECRET_KEY` | The matching server secret. Keep it in deployment environment variables; never put it in a public variable or a committed file. |

The code supplies `/sign-in` and `/sign-up` directly. Optional environment variables `NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in` and `NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up` can mirror those paths. Keep Clerk's application URLs consistent with the final Academy domain. Configure the sign-in methods and verification policy in the Clerk application; verified email is the intended account setup for this Academy edition. Development and production keys must belong to the same Clerk application environment, and changing a public key requires a new build.

Use the separate database and deployment instructions in the export README to enable persistent learning records. Authentication alone does not configure the database, payments or live AI.

No Clerk application, user account or paid service was provisioned to create this ZIP. There are no live credentials in this authentication implementation.

## What is implemented

- `proxy.ts` invokes Clerk middleware when both keys exist. It leaves public content available when keys are absent. The existing page and API guards remain responsible for requiring a signed-in learner; the public catalogue and payment webhook are not indiscriminately blocked by the proxy.
- `getChatGPTUser()` requests a verified **session token**, treats pending sessions as signed out, and checks that Clerk's server user record matches the session user ID. Only the ID, display name, email and full name enter the Academy contract. Clerk private metadata and secrets are not passed to the browser.
- Missing either key means no account identity is accepted, no Clerk provider is mounted, and the secure account pages explain that the deployment's account setup is unavailable. This is not a simulated sign-in. A configured service that fails verification also never falls back to request headers.
- `/sign-in/[[...sign-in]]` and `/sign-up/[[...sign-up]]` mount the actual Clerk sign-in and sign-up interfaces. `/login` points to sign-in; `/signup` points to sign-up. Their default destinations are the dashboard and learner onboarding respectively.
- `return_to` accepts only local Academy content routes. External URLs, protocol-relative URLs, encoded slash/backslash tricks, control characters, API paths and authentication loops are rejected. The Clerk forms receive a validated `forceRedirectUrl`, so an untrusted `redirect_url` query parameter cannot override it. Switching between the sign-in and sign-up forms preserves the same validated destination.
- `/sign-out` is a confirmation page. Its button calls Clerk's `signOut()` SDK method, blocks duplicate clicks during the request and shows a retryable error if that operation fails. Merely visiting a URL never signs a user out. Signing out does not erase learning records or cancel a subscription.
- `/signin-with-chatgpt` and `/signout-with-chatgpt` are safe navigation aliases for older links. They open the appropriate Clerk flow; the latter opens the confirmation page and does not mutate a session on a GET request.

The pre-existing Academy profile deletion still concerns the Academy's learning record and linked recurring subscription. It does not delete the separate Clerk authentication account. Account copy and privacy information in this edition reflect that distinction.

## Verification and remaining deployment check

`node tests/vercel-auth.test.mjs` passes **14 tests**, using the actual TypeScript auth modules, pages, proxy and sign-out handler with the Clerk transport mocked. It checks forged legacy headers, session/profile mismatch, verification errors, local redirect validation, missing-key behavior, provider placement, distinct account flows and deliberate sign-out retries.

These are code and handler regressions, not a claim of a live Clerk account lifecycle test. After adding the owner's real keys and deploying, verify sign-up, verification, sign-in, sign-out and protected-page access on the configured domain. No real account creation, live session, external deployment or payment was performed for the export.

## Official references checked

- [Clerk Next.js App Router quickstart](https://clerk.com/docs/nextjs/getting-started/quickstart) — SDK, keys, proxy and provider setup.
- [Clerk `auth()`](https://clerk.com/docs/reference/nextjs/app-router/auth) — server verification, accepted token types and pending-session handling.
- [Clerk `currentUser()`](https://clerk.com/docs/reference/nextjs/app-router/current-user) — server profile access and private metadata boundaries.
- [Clerk redirect configuration](https://clerk.com/docs/guides/development/customize-redirect-urls) — forced and fallback destinations.
- [Clerk SignIn component](https://clerk.com/docs/nextjs/reference/components/authentication/sign-in) — dedicated paths and sign-in/sign-up navigation.
- [Clerk custom sign-out](https://clerk.com/docs/guides/development/custom-flows/authentication/sign-out) — explicit SDK sign-out and redirect behavior.

Checked 17 October 2026. The README records the complete export build and service configuration.
