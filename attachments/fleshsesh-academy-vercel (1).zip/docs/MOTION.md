# Academy motion

The motion layer is a presentation enhancement. It does not control navigation,
form state, access, progress, authentication, or payment decisions. All content
uses its normal visible CSS state. There are no animation dependencies, audio,
parallax, counters, confetti, or continuous ambient loops in this layer.

## Integration

Import `components/academy/motion.css` **after** the global and brand styles in the
application layout. Render one director inside `.academy`, outside the page
content and outside modal dialogs:

```tsx
import { MotionDirector } from './motion';

<MotionDirector routeKey={route} ready={ageGateReady && !ageGate} />
```

`routeKey` is the existing route string. It must not contain a timestamp or change
when account data refreshes. `ready` should remain false until the initial age-gate
check is resolved, then become true when no age gate is open. This lets the first
hero entrance play after the declaration instead of behind it. The director does
not alter the application context or key/remount the rendered route.

The controller owns `data-motion="on" | "off"` on the document root. It restores
the prior attribute when unmounted. The lower-left toggle is hidden until the
gate and browser preference have resolved and sits below dialogs. On desktop,
it moves above a visible toast through CSS `:has()`. At 600 px and below it is a
44 × 44 px icon button, retaining the full accessible label and explanatory
title, and stays at the bottom left. The host layout reserves 76 px of mobile
bottom clearance and positions mobile toasts to the right of this control
(`left: 66px; right: 15px`) so lesson actions and long notifications stay clear.

## User preference

- The operating system's `prefers-reduced-motion: reduce` preference always pauses
  enhanced motion. The control displays “Reduced motion” with an explanation.
- Otherwise the keyboard-accessible button offers “Pause motion” or “Resume
  motion”. A pause also removes existing decorative CSS transitions, smooth CSS
  scrolling, loading animation, and course-card hover movement.
- The optional local preference uses `fsa:motion:v1` with the values `paused` or
  `system`. It contains no profile information and is not sent to the server.
- When storage is unavailable, the choice still works in memory for the current
  browser page session. Storage events synchronize the preference across tabs
  when storage is available.
- A device-preference change, pause, route change, or unmount cancels active Web
  Animations and cleans up the relevant observers/listeners. No DOM observers
  are installed while `ready` is false or enhanced motion is paused.

The application must also make explicit JavaScript scrolling honor reduced
motion; CSS cannot replace an explicit `behavior: 'smooth'` request. Assessment
submit/retry scroll calls are maintained by the learning component, outside this
module.

## Motion map

| Surface | Behavior |
| --- | --- |
| Landing hero | One 1.9-second image settle; 650 ms staggered text/action entrances. The `.hero-promo` player receives one entrance; media playback is independently controlled by `HeroPromoVideo` (see `docs/PROMO_PLAYER.md`). |
| Editorial sections and cards | One 520 ms reveal near viewport entry; stagger capped at 165 ms. Card reveals use opacity so their hover transform remains independent. |
| Route navigation | A 190 ms opacity entrance on non-home route changes. No navigation delay, outgoing-page retention, form remounting, or forced scroll. |
| Mobile navigation | A 180 ms entrance; immediate close. |
| Dialogs | A 150 ms scrim and 210 ms panel entrance; existing focus trapping and immediate close remain in the shared modal component. |
| Tabs, buttons and cards | Short transitions using the existing colors and static layout. |
| Saved lesson/certificate | One 580 ms icon settle, triggered only by a changed completion toast. Existing toast semantics announce the saved result. |
| Passed assessment | One icon settle when a new passed-result panel is inserted. Existing results do not receive a replay on hydration or resume. |

The image, reading paragraphs, assessment inputs, chat history, private worksheets,
and forms are not scroll-reveal targets. The hero image has only its finite
decorative settle. The route entrance affects the content container's opacity
without moving its layout. A newly focused descendant cancels its ancestor's
active Web Animation, keeping keyboard interaction stable.

`IntersectionObserver` discovers viewport entry. A scoped `MutationObserver`
finds newly rendered presentation elements after catalogue requests or lazy
pages resolve. A separate toast observer ignores existing text at setup, empty
messages, identical messages, and notifications unrelated to learning completion.
Weak sets prevent replay on the same DOM elements. Changing route, preference,
or readiness disconnects the observers and cancels pending animation frames.

Animation does not retain a final fill: removing, finishing, or cancelling an
effect returns an element to its normal stylesheet appearance. Staggered effects
use `fill: 'backwards'` during their brief delay, keeping the readable starting
appearance steady instead of blinking when the delay expires. No hidden initial
style or animation-end callback is needed for content to be usable. Missing
animation or observation APIs simply omit the corresponding enhancement.

## Verification boundaries

The module can be checked with the project's installed TypeScript compiler;
no dependency installation or alternate preview server is needed. Browser
interaction still needs verification in the approved managed browser when it is
available. In particular, check the age gate followed by hero entry, keyboard
focus during a reveal, an assessment result, rapid navigation during loading,
pause/resume, live device-preference changes, mobile toast/control spacing, and
modal focus restoration. This document does not claim those browser checks have
been performed.

The enhancement adds no hidden-content requirement. Core account and learning
functions retain the existing application's JavaScript requirements.

## October 2026 hero revision

The hero uses the conceptual eCampus background and a separate, deliberately silent 15-second Academy brand-film player. Its play/pause, replay, visibility handling, global motion preference and full visual transcript are documented in `docs/PROMO_PLAYER.md`. The motion director controls only the finite player entrance and background settle. The player never begins behind an unresolved age gate. Explicit Play can request media playback with reduced motion enabled while decorative page motion stays paused.
