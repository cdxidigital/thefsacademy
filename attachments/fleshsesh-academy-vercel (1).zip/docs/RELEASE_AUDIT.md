> Historical Sites release record. For this Vercel export, use `README.md`, `DEPLOY_TO_VERCEL.md` and `docs/VERCEL_EXPORT_VERIFICATION.md`. Native ChatGPT hosting identity and Cloudflare D1 have been replaced in the export. Earlier test counts and deployments below describe the original release.

# Curriculum promo, subscribed demo and platform audit

Release prepared: 17 October 2026. This report describes tested code paths and explicit remaining limits; it does not certify every browser, provider or clinical outcome.

The release was reconciled with the concurrent curriculum **1.1** update before publication. Its revised teaching, 19 revised assessment items, three new source records and canonical-index answer shuffling are preserved alongside the demo and tutor changes. The curriculum still contains 18 modules and 48 written lessons, so the new film remains accurate.

## Delivered

### New curriculum promo

The landing page uses a new 25-second silent film, with original generated campus footage, fictional adult learners, animated course titles and the supplied glossy Academy logo. It references consent, bodies, communication, relationships, identity and inclusion; the 18 modules, 48 written lessons and three tutor roles match the actual curriculum.

The new MP4 is 1920 × 1080 at 24 fps, H.264 High Level 4.0, 4,377,924 bytes, with a verified full decode and faststart layout. Its matching closing-frame poster and complete visual description are included. Source footage and a reproduction script are retained. See `PROMO_MEDIA.md` and `docs/media/promo-v2-verification.json`.

The player allows one automatic viewing of each versioned film per browser-tab session, after adult entry and visibility/motion checks. It pauses when hidden, never loops, and retains manual Play and Replay. Reduced motion and the site motion control suppress automatic playback. When session storage is blocked, in-memory protection lasts through client navigation; a full reload cannot preserve that record.

### Academy Plus demonstration

Open `/demo`, use native ChatGPT sign-in, accept the adult learner declaration and enter the demo. There is no shared password. The separate **Alex · demo learner** receives two hours of Plus access, six sample lesson completions and one sample module pass. C02's assessment can be tried immediately.

Member lessons, assessments, XP, progress and resources use actual application handlers with isolated demonstration records. Reset starts again; Exit restores the normal learner. The cookie is owner-bound, private and hashed in D1. Expired/tampered sessions fail closed. A stale tab cannot silently write demonstration actions into a restored real learner profile.

Real payment actions, real account export/deletion and genuine certificate issuance reject demo learners. The sample certificate is visibly marked **DEMONSTRATION · NOT VALID**. Demo tutoring never calls a paid AI provider or spends AI credits. See `DEMO.md`.

### Three distinct tutor roles

| Tutor | Personality and knowledge |
| --- | --- |
| Foundations Tutor | Calm, clear and curious. Explains accessible lesson content, recaps one idea and supplies actual course sources. |
| Practice Coach | Encouraging, practical and unhurried. Presents a fictional choice, waits for the learner, then explains the source reasoning. Follow-up explanations continue the exercise context. |
| Assessment Tutor | Precise, patient and fair. Reads the learner's own stored totals, completion requirements and already released feedback. It cannot change marks or issue credentials. |

An active marked assessment restricts every role to process guidance. Provider replies are checked again if an assessment opens while the request is pending. Demo, access, source, privacy, quota and refund checks run on the server. The private answer bank is not imported into public persona configuration or passed to the model.

The current runtime has **no model/key configured** and keeps the external-AI release gate closed. The three roles therefore operate as clearly labelled curriculum guides. Distinct optional AI instructions and failure/refund paths were tested with a mocked provider; real generative quality is not verified. See `TUTOR_ROLES.md`.

## Concrete defects fixed

| Area | Finding and correction |
| --- | --- |
| Subscription consent | The server now requires recurring-price consent before creating a subscription checkout. The checkbox alone had not enforced it. |
| Saves and progress | Successful learning/profile writes remain saved when a later totals refresh fails. Duplicate submission is blocked and retries do not repeat successful onboarding writes. |
| Assessment state | Pending answers lock; stale responses from a prior route cannot replace the current assessment. Saved results receive focus and explicit correctness text. |
| Account refresh ordering | Newer snapshots and errors win over older requests. Identity changes and unmount invalidate pending view updates and the client learner-consistency hint. |
| Certificates | Direct download links replace delayed popup creation. Demo output remains a marked sample. |
| Tutor conversation | Tutor/topic/account changes clear and abort old conversations. Practice feedback followed by “why?” now explains instead of restarting an exercise. UTF-8 request bounds are enforced before sending. Curriculum 1.1 urgent-sign questions now return the exact emergency-support paragraph and H01/H02 sources before ordinary teaching. |
| Public navigation | The glossary/source-register route is public while protected toolkit content remains server-gated. Support, policies and demo recovery survive catalogue failure. The landing film also stays mounted, with a retry in its course section. |
| Embedded sign-in | Demo native sign-in opens at the top-level browsing context. |
| Privacy | Disclosure now includes bounded recent conversation sent to the Academy API and, only when eligible and consented, to OpenAI. It distinguishes processing from chat database retention. |
| Responsive controls | Mobile progress status wraps; reader controls have 44-pixel targets; tutor assessment notices span their grid; compact navigation leaves room for the new demo destination. |

## Verification evidence

Across nine suites, **97 tests/groups passed and one authoring-file parity check was skipped**. Counts describe actual test cases, not fully interactive journeys. The 11 original backend groups include broad assertions across the assessment bank and commercial/account paths.

| Command | Passing cases | Method |
| --- | ---: | --- |
| `node tests/backend.test.mjs` | 11 | Actual server routes, grading, access, billing/AI boundaries and generated migrations in isolated SQLite/D1 |
| `node tests/demo.test.mjs` | 9 | Actual demo routes, owner/session isolation, paid gates, provider restrictions and client expectation header |
| `node tests/demo-ui.test.mjs` | 4 | Actual demo component rendering with controlled account context |
| `node tests/learner-entry.test.mjs` | 15 | Actual TSX handlers for onboarding, saves, assessments, certificates, entitlement recovery and shuffled-answer submission/retry |
| `node tests/tutor-personas.test.mjs` | 31 | Actual tutor handler, including all 18 source acceptance cases across all three roles |
| `node tests/tutor-client.test.mjs` | 5 | Actual tutor TSX state and handlers with isolated hooks/navigation |
| `node tests/promo-playback.test.mjs` | 9 | Actual playback-policy and session-storage helpers |
| `node tests/academy-refresh.test.mjs` | 9 | Actual application and request helper with deferred/out-of-order responses |
| `node tests/curriculum.test.mjs` | 4; 1 skipped | Actual grading patterns, shuffled canonical indices, response key exclusion and curriculum invariants; separate authoring-file parity skipped |

The backend, tutor and demo suites were rerun against curriculum 1.1. The merged learner suite verifies both the retained audit fixes and the new shuffled-answer behavior. The refresh suite includes the final landing-page failure recovery. The release workflow requires a clean diff check, complete-project TypeScript check and official production build before source push and packaging.

The four runnable curriculum checks include 5,024 grading patterns, 2,736 answer-order presentations and key exclusion from the public catalogue and all 68 authorized assessment responses. A fresh exact comparison against the separate revised authoring JSON could not run: the available attachment was edition 1.0, not the manifest's expected 1.1 SHA-256 `598ea8bf6d69e2a9bbcff302a64592a4bbbd2b8372bd887877efb615a435c4e9`. The older file was not substituted. The preceding curriculum release's own parity record is preserved in `CURRICULUM_AUDIT_2026-10-17.md`; it is not counted as a new passing check here.

### Dependencies

The initial production dependency scan found five affected package entries. Compatible fixes update Next and its ESLint configuration to 16.4.2, Sharp to 0.35.5, source-map-js to 1.2.2, the affected fast-uri v3 path to 3.1.8, and baseline-browser-mapping to 2.11.29. The lockfile was regenerated and the official clean installer succeeded.

`npm audit --omit=dev --json` then exited successfully with **zero known production findings**. The actual result is retained in `production-dependency-audit.json`. This is the registry's package-advisory result for this lockfile, not a guarantee of application security, a claim that every flagged package was exploitable in the Worker, or an audit of development-only dependencies.

## Remaining verification and activation limits

- The required managed browser capability was unavailable. Responsive code, interaction handlers and video frames were reviewed; actual mobile/desktop rendering, hydration, keyboard journeys, playback and fullscreen were not browser-tested.
- Native signed-in production journeys and production D1 writes were not performed by impersonating a visitor. Sign-in remains the platform's official flow. Handler tests use isolated fixtures.
- No actual Stripe charge, live webhook, billing portal visit or real AI request was made. Those provider transports are mocked in tests. Checkout remains disabled in pilot mode; model credentials and existing release gates remain unset.
- Generated replies need a real-provider acceptance run after activation. Valid source IDs do not prove every generated sentence is correct.
- Specialist clinical/legal review and external accreditation are not completed or claimed. The course remains written, non-accredited adult education.

The final publication result and read-only public endpoint checks are reported with the delivered site. Publication does not remove these limits.
