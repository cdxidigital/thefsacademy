# Printable certificate brand update

The private certificate download now follows the supplied **fleshsesh academy** identity. This is a bounded presentation change to the existing downloadable HTML certificate.

## Visual decisions

- The actual flat black wordmark is embedded as a PNG. It is the supplied custom artwork, not text re-created with a substitute font. The Paper surface is appropriate for this black-on-transparent asset.
- Inter Regular 400 and Inter Bold 700 are embedded as standard WOFF fonts. These are faithful static subsets of the official Inter variable font at optical size 14; Latin, Latin Extended, punctuation, euro and middle-dot glyphs are included. Arial/sans-serif remains the fallback for unavailable glyphs or a renderer that cannot load embedded fonts. The font license is retained at `public/fonts/OFL-Inter.txt`.
- The palette is exactly Ink `#0D1014`, Paper `#F4EEE6`, Berry `#9D3A5C`, Blush `#E6A7BB` and Brass `#C7A86D`. Ink carries body text, Berry provides headings and accents, Blush decorates a small separator, and Brass is used only for decorative rules/borders.
- The brand name is lowercase in the document title, image alternative text, accessibility label and downloaded filename. The certificate remains an **Assessed Certificate of Completion**, with the original course name, learner name, requirements, issue date, version and certificate ID.
- A restrained landscape layout provides responsive screen styles and separate A4 landscape print styles. Long learner names can wrap. The print guidance is hidden in print output. The certificate has no animation or scripting; the interactive site's motion is separate from the printable record.

## Offline and privacy behaviour

The logo and both fonts are embedded into `lib/server/certificate-brand.ts` as data URIs and included directly in the downloaded HTML. The download makes no external image/font request. It does not depend on access to the live website after downloading.

The existing Content Security Policy retains `default-src 'none'` and permits only inline CSS plus `data:` images and fonts. Authentication, user-scoped lookup, private/no-store response headers, eligibility, issuance, idempotence and certificate data were not changed. The non-accredited statement and private-pilot notice remain visible. The download filename is `fleshsesh_academy_certificate.html`; the URL and response format remain the same.

## Embedded assets

| Source | Bytes | SHA-256 |
|---|---:|---|
| `public/brand/flat-wordmark-dark.png` | 63,335 | `f9394d2556b66c290e062217c20086c79c09543d645237fa06207cbefbbbcc83` |
| `public/fonts/Inter-Regular-Latin.woff` | 70,444 | `eabde7b4bd3461bca008a6a3ca2bd9fa25ee2ec95821aec21d3eeab26a30d238` |
| `public/fonts/Inter-Bold-Latin.woff` | 72,928 | `541eec80bf46c62d74e61dddc30f3d06c385721a6851ca1c2fa85e316f3a78c0` |

The generated module embeds these asset bytes directly. To update an asset later, regenerate the matching data URI from the approved file; do not retype the wordmark. The PNG is 1984 × 604 pixels and uses its natural aspect ratio.

## Verification

All 11 existing backend test groups passed with `node tests/backend.test.mjs`, including the certificate's existing authentication, eligibility and private-download coverage. The TypeScript check also passed with `npx tsc --noEmit --pretty false`. No additional tests, browser, preview server or screenshot workflow were introduced. These checks do not constitute printer/browser layout testing.
