# Virtual eCampus artwork

## Status and purpose

This background is an **AI-generated conceptual illustration of a virtual learning campus**. It does not depict a real Academy building, an existing campus, a physical facility available to learners, or an accreditation claim.

It was created on **17 October 2026** with the built-in image-generation tool for the requested landing-page revision: replacing the terracotta sculpture background with an eCampus environment. The header identity and promotional film are separate supplied assets; neither was generated as part of this image.

The composition reserves approximately the left 45% for a quiet dark headline area. The right side contains a glass library atrium, tiered study spaces, comfortable lounge furniture, warm shelves and path lighting. Translucent panels contain abstract shapes only. The inspected output contains no people, readable text, logos, sexual imagery or assessment claims.

## Production assets

| File | Dimensions | Format | Size | Purpose |
| --- | --- | --- | --- | --- |
| `design/originals/ecampus.png` | 1672 × 941 | RGB PNG | 2,017,594 bytes | Unchanged generated original |
| `public/images/ecampus.webp` | 1672 × 941 | WebP | 138,568 bytes | Website hero background at `/images/ecampus.webp` |

The actual generated frame is approximately 16:9. The WebP was encoded with the project's existing Sharp installation at **quality 84, effort 6**, preserving the complete frame without cropping or resizing. It is approximately 93% smaller than the PNG. The generated original was copied unchanged into the project.

### Integrity

- Original PNG SHA-256: `67284976422327fd78816c4b07573e4bcbc2ac456fc8e8ab4749ee986231f2d5`
- WebP SHA-256: `fde36ae8100e53e3a624468666f69cd519ef752cb06e179e4726b3d135eff597`

The built-in tool returned `generated_images/exec-13d11dd8-bece-4ab8-8853-8885bfb461b9.png` in the working session. A staging copy was retained as `promo-work/ecampus-original.png` before the site source was reopened. The project files above are the production deliverables.

## Brand direction

The prompt uses the supplied Brand Guide v1.0 palette: Ink `#0D1014`, Berry `#9D3A5C`, Blush `#E6A7BB`, Brass `#C7A86D` and Paper `#F4EEE6`. These guide the architectural materials and lighting. A photographic rendering naturally includes shading, reflections and colour variation; it is not a flat palette swatch or an accessibility contrast guarantee.

The large dark left area supports headline placement. The website applies responsive crops and contrast overlays in CSS; the source image itself remains unchanged. Use wording such as “virtual campus” or “conceptual eCampus illustration” when describing it as an image, rather than suggesting a real physical location.

## Exact generation prompt

```text
Use case: ads-marketing
Asset type: background image for an adult digital-learning platform landing page, cinematic landscape 16:9, ideally 2048 x 1152.
Primary request: Create a sophisticated conceptual virtual eCampus: a beautiful adult learning library and lounge within a glass atrium at dusk or night. This is an imagined learning environment, not a real campus or institutional claim.
Scene: generous double-height architectural space, tiered collaborative study terraces, warm illuminated bookshelves, carefully considered comfortable lounge furniture, glass balustrades and quiet brass path lights. Include a few restrained floating translucent learning panels with purely abstract shapes, no readable text.
Style: photoreal architectural visualization with the craft of an editorial architecture photograph; detailed believable materials, cinematic depth, refined and welcoming mature design.
Composition: wide 16:9 hero background. Concentrate the architectural interest, shelves and tiers from the center to the right. The LEFT 45 percent must remain exceptionally quiet, uncluttered and very dark, with a soft smooth charcoal foreground wall or atmospheric shadow suitable behind large white headline text. Avoid bright windows, lamps, furniture edges or intricate geometry behind the left headline zone. Right-side architecture should still feel immersive and expansive. Eye-level wide architectural view with natural straight verticals.
Light and palette: Ink #0D1014 is the predominant dark ground. Restrained Berry #9D3A5C and Blush #E6A7BB reflected light in the learning spaces, warm Brass #C7A86D highlights and gentle gold path lighting, Paper #F4EEE6 reading surfaces. Subtle glass reflections and soft dusk outside. Inviting pools of light, tasteful contrast, quiet cinematic atmosphere, no neon saturation.
Materials: smoked glass, warm timber shelves, softly textured upholstery, matte dark stone, subtle brushed brass.
Constraints: image only, no words, no typography, no logos, no watermark, no people, no sexuality or anatomy, no certificates or assessment claims. Do not include any existing academy logo. Avoid generic corporate offices, cyberpunk, neon holograms, glowing grids, sci-fi command centers and clutter. The panels are minimal and secondary to the human-scaled architecture. Preserve the calm dark left-side space.
```

## Bounded integration review

A read-only review compared `app/brand.css`, `components/academy/marketing.tsx` and the inherited rules in `app/globals.css`, including the final imported promo-player styles. It considered widths **320, 390, 600, 800, 1000, 1100 and 1431px**. No browser was started for this review.

Two mobile header conflicts were reported and corrected by the integration owner: a general glossy-logo rule overriding the more specific intended header dimensions through equal specificity, and bottom padding making the action area taller than its fixed grid row.

After those corrections, the header uses **244px artwork width above 600px and 242px at or below 600px**, both exceeding the guide's 240px minimum. With the 1299 × 393 master aspect ratio, quarter-height clear space is approximately **18.45px and 18.30px**, respectively; the header supplies **19px padding on every side**. The 44px controls fit the 46px mobile action row.

The hero uses one column through 1000px and two above that threshold. Its calculated text tracks at the requested widths are approximately 278, 342, 552, 640, 640, 466 and 606px. The Inter headline fits within those tracks in a local font-shaping estimate. The player stays in normal document flow with responsive dimensions and zero minimum grid-item width. No additional concrete header or hero overflow was identified in this bounded static review. Browser rendering, playback and device interaction are separate integration checks.
