> Historical Sites release record. For this Vercel export, use `README.md`, `DEPLOY_TO_VERCEL.md` and `docs/VERCEL_EXPORT_VERIFICATION.md`. Native ChatGPT hosting identity and Cloudflare D1 have been replaced in the export. Earlier test counts and deployments below describe the original release.

# Verification record — 17 October 2026

## Latest curriculum promo and audit release

- New, original 25-second 1080p curriculum promo integrated with supplied branding, a reviewed visual description, faststart encoding and a successful complete decode. The film names the actual 18 modules, 48 written lessons and three tutor roles. See `PROMO_MEDIA.md`.
- Once-per-tab automatic playback is implemented and verified through the actual policy/session helper; manual replay, reduced motion and adult-entry gates remain. Actual browser playback is not claimed.
- Isolated native-sign-in Plus demonstration implemented at `/demo`, with two-hour access, owner-bound hashed session tokens, sample learning state, reset/exit, stale-tab protection and a clearly invalid sample certificate. Demo requests cannot charge money, use external AI or alter a normal learner's records.
- Foundations, Practice and Assessment tutors now have distinct source-defined roles and server behavior. Their 31-case handler suite exercises all 18 curriculum acceptance cases across all three roles. Optional real AI remains unconfigured.
- Nine test suites have 97 passing tests/groups: backend 11, demo 9, demo UI 4, learner UI 15, tutor handler 31, tutor client 5, promo policy 9, refresh ordering 9 and curriculum 4. One separate authoring-file parity check is skipped because the revised 1.1 export is unavailable; the older attachment was not substituted. These are isolated handler/component checks, not browser journeys.
- Reconciled the concurrent curriculum 1.1 release before publication. Retained all revised content and source records, canonical-index answer shuffling and the six-decision applied-case feedback. The backend/tutor/demo tests were rerun against that edition; the merged learner suite exercises the combined behavior. Promo counts remain 18 modules and 48 lessons.
- Audit fixes cover recurring-payment consent, duplicate/stale submissions, saved-state recovery, account refresh ordering, private/demo certificate boundaries, public resource entry, catalogue-failure recovery, tutor follow-ups and accurate conversation privacy disclosure.
- The final production dependency scan reports zero known findings after compatible dependency patches and an official clean installation. The scan is saved in `production-dependency-audit.json`.
- `RELEASE_AUDIT.md` records the current evidence and remaining browser, real-provider, production-mutation and specialist-review limits. Historical releases below describe their own assets and checks.

## Passed

- Source import: all 48 teaching texts preserved; all 114 assessment prompts, ordered options, correct responses and feedback compared with the Moodle XML, zero discrepancies.
- TypeScript: complete project `tsc --noEmit` passes after frontend/API contract alignment.
- Production build: Vinext client, RSC and SSR compilation passes, with all application and API routes included.
- Backend: 11 actual-route test groups pass using generated SQL in an in-memory SQLite implementation of the D1 interface. Only hosting identity/bindings and external provider transport are mocked.
- The backend tests cover all source assessment items, critical-item failure, authentication/adult acknowledgement/CSRF/body limits, cross-user isolation, paid access gates, XP idempotence, complete certificate prerequisites, private certificate downloads, guide modes and limits, profile deletion, webhook signatures and replay, duplicate payment events, refunds, canonical subscription state, product/price checks, AI consent and quotas, and failed-provider-call refunds.
- Client/API review corrected account deletion confirmation and cancellation copy, actual plan/period fields, tutor request limit/usage/notices, lesson scenario feedback, module sidebar lookup, server-based level values, checkout availability, and marked assessment start/end/retry handling.
- Commercial planner arithmetic matches the independent 100/500/1,000-member calculation, including zero-member and additional-cost scenarios. Figures are assumptions, not actual customers or income.
- Original artwork and font files inspected. Sources and OFL licences are retained. WebP delivery copies preserve the source dimensions and reduce the five images from 10,180,277 to 625,486 bytes (94%); original PNGs remain in `design/originals`.
- Subscription reversal tests cover invoice-specific refund/dispute holds, renewal payments without a Checkout Session, replay resistance, subsequent paid-period access and won-dispute reinstatement.

## Not represented as complete

- Interactive browser/viewport testing: the required managed browser capability was not available. No preview server or alternative browser route was substituted. Responsive and keyboard behaviour has been implemented and reviewed in code, but a real browser pass remains a release task.
- Live ChatGPT visitor sign-in and production D1 mutations: the public sign-in entry redirects to the official OAuth endpoint, but the authoring session cannot impersonate a signed-in visitor. The actual handlers are exercised in isolated tests.
- Actual Stripe sandbox/live charges, webhooks and portal flows: no provider credentials or business acceptance supplied. HTTP/provider responses were mocked for the tests. Public publication has been approved, but checkout remains disabled in pilot mode.
- Live generative tutor: no real model call or API credential configured. Current guide mode is explicitly labelled curriculum retrieval. AI adapter tests mock the transport.
- Specialist clinical/legal review and external accreditation: not completed or claimed. Teaching content remains written. The separate silent promotional film is documented below.

## Brand and motion update — 17 October 2026

- Extracted original logo variants, compact icon and Open Graph artwork from the supplied brand-guide PDF. Direct exports were compared against the embedded source pixels. The glossy master removes only the documented near-invisible background margins; the original extraction is retained.
- Applied exact primary brand tokens, lowercase identity and self-hosted Inter. Client WOFF preserves weight and optical-size axes and is 232,964 bytes.
- Added a motion controller with progressive enhancement, preference persistence, OS reduced-motion support, observer/animation cleanup and no animation-controlled access or navigation. Static module/lesson data remains intact.
- Certificate changes preserve all eligibility and privacy behaviour; the existing 11 backend test groups pass with the new offline logo/font data and CSP.
- Complete project TypeScript and production build pass on the final branded source. Native deployment status is the publication check.
- The approved managed browser capability remains unavailable, so visual timing, mobile interaction and physical print output are not claimed as browser-verified.

- Local checks found no missing brand/font references. Primary solid-colour contrast pairs match the guide: Paper/Ink 16.54:1, Berry/Paper 5.71:1, Blush/Ink 9.63:1, Brass/Ink 8.40:1. These checks do not claim full interface WCAG conformance. Narrow-screen headline metrics were checked with Inter; the 320px variant was adjusted to stay within the content width.

## Public release and completion pass — 17 October 2026

- The owner approved public publication. Version 3 deployed successfully at `https://fleshsesh-academy.jamison-park-3726.chatgpt.site` with the glossy header logo, eCampus background and 15-second silent promo film. Media provenance and playback behaviour are recorded in `PROMO_MEDIA.md`, `PROMO_PLAYER.md` and `ECAMPUS_ART.md`.
- Read-only requests to the public landing, signup, login, library, pricing and about pages all returned HTTP 200. The catalogue and anonymous profile endpoints also returned HTTP 200; the catalogue contained 18 modules and 48 lessons, and anonymous billing reported pilot mode with checkout unavailable.
- The public logo, eCampus image, poster, MP4 and visual-description track all returned HTTP 200. The deployed MP4 is 3,792,201 bytes and its SHA-256 (`516bd337c30d2028741d5506f1406a677195c0fd4bf3b387bf03f73df0ae9b86`) matches the reviewed source asset. The earlier source-media checks verified a full decode and fast-start layout. The host returned the complete MP4 for a range request; byte-range delivery and browser seeking are not claimed as verified.
- The native sign-in entry returned HTTP 302 to `https://auth.openai.com/oauth/authorize`. Unauthenticated requests to a lesson and the private certificate endpoint returned HTTP 401. No live learner profile, payment or other production data was created by these checks.
- Completion fixes route existing learners from landing/pricing calls to action to their dashboard; onboarding redirects profiles with the current accepted policy, preserves the weekly goal during policy reacceptance, and tolerates unavailable session storage after the server has saved the profile. Paid lesson access errors offer membership, while expired-agreement errors offer onboarding.
- `node tests/learner-entry.test.mjs` passes all five targeted behaviour checks against the actual compiled component handlers and existing API response parser: current-policy redirect, policy reacceptance and goal retention, successful onboarding with blocked storage, membership recovery, and agreement recovery. Hook/navigation state and HTTP responses are isolated; these are not browser tests. No backend handlers changed in this pass, so the existing full backend suite was not rerun.
- Restored Quick exit as a labelled 44-pixel mobile header control. Responsive layout, silent-film disclosure, playback readiness, motion coordination and fullscreen failure handling received a bounded code review. The required managed browser remains unavailable; interactive mobile, playback and signed-in production flows still need a real browser pass.


## Curriculum audit revision 1.1

- All 48 lessons and 114 assessment items received an editorial review. Six lesson records, 19 items and the applied-case exemplar were revised; three authoritative health references were added. The current catalogue and assessment bank match the revised source JSON exactly. See `CURRICULUM_AUDIT_2026-10-17.md`.
- The new five-group curriculum suite covers all 5,024 correctness patterns in the actual online grading function, 2,736 shuffled-option presentations, all 68 authorised question responses, catalogue key exclusion and exact seed parity. It passes against edition 1.1.
- The 11 backend groups and six component groups pass, including the five original learner-entry checks and a new actual-component assessment submission/retry check. The complete TypeScript check and production build are required on this final source before packaging. Their completed results are recorded by the source workflow; a failure blocks this publication.
- Answer shuffling retains canonical indices for selected answers and feedback. Retry reshuffles only presentation. Inputs are disabled during submission. A failed PLAN01 result names its six required decisions rather than the capstone.
- Existing progress, pass records, certificates, access audience and release flags are preserved. This audit does not claim live browser, live generative-model, clinical, accreditation or learner-pilot validation.
