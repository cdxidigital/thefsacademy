# Academy Plus demonstration

## Visitor experience

Open `/demo` and sign in using the verified Clerk sign-in for this Vercel export. There is no shared demonstration password. Confirm the adult learner declaration and enter the demonstration.

The demonstration selects a separate learner named **Alex · demo learner** with Plus access. It starts with six sample lesson completions (C01 and C02) and one sample module assessment pass (C01). The C02 assessment can be attempted immediately. Member lessons, progress, XP, assessments and resources use the same server routes as regular learning. New actions update only this separate demonstration learner.

The banner remains available across the platform. **Reset demo** deletes that demo's learning records and creates a fresh sample. **Exit demo** deletes the demo and restores the visitor's normal learner context. Access lasts two hours; an expired session must be restarted or exited. Starting a new demonstration for the same signed-in account replaces its previous demonstration.

`/api/demo/certificate` provides a branded sample clearly labelled **DEMONSTRATION · NOT VALID**. It has no issue number, makes no claim of achievement and creates no certificate record.

## Isolation and provider limits

- Verified Clerk identity remains authoritative. The demonstration cannot authenticate a visitor or replace the hosting sign-in mechanism.
- A random 256-bit token is stored in the `__Host-fsa-demo` cookie. It is Secure, HttpOnly, SameSite=Strict and scoped to `/`. Only its SHA-256 hash is stored in the learning database.
- The token is bound to the authenticated visitor's user ID and a separate `demo:<uuid>` learner. Copying the cookie to another account cannot select its learner record.
- Demo Plus access expires with the session. No entitlement is added to the visitor's normal account and no billing customer is created.
- Checkout, billing portal, normal account export/deletion and genuine certificate issuance/download reject demo learners on the server. The curriculum guide can run, but demo requests cannot call paid external AI or consume purchased AI questions.
- The cookie marker outlives demo access so expired tabs fail closed instead of silently selecting the normal account.
- Client API requests include their expected learner ID in `X-Academy-Learner`. This is a consistency check, never authentication. If a different tab resets or exits the demo, a stale request receives `409 learner_session_changed` before its action runs. `/api/me` can refresh that expectation.
- Expired demo records are deleted during subsequent demo creation. Reset/exit deletes the selected demo immediately. Deleting a normal Academy account also deletes its associated demo. Cleanup removes progress, assessment attempts/results, entitlements and guide usage through foreign-key cascades.

## Route contract

`GET /api/demo` returns `{ authenticated, active, expired, expiresAt, tier, signInUrl }` and does not expose token hashes or owner IDs.

`POST /api/demo` accepts same-origin JSON:

- `{ "action": "start", "adultConfirmed": true, "educationAcknowledged": true }`
- `{ "action": "reset" }` for a recognised existing demo; otherwise the two declarations are required again.
- `{ "action": "exit" }`

Successful actions return a same-site `redirectTo`. The client performs a full navigation so pages and private scratchpads cannot retain the prior learner's state. Start/reset sets the demo cookie; exit expires it.

`GET /api/me` adds `demo: { active: true, expiresAt, source: "isolated-demo", tier: "plus" }`. Its billing mode is `demo`, checkout is unavailable, the tutor mode is `lesson-guide`, and the certificate object contains `demoOnly: true` with a `sampleUrl`. Normal account snapshots have `demo: null`.

## Verification

`node tests/demo.test.mjs` exercises the actual route handlers and client request helper with an isolated SQLite adapter implementing D1 operations. It covers verified account authentication, adult declaration, request bounds/CSRF, cookie attributes/hash/binding, member access while real paid gating is enabled, progress idempotency, assessment grading, toolkit access, provider and genuine-account restrictions, reset/exit/expiry, cross-account replay, and stale-tab protection. `node tests/backend.test.mjs` retains the full existing backend regression suite.

`node tests/demo-ui.test.mjs` renders the actual demo components with controlled account context. Its four passing checks cover anonymous sign-in, the required adult declarations, active demo destinations/reset/exit controls and expired-session recovery. These checks do not simulate browser layout or hydration.

The billing audit also found that the interface's recurring-price consent was not enforced by the checkout API. The API now requires `renewalConsent: true` for subscriptions before contacting the provider; one-time purchases retain their existing behaviour.

These checks exercise route handlers and the client request helper, not a completed signed-in browser session or a live payment-provider test. The site still requires its provider configuration and release decisions before charging real customers or enabling external AI.
