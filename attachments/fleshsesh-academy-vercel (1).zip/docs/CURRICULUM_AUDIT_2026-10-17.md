# Curriculum revision 1.1

The curriculum audit reviewed all 48 lessons, 48 fictional scenarios, private activities and 114 assessment items. The updated course retains 12 core modules, six electives, its existing learning outcomes and the same completion thresholds. This was an editorial evidence review and implementation audit; specialist clinical/legal approval, external accreditation and empirical learner validation have not been obtained.

## Changes

- Clarified two optional activities in C01-L01 and C03-L01.
- Added explicit Australian emergency escalation for serious intoxication signs in C01-L02, supported by Victorian Government and NSW Health guidance.
- Made C05-L03 emergency-contraception follow-up more specific, including the interaction between ulipristal and progestogen-containing contraception and the lack of protection for later sex. The lesson directs learners to individual professional advice. The added source is Australian Prescriber, 2 June 2026.
- Revised 19 assessment items. This removes two ambiguous premises, clarifies a proposed shared relationship arrangement, improves final-answer alternatives, and aligns the six applied decisions with all six written rubric criteria.
- Made storage and AI-use permissions explicit in the applied privacy item and written exemplar.
- Added three source records, H01-H03, bringing the register to 91.
- Shuffled displayed answer positions when an assessment opens or a learner retries. Each choice retains its canonical server option index; feedback uses that same index. Inputs are disabled while a submission is being marked.
- Corrected the failed applied-case notice to name its six required decisions instead of the capstone.

All question IDs, canonical correct indices and critical-item membership are unchanged. The server continues to mark choices using private answer data. The client receives no answer keys before submission.

## Completion and version compatibility

Orientation and all 36 core lessons are required. Each core module requires 5/6; the final requires 10/12 with CAP01-Q01 to CAP01-Q04 correct in the same passing attempt; applied planning requires 6/6. Electives remain optional, with their separate 4/4 checks. Existing online lesson completions, passing results and issued certificates are retained because this editorial revision preserves the existing outcomes and pass rules. Existing certificates retain their stored course version; newly issued certificates record the current edition. No learner records were edited or reset by this audit.

The downloadable authoring service is a separate implementation. It keeps strict edition checks, validates trusted completion records and returns eligibility only. Its runtime validation fixes do not imply that malformed-input vulnerabilities were exposed by this Site.

## Verification

Run the course-specific checks with the audited authoring JSON:

```sh
node tests/curriculum.test.mjs /absolute/path/Fleshsesh_Academy_LMS_Content.json
node tests/backend.test.mjs
node tests/learner-entry.test.mjs
node node_modules/typescript/bin/tsc --noEmit
```

The curriculum suite checks all 5,024 right/wrong patterns across the 20 marked assessment forms, all 24 display orders for each of 114 questions (2,736 presentations), exact parity between online and authoring content, and key exclusion from the public catalogue and all 68 authorised assessment responses. API checks use the actual handlers with isolated platform identity and an in-memory SQLite implementation of D1; they do not create live learner data. The six component checks also exercise the real TSX assessment handlers through a shuffled submission, pending-marking input lock, failed applied-case feedback and a reshuffled retry. Hook, navigation and transport are isolated; these are not browser rendering sessions.

Question-length analysis is an authoring check, not a learner result. Before revision, all six applied-case correct answers and ten of twelve final correct answers were uniquely longest by word count. After revision, none is uniquely longest; all four options in each applied question have equal word counts. A check for an accidental shortest-answer cue was also completed.

The approved managed browser capability remains unavailable. No browser preview or alternative browser path was substituted. Live generative AI conversations, real learner piloting, Moodle import and specialist approval remain outside the verified scope. Current public/private access and release flags are preserved.

## Source evidence

- [Victorian Government: overdose emergency response](https://www.betterhealth.vic.gov.au/health/servicesandsupport/overdose-what-to-do-in-an-emergency), reviewed 28 May 2026.
- [NSW Health: Alcohol the facts](https://yourroom.health.nsw.gov.au/publicationdocuments/Alcohol_fact_sheet_2021_A4.pdf).
- [Australian Prescriber: Emergency contraception an overview](https://australianprescriber.tg.org.au/articles/emergency-contraception-an-overview.html), 2 June 2026.

All three were read on 17 October 2026. The added source records describe an editorial source check, not clinical signoff. Other source records retain their existing provenance and review status.
