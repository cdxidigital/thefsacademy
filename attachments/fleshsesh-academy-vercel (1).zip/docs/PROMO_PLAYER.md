# Academy brand-film player

`HeroPromoVideo` presents the selected Academy brand film. It is not a course
demonstration or a sample lesson. The root application owns the actual media
files, final visual description, hero placement, and age-gate state.

## Integration

Import `components/academy/promo-video.css` after the application styles. The
component is a normal-flow `.hero-promo` figure with `max-width: 100%`; the hero's
grid or stack determines its position. `MotionDirector` applies one finite
entrance to `.hero-promo`; the player independently controls its media playback.

```tsx
import { HeroPromoVideo } from './promo-video';

<HeroPromoVideo
  ready={ageGateChecked && !ageGate}
  durationSeconds={25}
  hasAudio={false}
  hasCaptions={false}
  src="/media/academy-new-chapter-v2.mp4"
  poster="/media/academy-new-chapter-v2-poster.webp"
  transcript={verifiedVisualDescription}
/>
```

The host owns each released film's exact duration and verified audio state.
Autoplay is muted even if that edition has audio. Do not label a film narrated
or provide audio captions for unverified audio. The host should provide the
reviewed visual description as `transcript` and retain the default disclosure
label, “Read the film description”, unless a spoken transcript was verified.

The released `/media/academy-new-chapter-v2.vtt` is a visual-description resource, not
audio captions. Leave `hasCaptions` false for this edition. The visible disclosure
provides the complete reviewed visual alternative without relying on optional
browser support for description tracks. A future audio edition must supply a
separate reviewed captions file before enabling its captions control.

### Props

| Prop | Type / default | Purpose |
| --- | --- | --- |
| `ready` | `boolean`, default `false` | Explicit permission to play after the age gate is resolved and cleared. |
| `durationSeconds` | optional `number` | Verified duration before metadata arrives. Actual loaded metadata takes precedence. No duration is invented if omitted. |
| `transcript` | optional `string \| readonly string[]` | Reviewed visual description or transcript. A string is split at blank lines. No default transcript is invented. |
| `transcriptLabel` | `string`, “Read the film description” | Use “Read the transcript” only when supplying a verified transcript. |
| `hasAudio` | `boolean`, default `false` | Show a working sound toggle only for a verified edition that contains audio. Playback starts muted. |
| `hasCaptions` | `boolean`, default `false` | Include a captions track and control only when actual reviewed captions exist. |
| `src` | `/media/academy-promo.mp4` | Versioned film URL; the exact source string is its once-per-tab identity. |
| `poster` | `/media/academy-promo-poster.webp` | Safe logo/end-card poster. |
| `captionsSrc` | `/media/academy-promo.vtt` | Optional reviewed WebVTT captions; not requested when `hasCaptions` is false. |

The visible label is “Academy brand film” with a duration/edition subtitle, such
as “25-second silent brand film”. Duration labels round to a whole second;
the progress control uses the actual fractional duration.

## Playback policy

There is no HTML `autoplay` or `loop` attribute. The controller may start muted
automatic playback only when all of these conditions hold:

- `ready` is true;
- at least 35% of the video rectangle is on screen;
- the browser tab is visible;
- the document root has `data-motion="on"`;
- the operating system does not request reduced motion;
- this film has not already started in this browser-tab session, unless this is
  the same mounted automatic run resuming after a temporary pause;
- playback has not ended, failed, been explicitly paused, or had automatic
  playback blocked by the browser.

Explicit Play or Replay can override the motion preference for that viewing
session, including an OS reduced-motion setting. It cannot override the age gate
or visibility requirements. A new global Pause or device reduced-motion change
stops an already playing manual session; the user can choose Play again under
the new preference. Scrolling away or hiding the tab pauses playback. An
explicitly watched film stays paused when the user returns; a muted automatic
film may resume if its conditions are satisfied. The film stops at its end and
offers Replay instead of looping.

### One automatic viewing per film and tab

The first actual `playing` event records the film, after the playback policy has
accepted it. Waiting at the adult gate, a hidden tab, reduced motion, loading,
or a rejected `play()` promise does not count as a viewing. A successful manual
viewing also records the film so returning to the page does not trigger an
unsolicited automatic viewing. Play and Replay remain available afterward.

The record uses `sessionStorage` under `fsa:promo-played:v1:` plus the exact
`src`. Returning through client navigation or refreshing the page in the same
tab therefore leaves an already-started film paused. Publish replacement media
at a new versioned URL to give that distinct film its own automatic viewing.
Changing source also resets playback/error/caption state and the media element;
the old source's listeners and pending operations are cleaned up.

An interrupted automatic run can resume in the same mounted player when its
visibility and motion conditions return. It continues from its existing time;
it does not restart. Navigating away ends that mounted run, even if the viewer
left before the film finished. Returning afterward requires explicit Play.

Storage access and writes are guarded. A module-memory set preserves the same
behavior through in-page navigation if storage is unavailable. In that fallback,
a full page reload creates fresh memory and may permit another automatic run;
persistence across reloads cannot be guaranteed when the browser denies storage.
Only film source strings and a started flag are stored; no learner identifier
or viewing progress is recorded.

`data-motion="off"` alone is not sufficient to represent the age gate: that
value also represents user or system motion preferences. Always pass `ready`
separately. The controller observes the root attribute and system media query;
it does not change the global motion preference.

## Controls and alternatives

- Play/Pause and Replay operate the actual HTML video element. Playing state
  follows media events instead of a simulated timer. The poster-overlay Play
  action moves focus to the persistent playback control before the overlay
  disappears; automatic playback does not begin while a player control is focused.
- A labelled native range input seeks through the actual duration and reports
  its position to assistive technology.
- Fullscreen is offered when a relevant browser API is available, with a native
  iOS fallback where supported. An iframe/browser permission refusal leaves the
  inline player available with a readable message.
- Sound is an explicit control only when `hasAudio` is true. There is no voice,
  narration, or sound claim for the silent edition.
- Captions and their control are absent unless `hasCaptions` is true. A failed
  captions request leaves the reviewed written alternative available.
- The poster remains visible before playback. A media failure keeps a poster
  fallback, retry action, and the written alternative.
- Browser refusal of automatic playback becomes a normal Play invitation.
- The reviewed description is a native disclosure, available without playing.
- Before client enhancement, native video controls are available only when
  `ready` has already been established. While `ready` is false, the element has
  no native controls, is outside the tab order, and exposes no fallback video
  link. There is never an autoplay attribute. If JavaScript fails before the
  adult-entry check resolves, the poster and written alternative remain usable
  while playback remains gated. The surrounding application retains its existing
  JavaScript requirements for the age declaration and account features.

Event listeners, observers, queued animation frames, and stale play requests are
cleaned up on source/readiness changes or unmount. Cleanup pauses the media.

## Verification boundary

`node tests/promo-playback.test.mjs` exercises the actual policy/session helper:
gate and motion waiting, visibility resumption, same-tab revisit and reload,
distinct versioned sources, explicit viewing/replay, end-of-film stopping,
rejected autoplay and denied/read-only storage. These are focused policy and
session regression checks, not a media decoder or browser test. This is not a claim of browser
verification. In the approved browser, verify gate-before-play, default muted
playback, explicit reduced-motion Play, global Pause, scrolling and tab changes,
Play/Replay/seek, rejection/error fallback, mobile controls, and fullscreen
permission behavior. Confirm the final MP4 actually has the release's intended
audio state and that its description matches the supplied visual content.
