# Fleshsesh Academy: subscription and micropayment model

Prepared 17 October 2026. AUD throughout. This is a launch recommendation and a transparent planning model, not a revenue forecast or processor approval.

## Recommended offer

Launch with a genuinely useful free path, a A$19 membership and an optional A$29 higher-use membership. Make the full written curriculum and fair assessment the central value. The existing LMS describes written lessons as complete, but audio/video as not produced and clinical/legal review as incomplete. A cinematic interface must not imply a finished video catalogue.

| Offer | Price | What the buyer receives |
|---|---:|---|
| Explore | Free; no card | Consent foundation, previews, glossary, progress/badges, help information; up to 10 tutor replies/month if live tutor service is available |
| Academy | A$19/month or A$190/year | All released written modules/electives, workbook, assessments with unlimited retries, eligible completion certificate and 50 tutor replies/month |
| Academy Plus | A$29/month or A$290/year | Academy features, 200 tutor replies/month and optional structured learning plans |
| One module | A$7 once | Named module's lessons, scenarios and knowledge checks; relevant for people who prefer no subscription |
| Tutor booster | A$5 once | 50 additional replies; explicit purchase with a visible remaining-use counter |
| Standalone toolkit | A$5 once | Future optional SKU only after a separate useful download exists; never charge members again for the included workbook |

Annual Academy saves A$38 against 12 monthly payments; annual Plus saves A$58. Both are 16.7% lower than the twelve-month monthly total. Display **A$190 billed yearly** / **A$290 billed yearly** prominently. A$15.83 and A$24.17 per-month equivalents are explanatory figures, not the amount charged monthly.

Price the tutor's learning help, not emotional attachment or access to essential safety information. The tutor should stay within the sourced curriculum, label itself AI, use fictional examples, distinguish education from diagnosis/advice, and avoid erotic roleplay. Keep source grounding and reply-length/usage limits to control cost. The cost allowances below are planning inputs, not a quotation from an AI provider.

## How recurring revenue stays worth paying for

The launch course can be completed, so membership renewal needs continued learning value. Build a transparent release calendar around refreshed scenarios, optional learning plans, evidence updates and new modules that are actually published. Let learners revisit their course history and certificates after cancellation. A person who has finished should be able to leave easily and return when there is something useful to study.

Track activation (one lesson and one knowledge check), completion, retained paid members, tutor cost per active member, refund/dispute rate and revenue per active learner. Compare monthly and annual plans using net revenue and retention. Do not use a fabricated popularity count, fake reviews, countdown discounts or private sexual-health conversations to drive an upsell.

Use private XP for completing lessons, trying again and progressing through knowledge checks. Badges should describe learning milestones, never certify that a learner is a safe partner or competent clinician. Keep participation optional; no public sexual-knowledge leaderboard, paid streak repair, paid exam retries or purchasable completion badges.

## Micropayments: direct items, not a money wallet

Use named items charged directly through hosted checkout. One order may contain several low-price products, reducing fixed processing costs. At the current domestic card rate, a A$1 payment consumes about A$0.32 in processing, whereas A$5 costs about A$0.38 and A$7 costs about A$0.42, before any separately applicable product fee. This is why A$5–A$7 purchases are more workable than repeated cents-level charges. [S01]

A module SKU grants that specific module; a tutor booster grants a fixed number of responses. Neither is a cash balance. Do not add transfers, cash-out, marketplace payouts or a generic stored-value account at launch. This avoids unnecessary payment-product complexity; it is not a claim that every prepaid entitlement is legally exempt. If a wallet is introduced later, obtain product-specific advice and processor approval before implementing it.

Monthly included replies reset on the stated billing date; purchased booster replies should remain after membership cancellation. Use included replies first, then the oldest purchased allowance. Show exactly what a reply means; do not deduct quota for failed requests. Never auto-rebuy. Recommend no expiry while the service operates, with clear continuity/refund handling. Do not label a module 'lifetime access' without defining and being able to honour that promise.

## Payment provider and Australian checkout constraints

Stripe's current Australian public card pricing is **1.65% + A$0.30 domestic** and **3.5% + A$0.30 international**; domestic card fees shown include GST. Stripe Billing's pay-as-you-go rate is **0.7% of billing volume**. Other features can add fees. The model adds a 10% GST provision to Billing fees and does not claim input credits, making the expense treatment conservative. Confirm the actual account invoice. [S01, S10]

Stripe prohibits adult services and content intended for sexual gratification, including qualifying AI content. Its written policy does not provide blanket acceptance simply because a seller uses the term sex education. The Academy's actual curriculum, imagery, AI behaviour, parent-brand links and business model must be disclosed accurately. Use a provider-neutral checkout adapter; live collection remains conditional on an accepted merchant account. Do not disguise or relabel prohibited material to obtain processing. [S02]

For Australian buyers, show inclusive AUD totals and renewal terms before the pay button, with no preselected add-ons. ACCC guidance requires taxes and unavoidable fees in the displayed total. It also states that Visa, Mastercard, American Express and eftpos card surcharges stopped from 1 October 2026: absorb processing in the displayed price. [S03]

Make the renewal date, amount and cancellation effect unambiguous. A monthly buyer can cancel renewal from Settings; an annual buyer sees that A$190/A$290 is paid upfront and that cancelling renewal retains access to the current term's end. Send confirmation and a renewal reminder. Those are recommended product choices; this report does not assert a universal statutory reminder period. The ACCC's recent eHarmony case reinforces the risk of obscured auto-renewal, misleading cancellation promises and headline monthly equivalents that conceal the required total. [S04]

Do not use a blanket 'no refunds' promise. The refund policy should preserve Australian Consumer Law rights and distinguish an ordinary change of mind from a service failure. [S09]

Treat GST as a real provision until the seller's registration and supply treatment are confirmed. The standard business registration threshold is A$75,000 GST turnover, assessed with actual/projected turnover; consider the whole supplying entity. Adult learning is not automatically GST-free: the ATO describes eligibility conditions for ACE courses/providers. The model assumes registration and taxable supplies rather than inventing an exemption. [S06, S07]

## Completion certificates

The supplied course explicitly states non-accredited education. Use **Certificate of Completion** with issuer, course version, learner name/alias policy, award date, unique verification ID, and an accurate assessment record. Display **Non-accredited education; not a professional qualification** in the credential flow and sales FAQ. Do not claim ASQA/AQF recognition or use regulated qualification titles or NRT branding. Obtaining external accreditation is a separate regulated pathway. [S05, S08]

## Illustrative monthly economics

The scenarios count **active paying subscribers**, not visitors. Plan mix is 75% Academy and 25% Plus, all billed monthly. For every paid member the model assumes three additional active free learners; 10% of those free learners buy one A$7 module/month, and 10% of members buy one A$5 tutor booster. Subscribers are never charged for a module already included in their plan. The toolkit candidate is excluded from revenue.

Each scenario subtracts GST, domestic-card processing, Billing plus its GST provision, a 2% refund/dispute reserve, and delivery allowances: A$2/Academy member, A$4/Plus member, A$0.10/active free learner, A$0.05/module order and A$0.75/booster. These allowances cover variable service consumption; they must be replaced with observed costs.

| Paying members | Subscription receipts | One-off receipts | Total cash collected | Revenue ex GST | Contribution after variable costs | After A$2,000 operating allowance |
|---:|---:|---:|---:|---:|---:|---:|
| 100 | $2,150 | $260 | $2,410 | $2,191 | $1,755 | $-245 |
| 500 | $10,750 | $1,300 | $12,050 | $10,955 | $8,777 | $6,777 |
| 1,000 | $21,500 | $2,600 | $24,100 | $21,909 | $17,554 | $15,554 |

The final column is **not take-home profit**. It excludes marketing/customer acquisition, founder pay, income tax, setup costs, newly commissioned media, one-off specialist review, foreign-card uplift and payment-provider reserves. Free learner counts are 300, 1,500 and 3,000 respectively, so total active learners are 400, 2,000 and 4,000. Each conversion and purchase-rate assumption needs measurement.

At these inputs, contribution is about A$17.55 per paying member, including the associated free-learning population. Approximately **114 paying members** cover the A$2,000 allowance before the excluded costs. An extra A$3,000/month for owner pay and marketing raises the threshold to about **285 paying members**. This is arithmetic under stated assumptions, not a growth prediction.

Annual upfront payments improve timing of cash, but annual revenue must be spread across the service term for monthly comparisons. A$190 received today is not A$190 MRR. Foreign cards, higher tutor use, acquisition costs, churn, clinical review and video production can materially change the outcome. Avoid scaling paid acquisition until actual retention and service cost support it.

## Build integration

Keep the product catalogue and allowed price IDs on the server. Grant or revoke paid entitlements from verified, idempotent payment events; never from a browser redirect or editable local state. Track purchases separately from subscriptions, consume tutor quota atomically, and show receipts and cancellation dates. Keep test/demo purchases clearly separate from live charges and provide a graceful response when live payment or AI credentials are absent.

## Primary sources

- **S01 — Stripe Australia pricing**. [Official source](https://stripe.com/au/pricing). Retrieved 2026-10-17. Domestic card 1.65% + A$0.30; international 3.5% + A$0.30; displayed card fees include GST; Billing 0.7% of volume; extra products separately priced.
- **S02 — Stripe prohibited and restricted businesses**. [Official source](https://stripe.com/au/legal/restricted-businesses). Retrieved 2026-10-17. Prohibition on adult services and mature audience content intended for sexual gratification, including qualifying AI content. Educational labelling is not an approval.
- **S03 — ACCC price displays**. [Official source](https://www.accc.gov.au/consumers/pricing/price-displays). Retrieved 2026-10-17. Show minimum total including unavoidable charges/taxes prominently. Card surcharges on Visa, Mastercard, American Express and eftpos prohibited from 1 October 2026.
- **S04 — ACCC: eHarmony renewal and subscription pricing findings**. [Official source](https://www.accc.gov.au/media-release/court-finds-eharmony-engaged-in-misleading-conduct-in-relation-to-automatic-renewal-and-pricing-of-its-subscriptions). Retrieved 2026-10-17. Clear pricing, duration, automatic renewal and cancellation statements; annual minimum total cannot be obscured by monthly equivalents.
- **S05 — AQF accreditation and certification of qualifications**. [Official source](https://www.aqf.edu.au/help-qualifications/accreditation-and-certification-qualifications). Retrieved 2026-10-17. Non-AQF qualifications lack government quality assurance/accreditation and should not use AQF titles.
- **S06 — ATO: GST and adult and community education courses**. [Official source](https://www.ato.gov.au/businesses-and-organisations/gst-excise-and-indirect-taxes/gst/in-detail/your-industry/gst-and-adult-and-community-education-courses). Retrieved 2026-10-17. GST-free ACE supplies require applicable course/provider eligibility; education is not automatically GST free.
- **S07 — ATO: registering for GST**. [Official source](https://www.ato.gov.au/businesses-and-organisations/gst-excise-and-indirect-taxes/gst/registering-for-gst). Retrieved 2026-10-17. Businesses need to assess actual and projected GST turnover; standard threshold A$75,000.
- **S08 — ASQA: course accreditation**. [Official source](https://www.asqa.gov.au/for-providers/course-accreditation). Retrieved 2026-10-17. Accredited courses meet regulated national standards; issuing a platform completion document is not this process.
- **S09 — ACCC: repair, replace, refund, cancel**. [Official source](https://www.accc.gov.au/consumers/problem-with-a-product-or-service-you-bought/repair-replace-refund-cancel). Retrieved 2026-10-17. Consumer guarantees can provide remedies including refund/cancellation; a blanket no-refunds condition is unsuitable.
- **S10 — Stripe: taxes on fees for Australia-based businesses**. [Official source](https://support.stripe.com/questions/taxes-on-stripe-fees-for-australia-based-businesses). Retrieved 2026-10-17. GST applies to Stripe fees unless pricing is GST inclusive. Model adds GST to Billing fee provision and does not claim input credits.
