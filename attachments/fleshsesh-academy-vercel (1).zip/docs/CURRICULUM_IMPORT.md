# Fleshsesh Academy content integration notes

## Supplied source set

All six uploaded files were read from their supplied scratch copies. No attachment was re-fetched through Library. The uploaded originals are unchanged. SHA-256 hashes and original file sizes are recorded in `content-manifest.json`.

| Source | Observed structure | Integration role |
| --- | --- | --- |
| Fleshsesh_Academy_LMS_Content(1).json | Schema 1.0, complete course metadata, orientation, 18 modules, capstone, worksheets, glossary, references | Primary structured text and assessment source |
| Fleshsesh_Academy_Question_Bank(1).xml | Moodle quiz XML; 20 categories, 114 multiple-choice questions | Independent structured cross-check of every assessment prompt, option, answer and feedback |
| Fleshsesh_Academy_Curriculum(1).pdf | 110-page educator edition | Curriculum explanation, tutor system and role prompts, tool contracts, acceptance cases, source register |
| Fleshsesh_Academy_Learner_Workbook(1).pdf | 14 pages | 10 optional private worksheets plus fictional planning task and preparation rubric |
| Fleshsesh_Academy_Certificate_Template(1).pdf | One page, explicitly TEMPLATE / NOT ISSUED | Credential fields and mandatory non-accredited wording; does not establish an award |
| Fleshsesh_Academy_Platform_Plan(1).pdf | 28-page authoring edition, 17 October 2026 | Access, privacy, assessment, AI roles, release, commercial and accessibility requirements |

The source pack consistently identifies its state as a complete written authoring edition awaiting specialist review and implementation. Its clinical and legal review flags are false. A polished implementation must not silently change those flags to approved or imply that the source pack establishes external accreditation.

## Normalized outputs

`catalog.json` is learner-safe course data. It contains course metadata, all 48 full teaching texts, orientation, objectives, reference links, 18 module records, 10 worksheets and 22 glossary definitions. Original teaching text is preserved exactly in each lesson's `content`. The same teaching paragraphs are exposed individually in `sections` for a reader UI. Lesson `reflection` fields are optional and explicitly declare `persistence: "none"`. The catalog contains no question text, options, correct indices, feedback keys, scenario answer keys, or planning model response.

`assessments.json` is **server-only**. It contains 114 original assessment questions, 48 additional ungraded practice scenarios, all answer keys and feedback, the applied case/rubric/model response, completion rules, and 68 assessment definitions. These are 48 lesson practice checks, 18 module checks, one capstone and one applied-planning check. A question can belong to a lesson practice check and its module check; this does not create a second question. Never place this file in `public`, export it as a client module, use it as a browser data fixture, or give it to the tutor model. The server can deliver authorised question fields and release feedback after submission.

`tutor-guidance.json` contains the actual shared system prompt and three role instructions from the educator PDF, plus the 18 source acceptance cases. These are configuration and evaluation inputs; they do not represent a connected or validated AI service.

`content-manifest.json` records provenance and validation. `normalize.py` and `extract-tutor.py` reproduce the intermediate normalization; they are not product application code.

## Stable identifiers and structure

All original module, lesson, question, worksheet and reference IDs are retained. Module test IDs are newly assigned with a predictable `-TEST` suffix. Lesson practice checks use `-CHECK`, and ungraded practice scenarios use `-SCENARIO`.

| Module | Kind | Lessons | Module check |
| --- | --- | --- | --- |
| C01 Consent and autonomy | Core | C01-L01 to C01-L03 | C01-TEST |
| C02 Communication and boundaries | Core | C02-L01 to C02-L03 | C02-TEST |
| C03 Bodies, anatomy and normal variation | Core | C03-L01 to C03-L03 | C03-TEST |
| C04 Desire, arousal, pleasure and solo wellbeing | Core | C04-L01 to C04-L03 | C04-TEST |
| C05 Safer sex, sexual health and contraception | Core | C05-L01 to C05-L03 | C05-TEST |
| C06 Relationships and agreements | Core | C06-L01 to C06-L03 | C06-TEST |
| C07 Inclusive intimacy | Core | C07-L01 to C07-L03 | C07-TEST |
| C08 Access and changing bodies | Core | C08-L01 to C08-L03 | C08-TEST |
| C09 Exploring interests and kink literacy | Core | C09-L01 to C09-L03 | C09-TEST |
| C10 Digital intimacy | Core | C10-L01 to C10-L03 | C10-TEST |
| C11 When sex is difficult | Core | C11-L01 to C11-L03 | C11-TEST |
| C12 Putting learning into practice | Core | C12-L01 to C12-L03 | C12-TEST |
| E01 Practical intimacy and pleasure | Elective | E01-L01 to E01-L02 | E01-TEST |
| E02 Sexual activities and health | Elective | E02-L01 to E02-L02 | E02-TEST |
| E03 Nonmonogamy and shared settings | Elective | E03-L01 to E03-L02 | E03-TEST |
| E04 Kink negotiation and power | Elective | E04-L01 to E04-L02 | E04-TEST |
| E05 Dating and digital choices | Elective | E05-L01 to E05-L02 | E05-TEST |
| E06 Intimacy through change and access | Elective | E06-L01 to E06-L02 | E06-TEST |

Each module preserves the supplied prerequisite module IDs. These should affect an assessed learning route without blocking urgent support or basic health information. Every lesson is estimated at 15 minutes. The source does not require a forced timer.

## Exact certificate rules

The core course is 600 planned minutes: 20-minute orientation, 36 core lessons at 15 minutes each, and a 40-minute capstone including applied planning. Six optional two-lesson electives add 180 minutes. Full catalog time is 780 minutes, approximately 13 hours. Audio/video alternatives must not be added again to these totals.

The authoritative completion service should check:

1. Orientation acknowledgements are complete.
2. All 36 core lessons have trusted completion records.
3. Each of 12 core module tests has a passing server-scored attempt of at least 5/6.
4. CAP01 has at least 10/12 correct and resolves every safety-critical item: CAP01-Q01, CAP01-Q02, CAP01-Q03 and CAP01-Q04. The normalized rule requires these four to be correct in the passing attempt, avoiding ambiguous aggregation of partial attempts.
5. PLAN01 has 6/6 correct, or an authorised human reviewer confirms all six rubric criteria for a submitted fictional written alternative. A self-check or AI opinion cannot substitute for human review of that alternative.
6. Issue one idempotent credential per learner/course edition. An issued record, not a model-generated sentence or browser progress flag, establishes issuance.

Electives are optional for the core certificate. Each elective requires 4/4 for its separate completion record. Lesson practice checks and scenario scores cannot substitute for the required module tests. Retries are unlimited with feedback. No sexual activity, personal history, intimate uploads, partner testimony or persisted reflection is required.

The source award title is **Assessed Certificate of Completion in Adult Sexual Wellbeing Foundations**, issued by Fleshsesh Academy. Include this limitation verbatim or in substantively identical words: “Non-accredited adult education. This certificate does not represent an AQF qualification, VET Statement of Attainment or professional licence.” Do not invent an RTO number, CPD recognition, accreditation badge, practitioner status, national course code, or government approval. Do not imply a certificate guarantees future consent, safe behaviour or professional competence.

Verification should use an unguessable learner-shared token, minimum necessary award information, and no searchable public directory. The supplied certificate file is a sample, not an issued learner credential.

## Claims that need careful presentation and review

These are observations about supplied content and its explicit review requirements, not independent legal or clinical verification. The 88 source-register entries were preserved, including the source author's access dates. They have **not** been independently rechecked as part of this local normalization task.

| Topic | Source location | Integration implication |
| --- | --- | --- |
| Consent, capacity and withdrawal | C01; A01–A06; R02 | Present the Academy ethical standard separately from jurisdiction-specific law. A disability or communication aid alone does not imply incapacity. Never frame a previous yes or bodily response as present agreement. |
| Age access | Platform Plan pp11–12 | 18+ is the Academy's admission policy. The source explicitly says an age checkbox alone does not establish regulatory compliance. Service/content classification and proportionate assurance remain release work. |
| Anatomy, symptoms and body variation | C03, C08, C11 | Use educational text, individual clinical referral, and exact source references. Do not create AI-generated anatomical images as an authoritative replacement for reviewed diagrams. |
| Emergency contraception and HIV PEP timing | C05-L03; A27, A28, A34 | These are time-sensitive clinical facts in the source. A clinician must review wording and source currency before public release; a tutor must not prescribe or delay urgent advice. |
| Barrier use, testing and U=U | C05-L01–L02; A23–A26, A34, R17 | Preserve qualifications and clinical context; avoid a universal safety guarantee. |
| Neck compression/strangulation | C09-L03; B12 | The source warns against the activity and directs medical help. Never turn the lesson into technique instruction or imply a stop word removes injury risk. |
| Rectal foreign body/anal injury | E02-L02; R11, R16 | Keep professional emergency referral. Do not substitute extraction instructions or automated diagnosis. |
| Sexual violence/coercive control | C06, C11, C12; A31, B20–B22 | Support choice, avoid blame and avoid forcing joint discussion or disclosure. A tutor is not an emergency monitor or investigator. |
| Intimate images/AI likeness | C02-L03, C10; A08–A09, B13–B16 | Keep separate consent for creation, storage, sharing and AI use; prevent intimate learner uploads and unnecessary personal-data collection. |
| Privacy and marketing | Platform Plan pp12, 14, 19 | Collect minimal account/progress/entitlement data, separate marketing opt-in, and never use sexual-health learning or chat for targeted product upsells. Avoid false anonymity or confidentiality claims. |
| Payments, renewal and refunds | Platform Plan pp14–15; R07–R08 | Clearly show currency, total price, billing interval, access period, auto-renewal and cancellation. Consumer guarantees cannot be removed by blanket no-refund language. Provider acceptance of actual content is unverified. |
| Accreditation | Curriculum pp97–100; Platform Plan pp21–24; K01–K10 | Current program is non-accredited. An RTO pathway requires separate scope, approval and assessment work. Passing these quizzes is not VET recognition. |

## UX, gamification and format guidance

The source permits clear progress and a return-to-lesson shortcut. Its position is against competitive public leaderboards, public sexual-wellbeing badges, streak penalties, partner scores or sexual-proficiency ratings. Private XP and optional learning milestones can support the user's gamification request while respecting this intent. Pauses must not reset achievements. Learning completion should reward understanding, never sexual activity or disclosure.

The pack has 48 teaching texts. It explicitly marks audio and video as **not produced**. Show a reading route now; only offer Listen or Watch after a real accessible asset exists. Do not label lesson scripts as existing video, imply actors are clinicians, or invent testimonials. Reduced motion, visible focus, keyboard operation and readable contrast remain product requirements.

The source's brand description is pink and gold with warm white lesson reading surfaces, dark text and restrained deep-pink accents. Gold is decorative unless contrast is checked. The six uploaded attachments contain no source logo file, exact brand hex values, or specified brand font. The new cinematic aubergine/terracotta/peach asset palette is a project design extension, not a claim that those were supplied brand tokens.

The source commercial proposal begins with free essentials and a complete paid course, then tests recurring value. The user's newer subscription and micropayment request governs the new commercial design. Keep consent basics, urgent health information and support accessible without payment. Do not promise recurring new lessons, live educator sessions, unlimited AI, or staffed support until those services are actually provisioned and costed. An economics forecast must state assumptions rather than describe hypothetical revenue as achieved income.

## Validation performed

- Exactly 18 modules and 48 original lesson IDs; original text reconstructed identically from normalized paragraph sections.
- All 114 Moodle questions matched the JSON prompt, ordered options, correct index and feedback exactly; zero mismatches.
- 48 ungraded practice scenarios retained separately from the 114 assessment items.
- All lesson/question references resolve to the 88 supplied source IDs; all prerequisite IDs resolve to supplied modules.
- Module and course time estimates reconcile to 600 minutes core and 780 minutes with all electives.
- Public catalog recursively checked to exclude assessment question arrays, answer indices, answer options, question feedback and planning model response.
- Every private worksheet and lesson reflection explicitly declares no persistence by default.
- Original false review/accreditation fields remain false; source references are labelled as not independently reverified.

This validates the transformation and provenance, not the clinical accuracy, legal compliance, accessibility, production backend, payment processing, live AI or accreditation of the completed platform.


## Editorial revision 1.1

The initial-import evidence above describes the supplied 1.0 files. Current content now follows the audited 1.1 seed, with 19 revised assessment items, six updated lesson records and three added health sources. IDs, correct indices and completion thresholds are retained. See `CURRICULUM_AUDIT_2026-10-17.md` and the `currentEdition` manifest entry for the changes, evidence and retained learner-progress policy.
