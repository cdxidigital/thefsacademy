# Promo media — A new chapter

## Current release

The 25-second curriculum promo replaces the previous landing-page film. It uses **entirely new generated footage**, animated curriculum titles and the supplied glossy Academy logo. No footage from the earlier performer montage is reused.

The landing player receives `/media/academy-new-chapter-v2.mp4`, its matching poster, `durationSeconds={25}`, `hasAudio={false}` and a reviewed written description. The versioned URL gives this new film a separate once-per-tab playback identity. See `PROMO_PLAYER.md` for playback gates and the browser-testing boundary.

## Provenance

- Original footage: Kling 3.0 through Higgsfield, Pro mode, 16:9, 15 seconds requested, sound off.
- Completed job: `2d490d85-921b-4ff2-8708-0aef4551f879`, generated 17 October 2026.
- Original file: `design/promo-originals/campus-film-source.mp4`, retained unchanged.
- The campus and adult learners are fictional AI-generated imagery. They are not an actual campus, staff, testimonials, a recorded class or a demonstration of live AI.
- The supplied logo is `public/brand/glossy-master.png`; its original proportions and lettering are preserved. Typography uses the supplied Inter font and Academy Ink, Paper, Blush and Brass colours.
- Exact text was added after generation. Counts come from `data/catalog.json`; role names come from `data/tutor-guidance.json` and the implemented tutor configuration.

## Curriculum and sequence

| Approximate time | Picture and message |
| --- | --- |
| 00:00–00:05 | Camera enters a warmly lit campus library through a charcoal-and-brass arch. “Your curiosity belongs here.” **Know more.** Consent, bodies and sexual wellbeing. |
| 00:05–00:10 | Three fully clothed fictional adults converse around a lounge table. “Open minds. Better connections.” **Feel more.** Communication, boundaries and relationships. |
| 00:10–00:14 | An open book, brass ribbon sculpture and softly glowing pink orb. “Learn at your own pace.” **Be you.** Identity, inclusion and informed choice. |
| 00:14–00:20 | Animated curriculum card: Adult Sexual Wellbeing Foundations; **48 written lessons**, **18 modules**, 12 core modules and 6 elective deep dives. Names the Foundations Tutor, Practice Coach and Assessment Tutor. Fictional practice, knowledge checks and private progress. |
| 00:20–00:25 | Supplied glossy logo. “There is room for your questions.” “Know more. Feel more. Be you.” “Your next chapter starts here.” “Non-accredited adult education · 18+.” |

Counts were checked directly against the catalog: 18 modules, of which 12 are core and 6 elective, containing 48 written lessons. The film does not claim video lessons, external accreditation, live payments or a connected generative tutor.

The publication also incorporates curriculum revision 1.1. Its lesson/source and assessment edits preserve these counts and topics; the promo was checked against the revised online catalog before release.

## Measured export

| Property | Value |
| --- | --- |
| Duration | 25.000 seconds |
| Picture | 1920 × 1080, 16:9, progressive |
| Video | H.264 High, Level 4.0, YUV 4:2:0 |
| Rate | 24 fps; 600 frames |
| Audio | No audio stream; intentionally silent |
| File size | 4,377,924 bytes |
| Faststart | `moov` at byte 32, before `mdat` at byte 8,157 |
| Poster | Actual closing frame at 24 seconds; WebP, 1920 × 1080, 101,936 bytes |

A complete FFmpeg decode passed. Representative frames from all three scenes, the curriculum card, fades and closing card were visually inspected. The poster was inspected at full size. A contact sheet and machine-readable verification are retained in `docs/media/`. This does not claim interactive browser playback testing.

The text alternative is shown in the player's “Read the film description” disclosure. Downloadable copies are `academy-new-chapter-v2-transcript.txt` and `academy-new-chapter-v2.vtt`. The WebVTT contains **visual descriptions**, not dialogue captions. Audio and captions controls remain absent.

## Reproduction

Run from the project root with FFmpeg and Python fontTools installed:

    python scripts/render-brand-promo.py \
      design/promo-originals/campus-film-source.mp4 \
      public/media/academy-new-chapter-v2.mp4 \
      /tmp/academy-promo-render

    ffmpeg -hide_banner -loglevel error -nostdin -y \
      -ss 24 -i public/media/academy-new-chapter-v2.mp4 \
      -frames:v 1 -an -c:v libwebp -quality 92 \
      public/media/academy-new-chapter-v2-poster.webp

The renderer writes a candidate file first, probes its duration, size and stream type, then replaces the published asset. It preserves the original footage and source logo. It uses original scene timing, a fade to the curriculum card, separately eased title entrances and a closing logo fade.

## Integrity

| Asset | SHA-256 |
| --- | --- |
| Original new footage | `7c8d8776b59b1c4c11425ec79618ae83a271fd8cfae4b49e661198827891a7d9` |
| Final MP4 | `2374efdc7c7ea95d6a9897e84ca96167bba7b997458f6d18c58116aaf8fe0109` |
| Final poster | `576a55a899f02a34ee0903d510d1cfa979f70c212e3b57911b373e68aa190a02` |

## Previous edition

The earlier supplied performer montage remains in version history and in the older `academy-promo.*` assets. The landing page no longer references it. Its 15.041667-second silent web export had SHA-256 `516bd337c30d2028741d5506f1406a677195c0fd4bf3b387bf03f73df0ae9b86`. The previous source review is recorded in the preceding repository version; this release does not reclassify that original footage as newly generated.
