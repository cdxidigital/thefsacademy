# Vercel export verification — 17 October 2026

## Result

The standalone Vercel source export passed a clean locked dependency install, TypeScript checking, native Next.js production compilation, static generation and server trace collection. It has not been deployed to a Vercel account in this task.

| Check | Result |
| --- | --- |
| `npm ci --no-audit --no-fund` | Passed; 574 packages installed from the included lockfile |
| `npm run typecheck` | Passed |
| `npm run build` | Passed, using Next.js 16.4.2 and Node.js 24.19.0 |
| `npm test` | All 11 suites passed: 118 passing checks, zero failures, one explicit source-parity skip |
| Production dependency audit | Zero known reported vulnerabilities after the database client's `ws` dependency was patched to 8.22.0 |
| Curriculum, media, original art and migrations | 71 files match the released source byte for byte |
| Basic credential-pattern scan of export source | No hard-coded private credentials detected; only an empty-key `.env.example` is included |

The local build emitted a metadata-base warning because no deployed origin was configured during verification. Configure the deployment's origin and provider domains as described in the setup guide. The build completed successfully.

## Automated coverage

| Suite | Passed |
| --- | ---: |
| Backend APIs | 11 |
| Isolated Plus demo APIs | 9 |
| Demo interface | 4 |
| Learner entry, lessons, assessments and membership interface | 15 |
| Tutor roles and boundaries | 31 |
| Tutor client behaviour | 5 |
| Promo playback state | 9 |
| Account refresh and error recovery | 9 |
| Curriculum scope, scoring, answer-order and disclosure rules | 4 |
| Actual local libSQL storage adapter and migrations | 7 |
| Vercel/Clerk auth modules, routes, redirects and sign-out | 14 |
| **Total** | **118** |

The single skipped curriculum check compares the current online edition to a separate audited authoring JSON export that was not available in this workspace. The current edition 1.1 content, all 18 modules and 48 lessons were preserved exactly. The remaining curriculum checks ran, including all 5,024 correctness patterns and 2,736 displayed-answer orders.

The backend suites execute actual route handlers and the new Node runtime. Clerk session/profile transport, the runtime database fixture and external payment/AI transport are mocked. They do not authenticate test users through caller-supplied native hosting headers.

The database suite also executes the real `@libsql/client` adapter against explicitly local isolated SQLite. It verifies prepared values, named rows, changes metadata, atomic quota/credit writes, foreign-key cascades, rollback of payment-style batches, correct migration order, idempotent migration history, checksums, and rollback of the entire pending schema/ledger if a later migration fails. The configuration check confirms that production chooses the HTTP client and rejects local filesystem persistence; it makes no remote database request.

Auth checks verify that missing keys cannot grant access, spoofed old identity headers are ignored, session/profile identifiers must match, return paths stay on local Academy routes, sign-in and sign-up are distinct, unconfigured pages explain availability, and sign-out requires an explicit SDK action with retry/duplicate handling. The dark theme uses the installed Clerk Core 3 variable names and passes the actual TypeScript declarations.

## Export changes

- Replaced the Vinext/Cloudflare build with the native Next.js build used by Vercel.
- Replaced the hosting-only identity headers with verified Clerk sessions and real account routes. Compatibility URL names remain navigation aliases only.
- Replaced the D1 runtime binding with a Turso/libSQL HTTP adapter while preserving the existing SQLite queries, data schema and transaction behaviour.
- Kept the supplied brand, curriculum, promo, demo isolation, ownership checks, assessment rules and payment/AI release switches.
- Included explicit database migrations and deployment instructions. Migrations do not run during build or page requests.
- Removed original hosting configuration and runtime artifacts from the exported package. No existing database or learner records were exported.

Reference source: Sites release commit `8499d5ce9ec14338cec750b0a0647da588957067`. The original hosted repository remained unchanged while this independent export was prepared.

## Verification limits

No live Clerk application/session, remote Turso database, Stripe checkout/webhook or OpenAI model was exercised. These require the owner's provider configuration. Actual signed-in browser journeys, responsive rendering, hydration and video playback on the new Vercel deployment still need connected deployment checks; this task did not publish a Vercel preview.

No approval flag was enabled. The three tutor roles work as curriculum guides once identity and storage are configured; optional live AI and real payments remain controlled by the existing release settings. The private Plus demo remains independent of paid processing and always uses curriculum guides.

The included dependency audit is a point-in-time known-advisory report, not a guarantee that every possible application or dependency vulnerability has been excluded.

See `DEPLOY_TO_VERCEL.md` for the exact provider variables and post-configuration checks, and `docs/VERCEL_AUTH.md` for the portable authentication implementation.
