# fleshsesh academy — supplied brand assets

## Source and scope

This implementation uses the attached **fleshsesh academy Brand Guide v1.0, October 2026**, `fleshsesh-academy-brand-guide(1).pdf` (13 pages). Its SHA-256 is `80fffd68e14a2a85cf373cc5ba26cef6c2dfcfd26fea594761a1cd5172d17731`.

The glossy wordmark and compact emblem remain the supplied raster artwork. The guide describes the Poppins flat wordmark, flat `fa` icon, palette roles and precise size rules as proposed consolidations in this edition (pages 3–4 and 13). The website adopts those supplied functional alternatives. No lettering has been retyped, traced, generated or replaced.

Page references below refer to the attached PDF, not inferred standards. The guide mentions a companion SVG/PNG/font kit on page 13, but the attachment itself contains raster image objects for the logos. The files exported here are genuine embedded artwork with their original PDF soft masks. No vector-master claim is made for them.

## Name and lettering

Use **fleshsesh academy** in running text: lowercase, two words. Preserve the lettering and capitalization within the glossy artwork, and keep `academy` in the primary lockup (page 2).

The glossy master combines custom pink script, lips and the gold `academy` descriptor. The custom lettering is not an identified retail typeface. Use the complete image as one unit (page 3). The compact glossy emblem has its own supplied capital `F` and uppercase `ACADEMY`; it is not the small functional icon (pages 4 and 10).

## Palette

The **sRGB values are authoritative**. The guide's CMYK figures are approximate conversions for print proofing (page 7).

| Token | Hex | RGB | Role | Approximate CMYK |
| --- | --- | --- | --- | --- |
| Ink | `#0D1014` | 13, 16, 20 | Dark brand ground | 35, 20, 0, 92 |
| Paper | `#F4EEE6` | 244, 238, 230 | Calm learning and extended-reading surfaces | 0, 2, 6, 4 |
| Berry | `#9D3A5C` | 157, 58, 92 | Actions and links on Paper | 0, 63, 41, 38 |
| Blush | `#E6A7BB` | 230, 167, 187 | Highlights on dark backgrounds | 0, 27, 19, 10 |
| Brass | `#C7A86D` | 199, 168, 109 | Academy accents on dark backgrounds | 0, 16, 45, 22 |

Page 8 gives an illustrative balance of Ink 35%, Paper 50%, Berry 8%, Blush 5%, Brass 2%, with an instruction to adapt to the surface. These are not fixed layout quotas.

| Solid pair in the guide | Printed contrast ratio | Guide designation |
| --- | --- | --- |
| Paper on Ink / Ink on Paper | 16.54:1 | AAA |
| Berry on Paper | 5.71:1 | AA |
| Blush on Ink | 9.63:1 | AAA |
| Brass on Ink | 8.40:1 | AAA |
| Brass on Paper | 1.97:1 | Decorative only |

These ratios apply to the listed solid token pairs. Imagery, gradients, opacity, focus states and the complete interface need separate checks; the guide does not certify an entire implementation as accessible (page 8). Machine-readable colour tokens are in `public/brand/brand-tokens.json`.

## Typography

Page 9 specifies **Inter** for learning and interface text:

| Role | Typeface and weight | Explicit size / line height |
| --- | --- | --- |
| Display and learning headings | Inter Bold, 700 | No fixed size specified |
| Lesson and interface headings | Inter Bold, 700 | No fixed size specified |
| Body | Inter Regular, 400 | 17px / 26px |
| Caption | Inter Medium, 500 | 12px / 18px |
| Flat logo | Poppins, supplied artwork | Use the extracted lockup |
| Glossy logo | Supplied custom artwork | Use the extracted master |

The guide does not require all interface headings to be lowercase. Its explicit lowercase naming rule applies to the brand name in running text. There is no reason to load Poppins for interface text because the flat logo is preserved as an image.

### Self-hosted font

`public/fonts/inter-variable-latin.woff` is the client font: a **232,964-byte variable subset** retaining both original weight 100–900 and optical-size 14–32 axes. It includes Latin and Latin Extended, Latin Extended Additional, general punctuation, superscripts/subscripts, currency, letterlike symbols, arrows and mathematical operators where present in the source: U+0000–024F, U+1E00–1EFF, U+2000–206F, U+2070–209F, U+20A0–20CF, U+2100–214F, U+2190–21FF and U+2200–22FF. It contains 1,774 glyphs and retains variable outline data. Use `format('woff')` and `font-weight: 100 900`; other scripts can use the interface's system fallback.

The unchanged source is retained at `design/brand-originals/Inter-Variable.ttf` and, during integration, `public/fonts/inter-variable.ttf` (876,576 bytes). The identical uppercase public duplicate has been removed. It was downloaded from the official [google/fonts, ofl/inter](https://github.com/google/fonts/tree/main/ofl/inter) repository. Source download: [Inter[opsz,wght].ttf](https://raw.githubusercontent.com/google/fonts/main/ofl/inter/Inter%5Bopsz%2Cwght%5D.ttf). Version metadata is `4.001;git-66647c0bb`. This is the upright face.

Its SIL Open Font License is retained in `public/fonts/OFL-Inter.txt`, copied from the same official repository. The full font SHA-256 is `29160a80ff49ddcab2c97711247e08b1fab27a484a329ce8b813d820dc559031`. Provenance and derivative details are recorded in `public/fonts/inter-provenance.json`.

The printable certificate can embed these static derivatives for offline use:

| File | Weight / optical size | Size |
| --- | --- | --- |
| `public/fonts/Inter-Regular-Latin.woff` | 400 / 14 | 70,444 bytes |
| `public/fonts/Inter-Bold-Latin.woff` | 700 / 14 | 72,928 bytes |

The subsets preserve Latin and Latin Extended characters, Latin Extended Additional, general punctuation, currency, letterlike symbols and arrows: U+0020–024F, U+1E00–1EFF, U+2000–206F, U+20A0–20CF, U+2100–214F and U+2190–21FF, where present in the original font. Both contain 1,737 glyphs. Curly apostrophes, em dash, middle dot, euro and accented Latin examples were checked. Other scripts can fall back to a system font. WOFF uses lossless compression; the full variable font is not modified.

## Exported identity files

All paths below are relative to the project. PNG dimensions describe the actual file canvas after the documented crop, so the display width is unambiguous.

| File | Dimensions | Foreground / intended use |
| --- | --- | --- |
| `public/brand/glossy-master.png` | 1299 × 393 | Original pink-and-gold primary artwork, transparent |
| `public/brand/glossy-emblem.png` | 614 × 680 | Original glossy `F`, lips and `ACADEMY` emblem, transparent |
| `public/brand/flat-wordmark-light.png` | 1984 × 604 | White two-line lockup, transparent; dark surfaces |
| `public/brand/flat-wordmark-dark.png` | 1984 × 604 | Black two-line lockup, transparent; Paper/light surfaces |
| `public/brand/flat-icon-light.png` | 656 × 574 | White `fa` glyph, transparent; dark surfaces |
| `public/brand/flat-icon-dark.png` | 656 × 574 | Black `fa` glyph, transparent; light surfaces |
| `public/brand/flat-icon-tile-dark.png` | 1024 × 1024 | Blush `fa` on rounded Ink tile; transparent corners |
| `public/brand/flat-icon-tile-light.png` | 1024 × 1024 | Black `fa` on rounded Paper tile; transparent corners |
| `public/brand/flat-icon-avatar.png` | 400 × 400 | Blush `fa` on Ink circular avatar |
| `public/brand/social-open-graph.png` | 1200 × 630 | Actual embedded social card from page 11 |
| `public/brand/profile-header.png` | 1500 × 500 | Actual embedded profile header from page 11 |

For wordmark and glyph filenames, **light/dark describes the foreground**, not the background. For tile filenames, dark/light describes the tile background.

### Clear space and minimum sizes

Page 5 requires the glossy master to be at least **240px wide on screen** or **60mm in print**. Allow clear space equal to **one quarter of the complete artwork height on all four sides**. That clear space is deliberately not baked into the exported PNG; supply it in layout.

For this 1299 × 393 export, if the displayed artwork width is `W`, its height is `W × 393 / 1299`, and the minimum padding on each side is `W × 393 / 1299 / 4`.

| Displayed glossy artwork width | Artwork height | Minimum clear space, each side |
| --- | --- | --- |
| 240px | 72.61px | 18.15px |
| 260px | 78.66px | 19.67px |
| 280px | 84.71px | 21.18px |
| 400px | 121.02px | 30.25px |

The glossy compact emblem requires at least **96px artwork width** and clear space equal to **one quarter of the emblem width** on each side. Below 96px, use the proposed flat `fa` icon and keep the full name in adjacent text when space permits (pages 5 and 10).

The PDF demonstrates the flat icon at 64, 48, 32, 24 and 16px. It does not provide a separate numerical minimum size or clear-space rule for the flat wordmark. The current header uses the supplied glossy master at the user's request. Its desktop artwork is 244px wide inside a 282px box with 19px padding on each side. At 600px and below, the artwork is 242px wide in a 280px box, again with 19px padding. Both exceed the 240px minimum and the calculated quarter-height clear space (18.45px and 18.30px). The mobile header uses two rows so the logo remains legible alongside navigation actions.

### Crop and alpha treatment

The master source, PDF image object 4, is 1536 × 1024. Its canvas contains isolated background speckles with alpha values 1–4 well outside the visible identity. The approved export crops to **x=125, y=270, width=1299, height=393**. It preserves every original RGBA pixel inside that box, including the visible sparkle extents. Removed source pixels have opacity no greater than 4/255 (1.57%).

The compact emblem is cropped from object 12 at **x=205, y=112, width=614, height=680**. The flat wordmarks use objects 9 and 11 at **x=32, y=33, width=1984, height=604**. The white flat icon uses object 15 at **x=184, y=225, width=656, height=574**. These trims remove only zero-alpha margins. Their original aspect ratios and lettering are retained.

The black standalone `fa` glyph retains the exact white glyph's alpha geometry, with RGB changed to black, matching the approved black foreground shown in the guide's light tile. The tile and social assets are complete embedded images without cropping.

Original, uncropped PNG extractions are retained in `design/brand-originals/pdf-object-*.png`. `public/brand/asset-provenance.json` maps each export to its PDF object, crop, dimensions and SHA-256 hash. PNG compression may differ from the extracted source file, but decoded RGBA pixel comparisons verified equality for every directly extracted export.

## Browser and app icons

| File | Content |
| --- | --- |
| `public/favicon.svg` | Self-contained SVG wrapper around the actual flat dark-tile PNG; no external request |
| `public/apple-touch-icon.png` | 180 × 180, original dark tile resized and flattened onto Ink |
| `public/brand/app-icon-192.png` | 192 × 192, original dark tile resized and flattened onto Ink |
| `public/brand/app-icon-512.png` | 512 × 512, original dark tile at 460 × 460 with 26px Ink inset on every side |
| `public/site.webmanifest` | Brand name, Paper background, Ink theme and the app-icon paths |

The favicon uses the guide's flat `fa` mark, not the glossy emblem. Its SVG extension is a browser container; it is **not** an outlined vector master. The 512px manifest icon has an additional inset to keep the glyph within a central safe circle and declares both `any` and `maskable` purposes. App icons retain the source design and avoid introducing new letterforms.

## Social artwork

`social-open-graph.png` is the actual 1200 × 630 embedded PDF object 30. It preserves the original glossy identity, Ink background, Inter message “there is room for your questions.” and Brass outline. `profile-header.png` is the actual 1500 × 500 object 31. Page 11 asks that identity remain in the safe area and that each platform's crop be checked. The site metadata references the Open Graph file; no social account posting is part of this change.

## Motion and voice

**This PDF contains no explicit animation timing, easing or motion specification.** Any implemented timing is an interaction design choice and should be documented separately in `docs/MOTION.md`, rather than attributed to the brand guide.

The guide's page 12 voice is clear, welcoming, choice-led and credible: invite questions, avoid assumptions about identity or experience, make fictional examples and pauses ordinary, identify AI as AI, and describe completion awards accurately. Its own examples reject universal participation expectations and unapproved accreditation or expert-status claims.

Page 6 prohibits distorted or rotated master art, unauthorized colours, poor foreground contrast, substitute lettering and crowded clear space. Animation should preserve the complete artwork and its proportions.

## Verification performed

- Read the PDF text and inspected rendered guide pages for identity, palette, typography, spacing, icons and social assets.
- Extracted image objects with their original soft masks, retaining complete uncropped sources.
- Compared decoded RGBA pixels of every directly extracted PNG with its source crop: all equal.
- Verified the black standalone glyph preserves the original white glyph's alpha mask exactly.
- Verified the favicon embeds the original flat tile bytes.
- Inspected final glossy artwork on Ink at 400px and 260px, flat header wordmarks at 170px and 128px, a glossy emblem above its minimum size, the black flat identity on Paper, small flat icons and the full Open Graph image.
- Read the Inter metadata, verified the client subset retains both variable axes and variable outline data, and checked essential punctuation, accented Latin and mathematical characters. Both certificate subsets were checked separately for punctuation and accented Latin coverage.

These are asset provenance and visual checks. Application behaviour, responsive layout and motion accessibility are verified separately by the site integration workflow.
