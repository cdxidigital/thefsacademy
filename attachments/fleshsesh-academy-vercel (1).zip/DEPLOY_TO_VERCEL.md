# Upload and configure on Vercel

## 1. Upload the ZIP

1. Open [Vercel Drop](https://vercel.com/drop) and sign in to your own Vercel account.
2. Drag `fleshsesh-academy-vercel.zip` onto the page.
3. Choose your team and a new project name, then select **Deploy**.
4. The project root is the folder containing `package.json` and `vercel.json`. The preset is **Next.js**, install command is `npm ci`, build command is `npm run build`, and Node.js is **24.x**. Leave the output directory at its Next.js default.

The ZIP places `package.json` at its top level to support framework detection. It contains source and assets; Vercel compiles the deployable application. There is no prelinked Vercel project and no requirement to copy a local `.next` directory.

Vercel Drop creates a production deployment. Its first upload can show the public site while sign-in and member services wait for their configuration. If you prefer a preview before production, extract the ZIP and use the Vercel CLI workflow below instead.

Reference: [Vercel Drop documentation](https://vercel.com/docs/drop).

## 2. Configure Clerk sign-in

Create a Clerk application you own. Enable the sign-in methods you want to offer and configure its allowed application domain for your new Vercel URL. Use development credentials only for development/testing; configure a production Clerk instance for a production launch.

In **Vercel → Project → Settings → Environment Variables**, add:

```text
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY
CLERK_SECRET_KEY
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
```

Set the appropriate environments, and redeploy after changing a `NEXT_PUBLIC_` variable because it is embedded at build time. Enter private keys directly in the provider/Vercel settings, not in public source or chat.

The export provides `/sign-in` and `/sign-up`, and compatibility routes for links retained from the original site. Learner identity comes from the verified Clerk session. Caller-supplied ChatGPT identity headers cannot authenticate a Vercel visitor. Sign-out uses the provider's session mechanism.

References: [Clerk Next.js quickstart](https://clerk.com/docs/nextjs/getting-started/quickstart), [Clerk Vercel deployment guidance](https://clerk.com/docs/deployments/vercel).

## 3. Configure the learning database

Create a **Turso/libSQL** database you own. Add these values in the same Vercel environment settings:

```text
TURSO_DATABASE_URL=libsql://your-database-host
TURSO_AUTH_TOKEN=your-own-database-token
```

The values above are illustrative placeholders. Use the URL and scoped credential provided for your own database. Server-side values are never needed in a `NEXT_PUBLIC_` variable.

Initialize its schema from the downloaded code before opening member features:

1. Extract the ZIP into a local folder.
2. Install [Node.js 24](https://nodejs.org/) if needed.
3. Open a terminal in the extracted folder and run `npm ci`.
4. Copy `.env.example` to `.env.local` and enter the intended database URL and token.
5. Run `npm run db:migrate`.

The migration runner applies the included journal in order and records completed migrations. It does not import learners from the existing Sites database. Use a fresh dedicated database unless you have reviewed a separate migration plan. Do not run development migrations against a database you did not intend to change.

The application uses durable remote storage on Vercel. Local `file:` databases are allowed only by an explicit development option; they are rejected in Vercel/production. SQLite-style prepared values and atomic batches preserve the existing lesson, demo and entitlement operations.

Reference: [Turso TypeScript client](https://docs.turso.tech/sdk/ts/reference).

## 4. Set the site origin and keep the existing pilot defaults

Set the new deployment's exact HTTPS origin without a trailing path:

```text
APP_ORIGIN=https://your-project.vercel.app
APP_MODE=pilot
RELEASE_APPROVED=false
PROCESSOR_APPROVED=false
AI_RELEASE_APPROVED=false
```

After entering all values, redeploy the Vercel project so its client build and server functions use the intended configuration.

The existing payment code supports the reviewed subscriptions, individual module/toolkit purchases and tutor question packs. Stripe is not provisioned by this ZIP. Before charging, configure the price IDs, secret key, webhook signing secret and `/api/billing/webhook` endpoint for this domain, then complete the existing payment/release checks. An existing Stripe customer or subscription is not automatically linked to a newly created Clerk user.

For generative tutoring, configure the server-side `OPENAI_API_KEY` and `OPENAI_MODEL` and complete the existing AI release/consent checks before enabling `AI_RELEASE_APPROVED`. No key is included. The three curriculum-guide roles work without a model once sign-in and storage are configured; Assessment Tutor remains deterministic and demo learners never make paid AI requests.

All supported variable names are in `.env.example`.

## 5. Check the connected deployment

Run these checks on the new Vercel URL after configuration:

1. Open the landing page; confirm the logo, eCampus imagery, film poster and manual playback. Accept the adult-entry declaration and confirm autoplay respects motion preferences and runs only once in the tab session.
2. Create an account, sign out, sign in again, and complete the adult learner welcome.
3. Complete a lesson and refresh; confirm its progress is saved to the intended database.
4. Open `/demo`, enter the private Plus demonstration, try a member lesson and the C02 assessment, reset, then exit. Confirm your regular learner progress is separate.
5. Open each tutor role, verify its different behaviour and source links, then start a marked assessment and confirm the teaching restrictions.
6. Confirm a second account cannot read the first learner's profile or replay its demo.

The export's automated checks and build do not replace provider-connected browser testing. See `docs/VERCEL_EXPORT_VERIFICATION.md` for exactly what was verified here.

## Optional: deploy a preview from your terminal

After extracting the ZIP, installing dependencies and adding your settings:

```sh
npx vercel login
npx vercel link
npx vercel deploy
```

Choose your own team/project in the prompts. Add the environment variables to that project's **Preview** environment and redeploy as needed. Do not use production database credentials for an untrusted preview. When you have reviewed the preview and are ready for production, deploy with the intended production settings.

Reference: [Deploy a Vercel project from the CLI](https://vercel.com/docs/projects/deploy-from-cli).

## Troubleshooting

| Symptom | Action |
| --- | --- |
| Vercel treats the upload as static or cannot find `package.json` | Select the extracted project root and the Next.js preset. Do not upload only `public/`. |
| Sign-in reports that it is not configured | Add both Clerk keys to the intended Vercel environment and redeploy. |
| Clerk reports a domain or key mismatch | Use the matching key pair and configure the deployed domain in that Clerk application. |
| Learning records are unavailable | Check Turso URL/token and run the supplied migrations on that database. |
| A prior Sites learner has no progress here | This is a new identity/database. The ZIP does not migrate existing accounts or records. |
| Checkout is unavailable | Expected while the existing pilot and processor/release switches are off. |
| Tutors show written guides | Expected until optional generative AI is configured and approved; the demo always uses written guidance. |
| Changing a public key has no visible effect | Trigger a new build after changing `NEXT_PUBLIC_` environment variables. |

