CREATE TABLE `demo_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`owner_user_id` text NOT NULL,
	`demo_user_id` text NOT NULL,
	`created_at` text NOT NULL,
	`expires_at` text NOT NULL,
	FOREIGN KEY (`demo_user_id`) REFERENCES `profiles`(`user_id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `demo_owner_unique` ON `demo_sessions` (`owner_user_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `demo_learner_unique` ON `demo_sessions` (`demo_user_id`);