CREATE TABLE `assessment_attempts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`assessment_id` text NOT NULL,
	`score` integer NOT NULL,
	`total` integer NOT NULL,
	`passed` integer NOT NULL,
	`critical_passed` integer NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `profiles`(`user_id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `assessment_results` (
	`user_id` text NOT NULL,
	`assessment_id` text NOT NULL,
	`best_score` integer NOT NULL,
	`total` integer NOT NULL,
	`passed_at` text,
	`last_attempt_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `assessment_id`),
	FOREIGN KEY (`user_id`) REFERENCES `profiles`(`user_id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `billing_customers` (
	`user_id` text PRIMARY KEY NOT NULL,
	`customer_id` text NOT NULL,
	`subscription_id` text,
	`subscription_status` text,
	`cancel_at_period_end` integer DEFAULT false NOT NULL,
	`period_end` text,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `profiles`(`user_id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `billing_customer_unique` ON `billing_customers` (`customer_id`);--> statement-breakpoint
CREATE TABLE `certificates` (
	`user_id` text PRIMARY KEY NOT NULL,
	`id` text NOT NULL,
	`display_name` text NOT NULL,
	`course_version` text NOT NULL,
	`issued_at` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `profiles`(`user_id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `certificate_id_unique` ON `certificates` (`id`);--> statement-breakpoint
CREATE TABLE `entitlements` (
	`user_id` text NOT NULL,
	`key` text NOT NULL,
	`source_id` text NOT NULL,
	`expires_at` text,
	`active` integer DEFAULT true NOT NULL,
	`updated_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `key`, `source_id`),
	FOREIGN KEY (`user_id`) REFERENCES `profiles`(`user_id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `lesson_progress` (
	`user_id` text NOT NULL,
	`lesson_id` text NOT NULL,
	`completed_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `lesson_id`),
	FOREIGN KEY (`user_id`) REFERENCES `profiles`(`user_id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `payment_events` (
	`id` text PRIMARY KEY NOT NULL,
	`type` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `profiles` (
	`user_id` text PRIMARY KEY NOT NULL,
	`display_name` text NOT NULL,
	`weekly_goal` integer DEFAULT 3 NOT NULL,
	`accepted_version` text NOT NULL,
	`adult_confirmed_at` text NOT NULL,
	`education_acknowledged_at` text NOT NULL,
	`orientation_completed_at` text,
	`external_ai_consent_at` text,
	`tutor_credits` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `tutor_usage` (
	`user_id` text NOT NULL,
	`bucket` text NOT NULL,
	`count` integer DEFAULT 0 NOT NULL,
	PRIMARY KEY(`user_id`, `bucket`),
	FOREIGN KEY (`user_id`) REFERENCES `profiles`(`user_id`) ON UPDATE no action ON DELETE cascade
);
