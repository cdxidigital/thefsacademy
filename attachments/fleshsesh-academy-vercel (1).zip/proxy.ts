import { clerkMiddleware } from "@clerk/nextjs/server";
import { NextResponse, type NextFetchEvent, type NextRequest } from "next/server";
import { hasClerkConfiguration } from "./lib/auth/config";

export default function proxy(request: NextRequest, event: NextFetchEvent) {
  // A ZIP with no configured services can still serve its public landing pages.
  // Protected pages/API handlers independently require a verified Clerk user.
  if (!hasClerkConfiguration()) return NextResponse.next();
  return clerkMiddleware({ signInUrl: "/sign-in", signUpUrl: "/sign-up" })(request, event);
}

export const config = {
  matcher: [
    "/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|avif|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest|mp4|webm|vtt|mp3|wav|ogg|pdf|txt)).*)",
    "/(api|trpc)(.*)",
    "/__clerk/(.*)",
  ],
};
