import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createConfiguredClient, databaseConfiguration, DatabaseConfigurationError } from '../lib/server/database-config.mjs';

const defaultDirectory = resolve(dirname(fileURLToPath(import.meta.url)), '../drizzle');
const ledger = '__academy_migrations';

/** Read the committed Drizzle journal without modifying source or database. */
export async function loadMigrations(directory = defaultDirectory) {
  const journal = JSON.parse(await readFile(resolve(directory, 'meta/_journal.json'), 'utf8'));
  if (journal.dialect !== 'sqlite' || !Array.isArray(journal.entries)) throw new Error('Expected a SQLite Drizzle migration journal.');
  const tags = new Set();
  const migrations = [];
  for (const [index, entry] of journal.entries.entries()) {
    if (entry.idx !== index || typeof entry.tag !== 'string' || !/^\d{4}_[a-z0-9_]+$/.test(entry.tag) || tags.has(entry.tag)) throw new Error('Migration journal order or identifier is invalid.');
    tags.add(entry.tag);
    const source = await readFile(resolve(directory, `${entry.tag}.sql`), 'utf8');
    const statements = source.split('--> statement-breakpoint').map((sql) => sql.trim()).filter(Boolean);
    if (!statements.length) throw new Error(`Migration ${entry.tag} contains no statements.`);
    migrations.push({ index, tag: entry.tag, hash: createHash('sha256').update(source).digest('hex'), statements });
  }
  return migrations;
}

/**
 * Applies the pending journal in one transaction, including its checksum ledger.
 * Never called from an HTTP request, build, or server startup.
 * @param {import('@libsql/client').Client} client
 */
export async function applyMigrations(client, directory = defaultDirectory) {
  const migrations = await loadMigrations(directory);
  const foreignKeys = await client.execute('PRAGMA foreign_keys');
  if (foreignKeys.rows[0]?.foreign_keys !== 1) throw new Error('Database foreign-key enforcement must be enabled before migration.');
  const transaction = await client.transaction('write');
  try {
    await transaction.execute(`CREATE TABLE IF NOT EXISTS ${ledger} (position INTEGER PRIMARY KEY NOT NULL, tag TEXT NOT NULL UNIQUE, checksum TEXT NOT NULL, applied_at TEXT NOT NULL)`);
    const applied = (await transaction.execute(`SELECT position, tag, checksum FROM ${ledger} ORDER BY position`)).rows;
    for (const [index, row] of applied.entries()) {
      const expected = migrations[index];
      if (!expected || row.position !== index || row.tag !== expected.tag || row.checksum !== expected.hash) throw new Error('Applied migration history differs from this export. Restore the matching migration files before continuing.');
    }
    const pending = migrations.slice(applied.length);
    const statements = pending.flatMap((migration) => [
      ...migration.statements.map((sql) => ({ sql, args: [] })),
      { sql: `INSERT INTO ${ledger} (position, tag, checksum, applied_at) VALUES (?, ?, ?, ?)`, args: [migration.index, migration.tag, migration.hash, new Date().toISOString()] },
    ]);
    if (statements.length) await transaction.batch(statements);
    await transaction.commit();
    return { applied: pending.map((item) => item.tag), skipped: migrations.slice(0, applied.length).map((item) => item.tag) };
  } catch (error) {
    try { await transaction.rollback(); } catch { /* A failed batch may already have rolled back. */ }
    throw error;
  } finally {
    transaction.close();
  }
}

async function main() {
  const configuration = databaseConfiguration();
  if (!configuration) throw new DatabaseConfigurationError('Set TURSO_DATABASE_URL and TURSO_AUTH_TOKEN before running db:migrate.');
  const client = createConfiguredClient(configuration);
  try {
    const result = await applyMigrations(client);
    console.log(`Migrations complete: ${result.applied.length} applied; ${result.skipped.length} already applied.`);
  } finally { client.close(); }
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  main().catch((error) => {
    console.error(error instanceof DatabaseConfigurationError ? error.message : 'Database migration did not finish cleanly. Check connectivity, database permissions, and the committed migration history before retrying; the checksum ledger prevents reapplying completed migrations.');
    process.exitCode = 1;
  });
}
