import { readdirSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const suites = readdirSync(path.join(root, "tests"))
  .filter((name) => name.endsWith(".test.mjs"))
  .sort();
let failures = 0;
for (const name of suites) {
  process.stdout.write(`\n${name}\n`);
  const result = spawnSync(process.execPath, [path.join("tests", name)], {
    cwd: root,
    stdio: "inherit",
    env: { ...process.env, NODE_ENV: "test" },
  });
  if (result.error || result.status !== 0) failures += 1;
}
process.stdout.write(`\n${suites.length - failures}/${suites.length} suites passed.\n`);
process.exitCode = failures ? 1 : 0;
