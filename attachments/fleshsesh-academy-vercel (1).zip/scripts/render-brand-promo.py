"""Compose the Academy's new silent brand film from its generated footage.

Usage: python scripts/render-brand-promo.py INPUT.mp4 OUTPUT.mp4 WORK_DIRECTORY
Requires ffmpeg and fontTools; uses the unmodified supplied glossy logo.
The source footage is a separate generated asset, not the previous promo.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont


def main() -> None:
    source, output, working = (Path(value).resolve() for value in sys.argv[1:4])
    root = Path(__file__).resolve().parents[1]
    working.mkdir(parents=True, exist_ok=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    fonts = {}
    for label, weight in (("regular", 450), ("bold", 700)):
        font = TTFont(root / "design/brand-originals/Inter-Variable.ttf")
        instantiateVariableFont(font, {"wght": weight, "opsz": 32}, inplace=True)
        path = working / f"Inter-{label}.ttf"
        font.save(path)
        fonts[label] = path

    filters = [
        "[0:v]fps=24,scale=1920:1080,setsar=1,trim=duration=15.041667,"
        "tpad=stop_mode=clone:stop_duration=10,setpts=PTS-STARTPTS,"
        "drawbox=color=0x0D1014@0.22:t=fill,"
        "fade=t=in:st=0:d=0.45:color=0x0D1014,"
        "fade=t=out:st=13.15:d=1.2:color=0x0D1014"
    ]
    copy = []

    def text(content: str, start: float, end: float, x: str | int, y: int,
             size: int, *, bold: bool = False, color: str = "F4EEE6",
             rise: bool = False) -> None:
        file = working / f"copy-{len(copy):02d}.txt"
        file.write_text(content, encoding="utf-8")
        copy.append({"text": content, "start": start, "end": end})
        alpha = (
            f"if(lt(t,{start}),0,if(lt(t,{start + .5}),(t-{start})/0.5,"
            f"if(lt(t,{end - .3}),1,if(lt(t,{end}),({end}-t)/0.3,0))))"
        )
        ypos = f"{y}+18*(1-min(max((t-{start})/0.65,0),1))" if rise else str(y)
        filters.append(
            f"drawtext=fontfile='{fonts['bold' if bold else 'regular']}':"
            f"textfile='{file}':expansion=none:fontsize={size}:fontcolor=0x{color}:"
            f"x='{x}':y='{ypos}':alpha='{alpha}':"
            "shadowcolor=black@0.3:shadowx=0:shadowy=2"
        )

    for start, end, label, headline, subtitle in (
        (.65, 4.6, "YOUR CURIOSITY BELONGS HERE", "Know more.",
         "Consent, bodies and sexual wellbeing."),
        (5.3, 9.6, "OPEN MINDS. BETTER CONNECTIONS.", "Feel more.",
         "Communication, boundaries and relationships."),
        (10.3, 14.05, "LEARN AT YOUR OWN PACE", "Be you.",
         "Identity, inclusion and informed choice."),
    ):
        text(label, start, end, 126, 602, 27, color="C7A86D")
        text(headline, start + .08, end, 118, 651, 154, bold=True, rise=True)
        text(subtitle, start + .22, end, 126, 849, 44)

    text("ADULT SEXUAL WELLBEING FOUNDATIONS", 14.55, 20.15, "(w-text_w)/2", 221, 32,
         color="C7A86D")
    text("48", 14.7, 20.15, "560-text_w/2", 315, 180, bold=True)
    text("written lessons", 14.8, 20.15, "560-text_w/2", 541, 50)
    text("18", 14.9, 20.15, "1360-text_w/2", 315, 180, bold=True)
    text("modules", 15.0, 20.15, "1360-text_w/2", 541, 50)
    text("12 core modules · 6 elective deep dives", 15.15, 20.15, "(w-text_w)/2", 645, 42,
         color="E6A7BB")
    text("Foundations Tutor · Practice Coach · Assessment Tutor", 15.3, 20.15,
         "(w-text_w)/2", 762, 40)
    text("Fictional practice · Knowledge checks · Private progress", 15.45, 20.15,
         "(w-text_w)/2", 843, 34, color="C7A86D")
    text("THERE IS ROOM FOR YOUR QUESTIONS.", 20.6, 26, "(w-text_w)/2", 178, 26,
         color="C7A86D")
    text("Know more. Feel more. Be you.", 20.75, 26, "(w-text_w)/2", 740, 42, bold=True)
    text("Your next chapter starts here.", 21.0, 26, "(w-text_w)/2", 824, 31,
         color="E6A7BB")
    text("Non-accredited adult education · 18+", 21.2, 26, "(w-text_w)/2", 932, 22)

    graph = ",\n".join(filters) + "[base];\n"
    graph += (
        "[1:v]fps=24,scale=1120:-1,format=rgba,"
        "fade=t=in:st=20.25:d=0.7:alpha=1[logo];\n"
        "[base][logo]overlay=x=(W-w)/2:y=300:shortest=1:format=auto,"
        "format=yuv420p[out]\n"
    )
    filter_file = working / "brand-film.ffmpeg"
    filter_file.write_text(graph, encoding="utf-8")
    candidate = working / "academy-new-chapter-candidate.mp4"
    subprocess.run([
        "ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "error", "-y",
        "-i", str(source), "-loop", "1", "-i", str(root / "public/brand/glossy-master.png"),
        "-filter_complex_script", str(filter_file), "-map", "[out]", "-an", "-t", "25",
        "-c:v", "libx264", "-preset", "slow", "-crf", "22", "-pix_fmt", "yuv420p",
        "-profile:v", "high", "-level:v", "4.0", "-refs", "3", "-maxrate", "8M", "-bufsize", "16M",
        "-movflags", "+faststart", "-metadata", "title=fleshsesh academy — A new chapter",
        "-metadata", "comment=Original AI-generated footage with supplied Academy branding; silent edition.",
        str(candidate),
    ], check=True)
    metadata = json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json",
        str(candidate),
    ], text=True))
    streams = metadata["streams"]
    if candidate.stat().st_size < 100_000 or abs(float(metadata["format"]["duration"]) - 25) > .1:
        raise RuntimeError("The rendered promo is empty, incomplete or has the wrong duration.")
    if len(streams) != 1 or streams[0]["codec_name"] != "h264":
        raise RuntimeError("The promo must contain exactly one H.264 video stream and no audio.")
    candidate.replace(output)
    (working / "copy-timings.json").write_text(json.dumps(copy, indent=2) + "\n")
    print(json.dumps({"output": str(output), "durationSeconds": 25, "bytes": output.stat().st_size}))


if __name__ == "__main__":
    main()
