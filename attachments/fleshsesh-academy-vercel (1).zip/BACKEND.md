> Historical Sites release record. For this Vercel export, use `README.md`, `DEPLOY_TO_VERCEL.md` and `docs/VERCEL_EXPORT_VERIFICATION.md`. Native ChatGPT hosting identity and Cloudflare D1 have been replaced in the export. Earlier test counts and deployments below describe the original release.

# Fleshsesh Academy: server and release notes

## What runs

This is a Vinext application on the Sites Cloudflare Workers runtime. Sites supplies authenticated ChatGPT identity. D1 stores adult learner acknowledgements, preferences, learning completions, scored attempts, private achievements, access grants, usage counters and issued certificates. Anonymous visitors can read the landing/catalogue/orientation; protected APIs derive the learner ID from the trusted Sites identity helper. There is no password database or separate email sign-in implementation.

`APP_MODE=pilot` is the default. Onboarded adult pilot learners can access the full written curriculum. Purchases are disabled, and no payment success or entitlement is fabricated. The tutor runs as a deterministic curriculum search guide until an approved model/key is configured. The uploaded curriculum is an authoring edition; clinical and legal review flags remain false. This deployment is intended as a private pilot.

The content comprises 48 lessons, 12 core modules, 6 optional electives, 114 source assessment items, 48 non-credential practice scenarios, 10 worksheets, glossary entries and source references. Public catalogue responses omit full lesson text and answer keys. Paid text is delivered only by protected routes. Private reflection prompts never require server submissions; no reflection content or tutor messages are stored.

## API contract

All state-changing visitor endpoints require a same-origin `Origin` header and JSON body. Requests are size-bounded. The payment webhook instead requires a verified raw-body Stripe HMAC signature with a five-minute timestamp window. Authenticated responses use `Cache-Control: private, no-store`.

| Route | Contract |
|---|---|
| `GET /api/me` | User or `null`, profile, progress, billing state, tutor allowance and certificate eligibility. |
| `POST /api/profile` | `{displayName,weeklyGoal:2|3|5,adultConfirmed:true,educationAcknowledged:true,externalAiConsent?:boolean}`. Initial adult and education acknowledgements required. |
| `GET /api/catalog` | Summaries, assessment metadata, source references and glossary. No teaching text or keys. |
| `GET /api/orientation` | Orientation content. |
| `POST /api/orientation` | `{}`; persists completion after onboarding. |
| `GET /api/lessons/:id` | Entitled lesson, module metadata, non-credential practice scenario and sources. |
| `POST /api/progress` | `{lessonId}`; idempotent, user-scoped completion. Requires orientation. |
| `GET /api/assessments/:id` | Questions/options without answers, after prerequisite checks. No state mutation. |
| `POST /api/assessments/:id/start` | `{}`; sets marked-assessment tutor mode. |
| `POST /api/assessments/:id/end` | `{}`; returns to teaching without a score. |
| `POST /api/assessments/:id` | `{answers:{questionId:zeroBasedOptionIndex}}`; server marking, feedback and updated progress. Clears the matching assessment session. |
| `GET /api/resources` | Source references/glossary and entitled toolkit worksheets. |
| `POST /api/tutor` | `{message,lessonId?,consentToAI?:boolean,mode?:'explain'|'scenario'|'recap'}`. Returns honest service `mode`, answer, actual sources and lesson links. |
| `POST /api/certificate` | `{}`; issues once after all requirements pass. |
| `GET /api/certificate` | Private certificate record and eligibility. `?download=1` downloads printable HTML; browser Print can save as PDF. |
| `GET /api/account/export` | Downloads own complete learning record as JSON. |
| `POST /api/account/delete` | `{confirmation:'DELETE MY ACCOUNT'}`. Cancels linked recurring Stripe subscription before deleting Academy data. Provider failure stops deletion. Does not delete ChatGPT or payment-provider statutory records. |
| `POST /api/billing/checkout` | `{product,moduleId?}` from the allowlist below. Returns secure Stripe URL, or clear error before any payment. |
| `POST /api/billing/portal` | `{}`; returns existing customer's Stripe portal. Remains available when new sales are paused. |
| `POST /api/billing/webhook` | Verified Stripe events only; no visitor cookie/identity dependency. |

Module IDs are `C01`–`C12` and `E01`–`E06`. Core lessons use `C01-L01` format, electives use `E01-L01`. Module checks use `C01-TEST`, practice uses `C01-L01-CHECK`, and finals are `CAP01`/`PLAN01`.

## Completion and private gamification

Lessons must be recorded before a module test can be submitted. The core certificate requires orientation, all 36 core lessons, all 12 core module checks at 5/6 or better, the capstone at 10/12 or better **with all four critical items correct in the same passing attempt**, and the six-item applied planning assessment at 6/6. Electives and personal reflections are optional. The model cannot submit answers, mark work, alter scores or issue certificates. A prior pass persists across later practice attempts; a failed critical attempt never creates a pass just because its numeric score is high.

XP is computed from unique records: 25 per lesson, 100 per module check, 150 for the capstone. Repeated posts or retries cannot mint duplicate points. Practice checks add no extra XP. Points have no monetary value, are not purchasable and are not shared on public leaderboards. Weekly progress is a rolling seven-day count; there is no punitive streak reset. Certificates are private, non-accredited records and never claim an AQF qualification, VET Statement of Attainment or licence. Pilot certificates are visibly identified by their course version and statement.

Adult onboarding is an 18+ self-declaration. It is not identity-backed age verification. Public release needs a jurisdiction/content-appropriate age-assurance decision, alongside privacy, consumer, accessibility and content release review.

## Payments and subscriptions

| Product key | Price in AUD | Access |
|---|---:|---|
| `academy_monthly` | $19/month | Full course/toolkit; 50 AI questions per calendar month when enabled. |
| `academy_yearly` | $190/year | Same; annual billing. |
| `plus_monthly` | $29/month | Full course/toolkit; 200 AI questions per calendar month when enabled. |
| `plus_yearly` | $290/year | Same; annual billing. |
| `module` + moduleId | $7 once | The purchased module; free consent module cannot be bought. |
| `toolkit` | $5 once | Worksheets. |
| `tutor_pack` | $5 once | 50 additional AI questions; unavailable until the AI service is enabled. |

`Explore` is free and includes orientation, consent module C01 and the written learning guide for accessible lessons. The initial course certificate is included once requirements are satisfied; it is never sold as accreditation. All above are proposed list prices. Whether they are commercially viable depends on actual acquisition, retention and provider costs; no income is guaranteed.

There is no cash wallet, withdrawable balance, recurring microcharge or gambling mechanism. Each small purchase opens a one-time hosted Checkout. Server price IDs are allowlisted and fetched from Stripe; currency, amount, billing interval and quantity are checked before purchase and again before granting access. Already included modules/toolkits cannot be purchased again. Existing subscribers use the billing portal rather than opening another recurring subscription. Configure the Stripe customer portal to support plan management and straightforward cancellation.

New sales require `APP_MODE=live`, `PROCESSOR_APPROVED=true`, `RELEASE_APPROVED=true`, a valid HTTPS `APP_ORIGIN`, provider keys and matching Price IDs. Keep new sales disabled until the processor has explicitly approved the actual business, content and parent-brand context. No approval is implied by having integration code. Do not disguise the business to a processor. Configure merchant identity, support contact, invoices, Australian tax treatment, renewal disclosure and refund process before launch.

Subscribe to `checkout.session.completed`, `checkout.session.async_payment_succeeded`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.paid`, `invoice.payment_failed`, `invoice.payment_action_required`, `charge.refunded`, `charge.dispute.created`, `charge.dispute.closed`. The webhook re-fetches the canonical Checkout/subscription from Stripe, binds its customer/metadata to a stored Academy customer and only grants paid, currently active subscription periods. Redirects and query parameters never grant access. D1 transactions atomically record processed event IDs and grants. Tutor packs are unique by Checkout Session as well as event, preventing double grants across different success event types. Full refunds/disputes revoke one-time purchases and remaining question credit; partial refunds do not automatically revoke access. For subscription charges, full refunds and disputes create an invoice-specific access hold. The charge is resolved to its invoice through Stripe Invoice Payments, including renewal charges with no Checkout Session. A hold suspends the plan entitlement while that invoice is the subscription's current paid invoice, without cancelling or changing provider billing; the customer can still manage or cancel through the portal. Replayed invoice/subscription events cannot reactivate the held invoice. A different, subsequently paid invoice can grant its new access period; a late reversal of an older invoice does not suspend that newer invoice. A dispute won by the merchant removes only its matching dispute hold after re-fetching the canonical dispute status; a separate full-refund hold remains effective. Open or lost disputes remain held for their invoice. There is no automatic restoration of one-time purchases after a won dispute; those require explicit merchant reconciliation. Cancelling or preventing future charges is a separate customer/merchant billing action, never an implicit consequence of the access hold.

**Private hosting limitation:** Stripe cannot deliver a normal unauthenticated webhook through the owner-private Sites sign-in wall. Leave payments disabled during the private pilot. For paid launch, use an approved public audience or a separately approved reachable event-ingestion architecture, then test provider sandbox Checkout → event signature → durable access → renewal failure → cancellation/refund. Do not expose the Site solely to work around this limitation without authorisation.

## Tutor configuration and privacy

The guide searches only authorised lesson text, with explanation, recap and fictional-practice modes. It labels itself a curriculum search guide. The provider adapter uses OpenAI Responses over HTTPS, a server-only key/model, bounded input/output, and `store:false`. No learner identity, email, grades, answer keys or private profile is sent with questions. This setting does not promise zero provider or network retention; disclose the provider's actual processing/retention before obtaining consent. Consent is recorded and an explicit `consentToAI:false` overrides and revokes a previous preference.

AI requires `AI_RELEASE_APPROVED=true`, `OPENAI_API_KEY`, `OPENAI_MODEL`, appropriate review, and consent. No provider key is provisioned by this source. The OpenAI Developers key-approval capability was unavailable in the authoring environment. Configure a key through the supported approval flow before enabling. On paid public mode the curriculum release flag must also be approved. No live provider request was made or validated in this build.

Monthly allowances and extra credits are reserved atomically on D1, never trusted to client counters; failed provider calls restore the reserved allowance. Guide fallback remains available when a provider fails or allowance is exhausted. There is an eight-request per-minute server limit. Marked-assessment sessions return process-only help. Severe/urgent help-seeking gets a support route instead of a learning exercise; the app does not monitor emergencies or offer clinical care. Sources in the uploaded authoring pack are carried through with their actual verification status and require specialist review, rather than being silently declared validated.

## Database and verification

Migrations are generated by `npm run db:generate` from `db/schema.ts`, committed with Drizzle metadata and applied by Sites publication. No request handler creates or alters a table. User-owned records use the trusted site-scoped user ID and cascading foreign keys. Payment events store only event IDs/types/timestamps, not raw payloads or card information. Do not edit already-applied migrations.

Run meaningful tests with `node tests/backend.test.mjs` on Node 24+. The harness loads the actual route modules, substitutes only platform identity/runtime bindings and external Stripe transport, and runs D1 queries against an in-memory SQLite database using the generated migrations. It covers source grading, critical failures, onboarding/auth/CSRF, user isolation, live entitlement gates, completion/XP idempotence, private certificates, guide/rate limits, cascading deletion, HMAC freshness/tampering and webhook duplicate/refund handling. Mocked provider transport verifies implementation logic, including subscription refund/dispute holds, replay resistance, renewal access and won-dispute reinstatement; it is not evidence of merchant approval or a successful real charge. The real Stripe sandbox and webhook delivery have not been exercised, including the invoice-payment lookup and dispute lifecycle. Complete those provider sandbox checks before enabling paid release. Also run `npx tsc --noEmit` and the Sites build command.

Primary implementation references: the session-provided Sites identity/storage documentation, [Stripe Checkout](https://docs.stripe.com/api/checkout/sessions/create), [Stripe event signatures and delivery](https://docs.stripe.com/events/manage-webhook-endpoints), [Stripe subscriptions](https://docs.stripe.com/api/subscriptions/object), [OpenAI Responses guidance](https://developers.openai.com/api/docs/guides/migrate-to-responses).
