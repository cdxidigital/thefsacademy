import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fixture, identity, request, context, route, catalog, bank, correctAnswers } from "./backend-runtime.mjs";

const { gradeAssessment } = await import("../lib/server/pure.ts");
const { shuffleQuestionOptions } = await import("../lib/academy/assessment-options.ts");
const lessons = catalog.modules.flatMap((module) => module.lessons);
const criticalIds = ["CAP01-Q01", "CAP01-Q02", "CAP01-Q03", "CAP01-Q04"];
const popcount = (value) => value.toString(2).replaceAll("0", "").length;

test("curriculum retains its full scope, stable item IDs and completion gates", () => {
  assert.equal(catalog.modules.length, 18);
  assert.equal(lessons.length, 48);
  assert.equal(bank.questions.length, 114);
  assert.equal(bank.scenarios.length, 48);
  assert.equal(new Set(bank.questions.map((question) => question.id)).size, 114);
  assert.equal(catalog.course.coreMinutes, 600);
  assert.equal(catalog.course.totalMinutes, 780);
  assert.equal(catalog.course.clinicalReviewCompleted, false);
  assert.equal(catalog.course.legalReviewCompleted, false);
  assert.match(catalog.course.accreditation, /Non-accredited/);
  assert.deepEqual(bank.rules.criticalCapstoneIds, criticalIds);
  assert.equal(bank.rules.coreLessonIds.length, 36);
  assert.equal(bank.rules.coreAssessmentIds.length, 12);
  assert.equal(bank.rules.electivesRequiredForCoreCertificate, false);
  for (const question of bank.questions) {
    assert.equal(question.options.length, 4, question.id);
    assert.equal(new Set(question.options).size, 4, question.id);
    assert.equal(question.correctOptionId, question.optionIds[question.correctIndex], question.id);
  }
  for (const lesson of lessons) {
    assert.equal(lesson.sections.map((section) => section.text).join("\n\n"), lesson.content, lesson.id);
    assert.equal(lesson.reflection.optional, true, lesson.id);
    assert.equal(lesson.reflection.persistence, "none", lesson.id);
    assert.equal(lesson.reflection.countsForCertificate, false, lesson.id);
  }
});

test("all 5,024 marked-assessment correctness patterns obey the independent pass specification", () => {
  const forms = bank.assessments.filter((assessment) => assessment.kind !== "lesson_practice");
  assert.equal(forms.length, 20);
  let patterns = 0;
  for (const form of forms) {
    const expectedSize = form.id === "CAP01" ? 12 : form.id === "PLAN01" || form.id.startsWith("C") ? 6 : 4;
    const expectedThreshold = form.id === "CAP01" ? 10 : form.id === "PLAN01" ? 6 : form.id.startsWith("C") ? 5 : 4;
    assert.equal(form.questionIds.length, expectedSize, form.id);
    assert.equal(form.passingScore, expectedThreshold, form.id);
    const expectedCriticalIds = form.id === "CAP01" ? criticalIds : form.id === "PLAN01" ? ["PLAN01-Q01", "PLAN01-Q02", "PLAN01-Q03", "PLAN01-Q04", "PLAN01-Q05", "PLAN01-Q06"] : [];
    assert.deepEqual(form.criticalQuestionIds, expectedCriticalIds, form.id);
    for (let mask = 0; mask < 2 ** expectedSize; mask++) {
      const answers = Object.fromEntries(form.questionIds.map((id, index) => {
        const question = bank.questions.find((item) => item.id === id);
        return [id, mask & (1 << index) ? question.correctIndex : (question.correctIndex + 1) % 4];
      }));
      const expectedCritical = expectedCriticalIds.every((id) => Boolean(mask & (1 << form.questionIds.indexOf(id))));
      const result = gradeAssessment(form, bank.questions, answers);
      assert.equal(result.score, popcount(mask), `${form.id}:${mask}`);
      assert.equal(result.criticalPassed, expectedCritical, `${form.id}:${mask}`);
      assert.equal(result.passed, popcount(mask) >= expectedThreshold && expectedCritical, `${form.id}:${mask}`);
      patterns++;
    }
  }
  assert.equal(patterns, 5024);
});

test("all 24 option orders preserve every question's text, selected answer and feedback mapping", () => {
  let presentations = 0;
  for (const question of bank.questions) {
    const original = JSON.stringify(question);
    const seen = new Set();
    for (let first = 0; first < 4; first++) for (let second = 0; second < 3; second++) for (let third = 0; third < 2; third++) {
      const draws = [(first + 0.5) / 4, (second + 0.5) / 3, (third + 0.5) / 2];
      const [presented] = shuffleQuestionOptions([question], () => draws.shift());
      assert.deepEqual([...presented.optionOrder].sort(), [0, 1, 2, 3]);
      seen.add(presented.optionOrder.join(","));
      const correctDisplayPosition = presented.optionOrder.findIndex((index) => presented.options[index] === question.options[question.correctIndex]);
      const submittedIndex = presented.optionOrder[correctDisplayPosition];
      const form = { id: "mapping-check", kind: "test", title: "mapping", questionIds: [question.id], passingScore: 1, criticalQuestionIds: [], countsForCertificate: false };
      const result = gradeAssessment(form, bank.questions, { [question.id]: submittedIndex });
      assert.equal(result.passed, true, question.id);
      assert.equal(result.feedback[0].correctIndex, submittedIndex);
      assert.equal(result.feedback[0].selectedIndex, submittedIndex);
      assert.equal(presented.options[presented.optionOrder[correctDisplayPosition]], question.options[question.correctIndex]);
      presentations++;
    }
    assert.equal(seen.size, 24, question.id);
    assert.equal(JSON.stringify(question), original, "Presentation must not mutate the server bank");
  }
  assert.equal(presentations, 2736);
});

test("public catalogue omits keys and authorised assessment responses release feedback only after submission", async () => {
  fixture();
  const catalogueRoute = await route("catalog");
  const profileRoute = await route("profile");
  const orientationRoute = await route("orientation");
  const progressRoute = await route("progress");
  const assessmentRoute = await route("assessments/[id]");
  identity(null);
  const publicResponse = await catalogueRoute.GET();
  assert.equal(publicResponse.status, 200);
  const publicText = await publicResponse.text();
  assert.doesNotMatch(publicText, /"(?:correctIndex|correctOptionId|feedback|modelResponse|options)"\s*:/);
  identity("curriculum-audit-learner");
  assert.equal((await profileRoute.POST(request("/api/profile", { displayName: "Test learner", weeklyGoal: 3, adultConfirmed: true, educationAcknowledged: true }))).status, 200);
  assert.equal((await orientationRoute.POST(request("/api/orientation", {}))).status, 200);
  for (const module of catalog.modules) {
    for (const lesson of module.lessons) assert.equal((await progressRoute.POST(request("/api/progress", { lessonId: lesson.id }))).status, 200);
    assert.equal((await assessmentRoute.POST(request(`/api/assessments/${module.assessmentId}`, { answers: correctAnswers(module.assessmentId) }), context(module.assessmentId))).status, 200);
  }
  for (const form of bank.assessments) {
    const response = await assessmentRoute.GET(request(`/api/assessments/${form.id}`), context(form.id));
    assert.equal(response.status, 200, form.id);
    const text = await response.text();
    assert.doesNotMatch(text, /"(?:correctIndex|correctOptionId|feedback|modelResponse)"\s*:/, form.id);
    const payload = JSON.parse(text);
    assert.deepEqual(payload.questions.map((question) => question.id), form.questionIds);
  }
  const submitted = await assessmentRoute.POST(request("/api/assessments/PLAN01", { answers: correctAnswers("PLAN01") }), context("PLAN01"));
  const result = await submitted.json();
  assert.equal(result.passed, true);
  assert.equal(result.feedback.length, 6);
  assert.ok(result.feedback.every((item) => typeof item.feedback === "string" && Number.isInteger(item.correctIndex)));
});

test("online lessons, all 114 items and source records match the audited authoring seed", { skip: !process.argv[2] && "Pass the audited LMS JSON path to run cross-artifact parity" }, () => {
  const source = JSON.parse(readFileSync(process.argv[2], "utf8"));
  const sourceLessons = source.modules.flatMap((module) => module.lessons);
  const sourceQuestions = [...sourceLessons.flatMap((lesson) => lesson.knowledge_check), ...source.capstone.questions, ...source.capstone.planning_questions];
  assert.equal(catalog.course.version, source.course.version);
  assert.equal(bank.courseVersion, source.course.version);
  for (const original of sourceLessons) {
    const online = lessons.find((lesson) => lesson.id === original.id);
    assert.equal(online.content, original.content, original.id);
    assert.deepEqual(online.objectives, original.objectives, original.id);
    assert.deepEqual(online.sourceIds, original.source_ids, original.id);
    assert.equal(online.reflection.prompt, original.activity, original.id);
    const scenario = bank.scenarios.find((item) => item.lessonId === original.id);
    assert.equal(scenario.prompt, original.scenario.prompt, original.id);
    assert.deepEqual(scenario.options, original.scenario.options, original.id);
    assert.equal(scenario.correctIndex, original.scenario.best_option_index, original.id);
    assert.equal(scenario.feedback, original.scenario.explanation, original.id);
  }
  for (const original of sourceQuestions) {
    const online = bank.questions.find((question) => question.id === original.id);
    assert.equal(online.prompt, original.question, original.id);
    assert.deepEqual(online.options, original.options, original.id);
    assert.equal(online.correctIndex, original.correct_index, original.id);
    assert.equal(online.feedback, original.feedback, original.id);
    assert.deepEqual(online.sourceIds, original.source_ids, original.id);
  }
  assert.equal(catalog.sources.length, source.sources.length);
  for (const original of source.sources) {
    const online = catalog.sources.find((item) => item.id === original.id);
    assert.equal(online.url, original.url, original.id);
    assert.equal(online.title, original.title, original.id);
  }
  assert.equal(bank.planning.modelResponse, source.capstone.model_response);
});
