import test from "node:test";
import assert from "node:assert/strict";
import { fixture, identity, request, context, route, correctAnswers } from "./backend-runtime.mjs";

const demo = await route("demo"), me = await route("me"), profile = await route("profile"), orientation = await route("orientation"), progress = await route("progress"), lesson = await route("lessons/[id]"), assessment = await route("assessments/[id]"), resources = await route("resources"), certificate = await route("certificate"), sample = await route("demo/certificate"), checkout = await route("billing/checkout"), portal = await route("billing/portal"), exported = await route("account/export"), removed = await route("account/delete"), tutor = await route("tutor");
const AGREEMENT = { action: "start", adultConfirmed: true, educationAcknowledged: true };
function cookie(response) { return response.headers.get("set-cookie")?.split(";")[0]; }
function useCookie(value) { if (value) globalThis.__academyHeaders.set("cookie", value); else globalThis.__academyHeaders.delete("cookie"); }
function expectLearner(value) { if (value) globalThis.__academyHeaders.set("x-academy-learner", value); else globalThis.__academyHeaders.delete("x-academy-learner"); }
async function onboard() { assert.equal((await profile.POST(request("/api/profile", { displayName: "Real learner", weeklyGoal: 5, adultConfirmed: true, educationAcknowledged: true }))).status, 200); await orientation.POST(request("/api/orientation", {})); }
async function startDemo() { const response = await demo.POST(request("/api/demo", AGREEMENT)); assert.equal(response.status, 200, JSON.stringify(await response.clone().json())); useCookie(cookie(response)); return response; }
async function snapshot() { const response = await me.GET(); assert.equal(response.status, 200); return response.json(); }

test("demo entry requires verified Clerk identity, adult agreement and same-origin JSON; cookie is private and hashed", async () => {
  const db = fixture(); identity(null);
  assert.equal((await demo.GET()).status, 200);
  assert.equal((await demo.POST(request("/api/demo", AGREEMENT))).status, 401);
  identity("learner-a");
  assert.equal((await demo.POST(request("/api/demo", { action: "start" }))).status, 400);
  assert.equal((await demo.POST(request("/api/demo", AGREEMENT, { headers: { Origin: "https://other.example" } }))).status, 403);
  assert.equal((await demo.POST(request("/api/demo", "{"))).status, 400);
  const response = await startDemo(); const header = response.headers.get("set-cookie");
  for (const attribute of ["__Host-fsa-demo=", "Path=/", "HttpOnly", "Secure", "SameSite=Strict"]) assert.ok(header.includes(attribute), attribute);
  const token = cookie(response).split("=")[1]; assert.match(token, /^[a-f0-9]{64}$/);
  const session = db.sqlite.prepare("SELECT * FROM demo_sessions").get();
  assert.notEqual(session.token_hash, token); assert.equal(session.owner_user_id, "learner-a");
  assert.match(session.demo_user_id, /^demo:/); assert.ok(new Date(session.expires_at).getTime() > Date.now() + 119 * 60000);
  const data = await snapshot(); assert.equal(data.demo.active, true); assert.equal(data.demo.tier, "plus");
  assert.equal(data.billing.mode, "demo"); assert.equal(data.billing.checkoutAvailable, false); assert.equal(data.billing.hasCustomer, false);
  assert.equal(data.user.email, ""); assert.equal(JSON.stringify(data).includes("learner-a@example.test"), false);
  assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM profiles WHERE user_id='learner-a'").get().n, 0, "Demo entry does not create or overwrite a real learner profile");
});

test("Plus demo exercises actual paid lesson, progress, assessment and toolkit routes in live access mode", async () => {
  const db = fixture(); await onboard(); globalThis.__academyEnv.APP_MODE = "live";
  assert.equal((await lesson.GET(request("/api/lessons/C03-L01"), context("C03-L01"))).status, 402);
  await startDemo(); let data = await snapshot(); const demoId = data.user.userId;
  assert.equal(data.progress.completedLessonIds.length, 6); assert.deepEqual(data.progress.passedAssessmentIds, ["C01-TEST"]); assert.equal(data.progress.xp, 250);
  assert.equal((await lesson.GET(request("/api/lessons/C03-L01"), context("C03-L01"))).status, 200);
  for (let count = 0; count < 2; count++) assert.equal((await progress.POST(request("/api/progress", { lessonId: "C03-L01" }))).status, 200);
  const check = await assessment.GET(request("/api/assessments/C02-TEST"), context("C02-TEST")); assert.equal(check.status, 200);
  assert.equal(JSON.stringify(await check.json()).includes("correctIndex"), false);
  const submitted = await assessment.POST(request("/api/assessments/C02-TEST", { answers: correctAnswers("C02-TEST") }), context("C02-TEST")); assert.equal(submitted.status, 200); assert.equal((await submitted.json()).passed, true);
  const toolkit = await (await resources.GET()).json(); assert.equal(toolkit.toolkitAvailable, true); assert.ok(toolkit.worksheets.every(item => item.prompts?.length));
  data = await snapshot(); assert.equal(data.progress.xp, 375); assert.equal(data.progress.completedLessonIds.length, 7);
  assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM lesson_progress WHERE user_id='learner-a'").get().n, 0);
  assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM entitlements WHERE user_id='learner-a'").get().n, 0);
  assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM assessment_attempts WHERE user_id=?").get(demoId).n, 1);
});

test("demo cannot purchase, open billing, export/delete a real account or issue a real certificate", async () => {
  const db = fixture(); await onboard(); await startDemo();
  const originalFetch = globalThis.fetch; let externalCalls = 0;
  globalThis.fetch = async () => { externalCalls++; throw new Error("A demonstration must not reach a payment provider"); };
  try {
    for (const response of [
      await checkout.POST(request("/api/billing/checkout", { product: "plus_monthly", renewalConsent: true })),
      await portal.POST(request("/api/billing/portal", {})),
      await exported.GET(),
      await removed.POST(request("/api/account/delete", { confirmation: "DELETE MY ACCOUNT" })),
      await certificate.POST(request("/api/certificate", {})),
      await certificate.GET(request("/api/certificate?download=1")),
    ]) { assert.equal(response.status, 403); assert.equal((await response.json()).code, "demo_action_unavailable"); }
    assert.equal(externalCalls, 0);
  } finally { globalThis.fetch = originalFetch; }
  const preview = await sample.GET(); assert.equal(preview.status, 200); assert.equal(preview.headers.get("cache-control"), "private, no-store");
  const html = await preview.text(); assert.match(html, /DEMONSTRATION · NOT VALID/); assert.match(html, /No learning achievement is certified/);
  assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM certificates").get().n, 0);
  const changed = await profile.POST(request("/api/profile", { displayName: "Demo nickname", externalAiConsent: true })); assert.equal(changed.status, 200);
  assert.equal(db.sqlite.prepare("SELECT external_ai_consent_at AS consent FROM profiles WHERE user_id LIKE 'demo:%'").get().consent, null);
  assert.equal(db.sqlite.prepare("SELECT display_name AS name FROM profiles WHERE user_id='learner-a'").get().name, "Real learner");
});

test("demo guide cannot call external AI or consume paid quota even when live AI is configured", async () => {
  const db = fixture(); await startDemo();
  Object.assign(globalThis.__academyEnv, { APP_MODE: "live", RELEASE_APPROVED: "true", AI_RELEASE_APPROVED: "true", OPENAI_API_KEY: "test-not-real", OPENAI_MODEL: "test-model" });
  const originalFetch = globalThis.fetch; let externalCalls = 0;
  globalThis.fetch = async () => { externalCalls++; throw new Error("Demo must not call external AI"); };
  try {
    const response = await tutor.POST(request("/api/tutor", { message: "Explain consent", lessonId: "C01-L01", consentToAI: true })); assert.equal(response.status, 200);
    const answer = await response.json(); assert.equal(answer.mode, "lesson-guide"); assert.equal(answer.externalProcessing, false); assert.ok(answer.answer.length > 80);
    assert.equal(externalCalls, 0); assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM tutor_usage WHERE bucket NOT LIKE 'minute:%'").get().n, 0);
    assert.equal((await snapshot()).tutor.externalProcessingConsent, false);
  } finally { globalThis.fetch = originalFetch; }
});

test("reset rotates authority, removes sample writes, bounds sessions and fails stale tabs closed", async () => {
  const db = fixture(); await onboard(); const first = await startDemo(); const oldCookie = cookie(first); const oldId = (await snapshot()).user.userId;
  await progress.POST(request("/api/progress", { lessonId: "C03-L01" }));
  const reset = await demo.POST(request("/api/demo", { action: "reset" })); assert.equal(reset.status, 200); const newCookie = cookie(reset); assert.notEqual(newCookie, oldCookie);
  useCookie(newCookie); const current = await snapshot(); assert.notEqual(current.user.userId, oldId); assert.equal(current.progress.completedLessonIds.length, 6);
  assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM profiles WHERE user_id=?").get(oldId).n, 0); assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM demo_sessions").get().n, 1);
  useCookie(oldCookie); const stale = await progress.POST(request("/api/progress", { lessonId: "C03-L02" })); assert.equal(stale.status, 409); assert.equal((await stale.json()).code, "demo_expired");
  useCookie(newCookie); expectLearner(oldId); const crossTab = await progress.POST(request("/api/progress", { lessonId: "C03-L02" })); assert.equal(crossTab.status, 409); assert.equal((await crossTab.json()).code, "learner_session_changed");
  assert.equal((await me.GET()).status, 200, "Me can refresh a stale tab's effective identity");
  expectLearner(null); assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM lesson_progress WHERE user_id='learner-a'").get().n, 0);
});

test("cookie theft, tampering and expiry cannot select another visitor or fall through to real writes", async () => {
  const db = fixture(); await onboard(); const opened = await startDemo(); const originalCookie = cookie(opened);
  identity("learner-b"); await onboard(); useCookie(originalCookie);
  const other = await me.GET(); assert.equal(other.status, 409); assert.equal((await other.json()).code, "demo_expired");
  assert.equal((await progress.POST(request("/api/progress", { lessonId: "C01-L01" }))).status, 409);
  identity("learner-a"); useCookie("__Host-fsa-demo=tampered"); assert.equal((await me.GET()).status, 409);
  useCookie(originalCookie); db.sqlite.prepare("UPDATE demo_sessions SET expires_at=?").run(new Date(Date.now() - 1000).toISOString());
  assert.equal((await progress.POST(request("/api/progress", { lessonId: "C01-L01" }))).status, 409);
  const status = await (await demo.GET()).json(); assert.equal(status.active, false); assert.equal(status.expired, true);
  assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM lesson_progress WHERE user_id IN ('learner-a','learner-b')").get().n, 0);
});

test("exit removes all demo records and restores real profile; an old demo tab cannot write to it", async () => {
  const db = fixture(); await onboard(); await progress.POST(request("/api/progress", { lessonId: "C01-L01" }));
  const before = await snapshot(); await startDemo(); const demoId = (await snapshot()).user.userId;
  const exit = await demo.POST(request("/api/demo", { action: "exit" })); assert.equal(exit.status, 200); assert.match(exit.headers.get("set-cookie"), /Max-Age=0/);
  useCookie(null); expectLearner(demoId);
  const staleTab = await progress.POST(request("/api/progress", { lessonId: "C02-L01" })); assert.equal(staleTab.status, 409); assert.equal((await staleTab.json()).code, "learner_session_changed");
  const after = await snapshot(); assert.equal(after.user.userId, "learner-a"); assert.deepEqual(after.profile, before.profile); assert.deepEqual(after.progress, before.progress); assert.equal(after.demo, null);
  assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM demo_sessions").get().n, 0); assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM profiles WHERE user_id LIKE 'demo:%'").get().n, 0);
  expectLearner(null); assert.equal((await sample.GET()).status, 403);
});

test("recurring payment consent is enforced before contacting a provider", async () => {
  fixture(); await onboard();
  Object.assign(globalThis.__academyEnv, { APP_MODE: "live", RELEASE_APPROVED: "true", PROCESSOR_APPROVED: "true", APP_ORIGIN: "https://academy.example.test", STRIPE_SECRET_KEY: "test-not-real", STRIPE_WEBHOOK_SECRET: "test-not-real", STRIPE_PRICE_ACADEMY_MONTHLY: "price_test" });
  const originalFetch = globalThis.fetch; let calls = 0;
  globalThis.fetch = async () => { calls++; return Response.json({ id: "price_test", active: true, currency: "usd", unit_amount: 1, recurring: { interval: "month", interval_count: 1 } }); };
  try {
    for (const consent of [undefined, false, "true", 1]) {
      const response = await checkout.POST(request("/api/billing/checkout", { product: "academy_monthly", renewalConsent: consent })); assert.equal(response.status, 400); assert.equal((await response.json()).code, "renewal_consent_required");
    }
    assert.equal(calls, 0);
    const consented = await checkout.POST(request("/api/billing/checkout", { product: "academy_monthly", renewalConsent: true })); assert.equal(consented.status, 503); assert.equal((await consented.json()).code, "price_mismatch"); assert.equal(calls, 1);
  } finally { globalThis.fetch = originalFetch; }
});

test("the actual client request helper refreshes its scope and protects an old demo tab after exit", async () => {
  const db = fixture(); await onboard();
  const client = await import("../lib/academy/types.ts");
  const previousWindow = globalThis.window, originalFetch = globalThis.fetch;
  globalThis.window = {};
  globalThis.fetch = async (path, init = {}) => {
    const suppliedHeaders = new Headers(init.headers);
    expectLearner(suppliedHeaders.get("x-academy-learner"));
    if (path === "/api/me") return me.GET();
    if (path === "/api/progress") return progress.POST(request(path, JSON.parse(init.body)));
    throw new Error(`Unexpected client request: ${path}`);
  };
  try {
    assert.equal((await client.request("/api/me")).user.userId, "learner-a");
    await startDemo(); const selected = await client.request("/api/me"); assert.match(selected.user.userId, /^demo:/);
    await client.post("/api/progress", { lessonId: "C03-L01" });
    await demo.POST(request("/api/demo", { action: "exit" })); useCookie(null);
    await assert.rejects(client.post("/api/progress", { lessonId: "C01-L02" }), error => error.status === 409 && error.data.code === "learner_session_changed");
    assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM lesson_progress WHERE user_id='learner-a'").get().n, 0);
    assert.equal((await client.request("/api/me")).user.userId, "learner-a");
    assert.equal((await client.post("/api/progress", { lessonId: "C01-L02" })).completed, true);
    assert.equal(db.sqlite.prepare("SELECT count(*) AS n FROM lesson_progress WHERE user_id='learner-a'").get().n, 1);
  } finally {
    globalThis.fetch = originalFetch;
    if (previousWindow === undefined) delete globalThis.window; else globalThis.window = previousWindow;
  }
});
