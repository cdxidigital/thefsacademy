import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { runInThisContext } from 'node:vm';
import ts from 'typescript';

const source = readFileSync(new URL('../components/academy/promo-playback.ts', import.meta.url), 'utf8');
const code = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const module = { exports: {} };
runInThisContext(`(function(module,exports){${code}\n})`)(module, module.exports);
const { createPromoPlaybackSession, shouldPlayPromo } = module.exports;
const film = '/media/academy-promo-v2.mp4';
const base = { ready: true, onscreen: true, visible: true, motionEnabled: true, reducedMotion: false, intent: 'automatic', ended: false, failed: false, automaticBlocked: false, automaticAvailable: true };
function store() {
  const values = new Map();
  const storage = { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) };
  return { values, options: { storage: () => storage, memory: new Set() } };
}

test('waiting behind the gate, outside the viewport, or under motion preferences does not use the film', () => {
  const { values, options } = store(), session = createPromoPlaybackSession(film, options);
  for (const condition of [{ ready: false }, { onscreen: false }, { visible: false }, { motionEnabled: false }, { reducedMotion: true }]) {
    assert.equal(shouldPlayPromo({ ...base, ...condition, automaticAvailable: session.automaticAvailable() }), false);
  }
  assert.equal(values.size, 0);
  assert.equal(session.automaticAvailable(), true);
});

test('a successful automatic run resumes after visibility pauses but cannot restart on a new visit', () => {
  const { options } = store(), session = createPromoPlaybackSession(film, options);
  session.recordStarted('automatic');
  assert.equal(shouldPlayPromo({ ...base, visible: false, automaticAvailable: session.automaticAvailable() }), false);
  assert.equal(shouldPlayPromo({ ...base, automaticAvailable: session.automaticAvailable() }), true);
  const revisited = createPromoPlaybackSession(film, options);
  assert.equal(shouldPlayPromo({ ...base, automaticAvailable: revisited.automaticAvailable() }), false);
});

test('session storage prevents a fresh-page replay within the same tab', () => {
  const { options } = store();
  createPromoPlaybackSession(film, options).recordStarted('automatic');
  const reloaded = createPromoPlaybackSession(film, { ...options, memory: new Set() });
  assert.equal(reloaded.automaticAvailable(), false);
});

test('a different versioned film receives its own automatic run', () => {
  const { options } = store();
  createPromoPlaybackSession(film, options).recordStarted('automatic');
  assert.equal(createPromoPlaybackSession('/media/academy-promo-v3.mp4', options).automaticAvailable(), true);
  assert.equal(createPromoPlaybackSession(film, options).automaticAvailable(), false);
});

test('manual viewing counts as watched and explicit replay remains available', () => {
  const { options } = store();
  createPromoPlaybackSession(film, options).recordStarted('manual');
  const revisited = createPromoPlaybackSession(film, options);
  assert.equal(revisited.automaticAvailable(), false);
  assert.equal(shouldPlayPromo({ ...base, intent: 'manual', automaticAvailable: false, motionEnabled: false, reducedMotion: true }), true);
  assert.equal(shouldPlayPromo({ ...base, intent: 'manual', automaticAvailable: false, ready: false }), false);
});

test('an ended film never loops; Replay must reset its ended state explicitly', () => {
  const { options } = store(), session = createPromoPlaybackSession(film, options);
  session.recordStarted('automatic');
  assert.equal(shouldPlayPromo({ ...base, ended: true, automaticAvailable: session.automaticAvailable() }), false);
  assert.equal(shouldPlayPromo({ ...base, intent: 'paused', automaticAvailable: session.automaticAvailable() }), false);
  assert.equal(shouldPlayPromo({ ...base, intent: 'manual', ended: false, automaticAvailable: false }), true);
});

test('rejected autoplay leaves manual Play available without claiming the film played', () => {
  const { options, values } = store(), session = createPromoPlaybackSession(film, options);
  assert.equal(shouldPlayPromo({ ...base, automaticBlocked: true, automaticAvailable: session.automaticAvailable() }), false);
  assert.equal(shouldPlayPromo({ ...base, intent: 'manual', automaticBlocked: true }), true);
  assert.equal(values.size, 0);
  assert.equal(createPromoPlaybackSession(film, options).automaticAvailable(), true);
});

test('denied storage access safely preserves once behavior during in-page navigation', () => {
  const options = { storage: () => { throw new Error('Storage unavailable'); }, memory: new Set() };
  const session = createPromoPlaybackSession(film, options);
  assert.equal(session.automaticAvailable(), true);
  assert.doesNotThrow(() => session.recordStarted('automatic'));
  assert.equal(session.automaticAvailable(), true);
  assert.equal(createPromoPlaybackSession(film, options).automaticAvailable(), false);
});

test('a storage write refusal cannot lose the already-started in-memory record', () => {
  const options = { storage: () => ({ getItem: () => null, setItem: () => { throw new Error('Quota exceeded'); } }), memory: new Set() };
  assert.doesNotThrow(() => createPromoPlaybackSession(film, options).recordStarted('manual'));
  assert.equal(createPromoPlaybackSession(film, options).automaticAvailable(), false);
});
