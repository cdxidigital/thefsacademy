import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInThisContext} from 'node:vm';
import ts from 'typescript';

// Execute the actual TSX hooks and event handlers with a small isolated hook
// harness. This verifies request/state decisions, not browser rendering.
let active;
const element=(type,props,key)=>({type,props:props??{},key});
const hooks={
 useRef(value){const owner=active,index=owner.cursor++;return owner.slots[index]??(owner.slots[index]={current:value});},
 useState(value){const owner=active,index=owner.cursor++;owner.slots[index]??={value:typeof value==='function'?value():value};return [owner.slots[index].value,next=>{owner.slots[index].value=typeof next==='function'?next(owner.slots[index].value):next;owner.dirty=true;}];},
 useEffect(effect,deps){const owner=active,index=owner.cursor++,old=owner.slots[index];if(!old||deps.some((value,i)=>!Object.is(value,old.deps[i]))){owner.slots[index]={deps};owner.pending.push(()=>{old?.cleanup?.();owner.slots[index].cleanup=effect();});}},
};
function compile(path,requireModule){const code=ts.transpileModule(readFileSync(new URL(path,import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText;const module={exports:{}};runInThisContext(`(function(require,module,exports){${code}\n})`,{filename:path})(requireModule,module,module.exports);return module.exports;}
const personas=compile('../lib/academy/tutor-personas.ts',()=>{throw new Error('Persona config must be client-safe');});
const api=compile('../lib/academy/types.ts',()=>{throw new Error('Unexpected API dependency');});
const {default:Tutor}=compile('../components/academy/tutor.tsx',id=>{
 if(id==='react')return hooks;
 if(id==='react/jsx-runtime')return {jsx:element,jsxs:element,Fragment:'Fragment'};
 if(id==='next/link')return {__esModule:true,default:'Link'};
 if(id==='next/navigation')return {useSearchParams:()=>new URLSearchParams(active.query)};
 if(id==='lucide-react')return new Proxy({},{get:(_target,key)=>key});
 if(id==='./ui')return new Proxy({useAcademy:()=>active.context},{get:(target,key)=>target[key]??key});
 if(id==='@/lib/academy/types')return api;
 if(id==='@/lib/academy/tutor-personas')return personas;
 throw new Error(`Unexpected tutor dependency ${id}`);
});
function harness(component,context,props={}){
 const view={component,context,props,query:'',slots:[],pending:[],cursor:0,dirty:false,tree:null};
 view.render=()=>{let count=0;do{view.cursor=0;view.pending=[];view.dirty=false;active=view;view.tree=component(view.props);for(const effect of view.pending)effect();assert.ok(++count<8);}while(view.dirty);return view.tree;};
 view.unmount=()=>{for(const slot of view.slots)slot?.cleanup?.();};return view;
}
function find(node,predicate){if(!node||typeof node!=='object')return; if(Array.isArray(node)){for(const child of node){const result=find(child,predicate);if(result)return result;}return;}if(predicate(node))return node;return find(node.props?.children,predicate);}
function textOf(node){if(node==null||typeof node==='boolean')return '';if(typeof node!=='object')return String(node);if(Array.isArray(node))return node.map(textOf).join(' ');return textOf(node.props?.children);}
function session(view){const found=find(view.tree,node=>typeof node.type==='function'&&node.type.name==='TutorSession');assert.ok(found);return found;}
function button(view,label){const result=find(view.tree,node=>node.type==='button'&&textOf(node).includes(label));assert.ok(result,`button ${label}`);return result;}
function browserStubs(t){for(const [name,value]of Object.entries({window:{matchMedia:()=>({matches:true})},document:{documentElement:{dataset:{motion:'off'}}}})){const descriptor=Object.getOwnPropertyDescriptor(globalThis,name);Object.defineProperty(globalThis,name,{configurable:true,value});t.after(()=>{if(descriptor)Object.defineProperty(globalThis,name,descriptor);else delete globalThis[name];});}}
function context(){return {catalog:{modules:[{id:'C01',title:'Consent',assessmentId:'C01-TEST',lessons:[{id:'C01-L01',title:'Consent is a choice'},{id:'C01-L02',title:'Capacity and access'}]},{id:'C02',title:'Communication',assessmentId:'C02-TEST',lessons:[{id:'C02-L01',title:'Ask and listen'}]}]},me:{user:{userId:'learner-a'},profile:{displayName:'Learner'},progress:{assessmentResults:[]},billing:{mode:'pilot'},tutor:{mode:'lesson-guide'}},loading:false,loadError:'',refresh:async()=>{}};}
const guide={role:'foundations_tutor',tutorTitle:'Foundations Tutor',mode:'lesson-guide',answer:'An educational reply from the course.',sources:[],lessonLinks:[],externalProcessing:false};
const flush=()=>new Promise(resolve=>setImmediate(resolve));

 test('three source-defined tutor identities change the scoped conversation and teaching role',()=>{
 const state=context(),parent=harness(Tutor,state);parent.render();const first=session(parent);
 for(const role of personas.TUTOR_PERSONAS){const control=button(parent,role.title);control.props.onClick();parent.render();const child=session(parent);assert.equal(child.props.role,role.id);assert.equal(button(parent,role.title).props['aria-pressed'],true);if(role.id!=='foundations_tutor')assert.notEqual(child.key,first.key);}
 assert.match(textOf(parent.tree),/Live AI is not connected/);
});

test('a changed same-route lesson query supersedes the previous dropdown choice immediately',()=>{
 const parent=harness(Tutor,context());parent.query='lesson=C01-L01';parent.render();session(parent).props.onLesson('C02-L01');parent.render();assert.equal(session(parent).props.lessonId,'C02-L01');
 const previousKey=session(parent).key;parent.query='lesson=C01-L02';parent.render();assert.equal(session(parent).props.lessonId,'C01-L02');assert.notEqual(session(parent).key,previousKey);
});

test('entering or exiting demo remounts the conversation and unmount aborts an old reply',async t=>{
 browserStubs(t);const state=context(),parent=harness(Tutor,state);parent.render();const first=session(parent),child=harness(first.type,state,first.props);child.render();
 let release,signal; t.mock.method(globalThis,'fetch',async(_path,init)=>{signal=init.signal;await new Promise(resolve=>{release=resolve;});return Response.json(guide);});
 find(child.tree,node=>node.type==='textarea').props.onChange({target:{value:'A prior learner question'}});child.render();const pending=find(child.tree,node=>node.type==='form').props.onSubmit({preventDefault(){}});child.render();assert.match(textOf(child.tree),/A prior learner question/);
 state.me={...state.me,user:{userId:'demo:isolated'},demo:{active:true,expiresAt:'2030-01-01T01:00:00Z'},billing:{mode:'demo'}};parent.render();const demo=session(parent);assert.notEqual(demo.key,first.key);child.unmount();assert.equal(signal.aborted,true);
 const demoChild=harness(demo.type,state,demo.props);demoChild.render();assert.equal(find(demoChild.tree,node=>node.type==='textarea').props.value,'');assert.equal(textOf(demoChild.tree).includes('A prior learner question'),false);
 release();await pending;assert.equal(textOf(demoChild.tree).includes(guide.answer),false);assert.match(textOf(demoChild.tree),/Demonstration.*no AI usage/);
 state.me={...state.me,user:{userId:'learner-a'},demo:null,billing:{mode:'pilot'}};parent.render();assert.notEqual(session(parent).key,demo.key);demoChild.unmount();
});

test('actual composer submits the chosen role and bounded ephemeral context once, without losing a reply on refresh failure',async t=>{
 browserStubs(t);const state=context();state.me.tutor={mode:'ai',externalProcessingConsent:true,monthlyLimit:50,monthlyUsed:0};state.refresh=async()=>{throw new Error('Refresh unavailable');};
 const parent=harness(Tutor,state);parent.render();const childNode=session(parent),child=harness(childNode.type,state,childNode.props);child.render();const bodies=[];
 t.mock.method(globalThis,'fetch',async(_path,init)=>{bodies.push(JSON.parse(init.body));return Response.json({...guide,mode:'ai',externalProcessing:true,answer:'é'.repeat(1600)});});
 find(child.tree,node=>node.type==='textarea').props.onChange({target:{value:'Explain one idea.'}});child.render();const send=find(child.tree,node=>node.type==='form').props.onSubmit;const first=send({preventDefault(){}});await send({preventDefault(){}});await first;await flush();child.render();assert.equal(bodies.length,1);assert.equal(bodies[0].role,'foundations_tutor');assert.equal(bodies[0].consentToAI,true);assert.match(textOf(child.tree),/Your reply is ready/);assert.equal(find(child.tree,node=>node.type==='ErrorPanel'),undefined);
 find(child.tree,node=>node.type==='textarea').props.onChange({target:{value:'Can you explain that again?'}});child.render();await find(child.tree,node=>node.type==='form').props.onSubmit({preventDefault(){}});child.render();assert.equal(bodies.length,2);assert.equal(bodies[1].history.length,2);assert.equal(bodies[1].history[0].role,'user');assert.ok(bodies[1].history.every(turn=>turn.content.length<=500));assert.ok(new TextEncoder().encode(JSON.stringify(bodies[1])).length<=6000);
 find(child.tree,node=>node.type==='textarea').props.onChange({target:{value:'学'.repeat(1200)}});child.render();await find(child.tree,node=>node.type==='form').props.onSubmit({preventDefault(){}});child.render();assert.equal(bodies.length,3);assert.equal(bodies[2].message.length,1200);assert.ok(bodies[2].history.length<4);assert.ok(new TextEncoder().encode(JSON.stringify(bodies[2])).length<=6000);
 button(child,'Clear this conversation').props.onClick();child.render();assert.equal(textOf(child.tree).includes('ééé'),false);child.unmount();
});

test('Practice Coach choice buttons and a typed B submit the server scenario identifier',async t=>{
 browserStubs(t);const state=context(),parent=harness(Tutor,state);parent.render();button(parent,'Practice Coach').props.onClick();parent.render();const node=session(parent),child=harness(node.type,state,node.props);child.render();const bodies=[];
 const exercise={...guide,role:'practice_coach',practice:{scenarioId:'C01-L01-SCENARIO',lessonId:'C01-L01',prompt:'Fictional adults choose.',options:['Pressure','Accept the boundary'],stage:'question',countsForCertificate:false}};
 t.mock.method(globalThis,'fetch',async(_path,init)=>{const body=JSON.parse(init.body);bodies.push(body);return Response.json(body.practice?{...exercise,practice:{...exercise.practice,stage:'feedback',selectedIndex:body.practice.choiceIndex,correct:true}}:body.message.startsWith('Why')?{...guide,role:'practice_coach'}:exercise);});
 button(child,'Give me a fictional practice example.').props.onClick();await flush();child.render();assert.equal(bodies[0].role,'practice_coach');assert.equal(bodies[0].mode,'scenario');
 button(child,'Accept the boundary').props.onClick();await flush();child.render();assert.deepEqual(bodies[1].practice,{scenarioId:'C01-L01-SCENARIO',choiceIndex:1});
 find(child.tree,node=>node.type==='textarea').props.onChange({target:{value:'Why is the first answer less respectful?'}});child.render();await find(child.tree,node=>node.type==='form').props.onSubmit({preventDefault(){}});child.render();assert.equal(bodies[2].mode,'explain');assert.equal(bodies[2].practice,undefined);
 find(child.tree,node=>node.type==='textarea').props.onChange({target:{value:'Give me another fictional example.'}});child.render();await find(child.tree,node=>node.type==='form').props.onSubmit({preventDefault(){}});child.render();
 find(child.tree,node=>node.type==='textarea').props.onChange({target:{value:'B'}});child.render();await find(child.tree,node=>node.type==='form').props.onSubmit({preventDefault(){}});assert.deepEqual(bodies[4].practice,{scenarioId:'C01-L01-SCENARIO',choiceIndex:1});child.unmount();
});
