import { registerHooks } from "node:module";
import { readFileSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import ts from "typescript";
import { DatabaseSync } from "node:sqlite";

export const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// This fixture changes only the process of this test file. The application still
// imports its real Node runtime and verified Clerk identity wrapper. Database and
// Clerk SDK responses are isolated test boundaries; no fixture is shipped in a
// production authentication path and no network account or database is contacted.
const environmentKeys = new Set([
  "APP_MODE", "APP_ORIGIN", "PROCESSOR_APPROVED", "RELEASE_APPROVED",
  "STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET", "STRIPE_PRICE_ACADEMY_MONTHLY",
  "STRIPE_PRICE_ACADEMY_YEARLY", "STRIPE_PRICE_PLUS_MONTHLY", "STRIPE_PRICE_PLUS_YEARLY",
  "STRIPE_PRICE_MODULE", "STRIPE_PRICE_TOOLKIT", "STRIPE_PRICE_TUTOR_PACK",
  "OPENAI_API_KEY", "OPENAI_MODEL", "AI_RELEASE_APPROVED",
  "TURSO_DATABASE_URL", "TURSO_AUTH_TOKEN", "LIBSQL_ALLOW_LOCAL",
  "NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY", "CLERK_SECRET_KEY",
]);
for (const key of environmentKeys) delete process.env[key];
globalThis.__academyTestDatabase = null;
// Keep existing route fixtures concise while exercising actual process.env reads.
// The DB object is test-only state and is never assigned to process.env.
globalThis.__academyEnv = new Proxy({}, {
  get(_target, key) { return key === "DB" ? globalThis.__academyTestDatabase : typeof key === "string" ? process.env[key] : undefined; },
  set(_target, key, value) {
    if (key === "DB") globalThis.__academyTestDatabase = value;
    else if (typeof key === "string") {
      environmentKeys.add(key);
      if (value === undefined || value === null) delete process.env[key];
      else process.env[key] = String(value);
    }
    return true;
  },
  ownKeys() { return ["DB", ...environmentKeys]; },
  getOwnPropertyDescriptor() { return { enumerable: true, configurable: true }; },
  deleteProperty(_target, key) {
    if (key === "DB") globalThis.__academyTestDatabase = null;
    else if (typeof key === "string") delete process.env[key];
    return true;
  },
});
globalThis.__academyHeaders = new Headers();
globalThis.__academyClerkAuth = { userId: null };
globalThis.__academyClerkUser = null;
const special = {
  // Next enforces this build-time server boundary; isolated Node tests have no
  // client bundle and need only the marker, not its unconditional Node throw.
  "server-only": "export {};",
  "@clerk/nextjs/server": "export async function auth() { return globalThis.__academyClerkAuth; } export async function currentUser() { return globalThis.__academyClerkUser; }",
  "next/headers": "export async function headers() { return globalThis.__academyHeaders; }",
  "next/navigation": "export function redirect(path) { throw new Error('redirect:'+path); }",
};
const databaseFixture = "export function configuredDatabase() { return globalThis.__academyTestDatabase; }";
registerHooks({
  resolve(specifier, context, nextResolve) {
    if (special[specifier]) return { url: `data:text/javascript,${encodeURIComponent(special[specifier])}`, shortCircuit: true };
    let candidate;
    if (specifier.startsWith("@/")) candidate = path.join(root, specifier.slice(2));
    else if (specifier.startsWith(".") && context.parentURL?.startsWith(pathToFileURL(root).href)) candidate = path.resolve(path.dirname(fileURLToPath(context.parentURL)), specifier);
    if (candidate) {
      // Mock only the runtime's DB factory boundary. Importing database.ts directly
      // still loads the real Turso adapter, allowing its own dedicated tests.
      if ([path.join(root, "lib/server/database"), path.join(root, "lib/server/database.ts")].includes(candidate)
          && context.parentURL === pathToFileURL(path.join(root, "lib/server/runtime.ts")).href) {
        return { url: `data:text/javascript,${encodeURIComponent(databaseFixture)}`, shortCircuit: true };
      }
      const resolved = [candidate, `${candidate}.ts`, `${candidate}.tsx`, `${candidate}/index.ts`].find((item) => existsSync(item));
      if (resolved) return { url: pathToFileURL(resolved).href, shortCircuit: true };
    }
    return nextResolve(specifier, context);
  },
  load(url, context, nextLoad) {
    if (url.startsWith("file:") && /\.tsx?$/.test(url)) return { format: "module", source: ts.transpileModule(readFileSync(fileURLToPath(url), "utf8"), { compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX } }).outputText, shortCircuit: true };
    if (url.startsWith("file:") && url.endsWith(".json")) return { format: "module", source: `export default ${readFileSync(fileURLToPath(url), "utf8")}`, shortCircuit: true };
    return nextLoad(url, context);
  },
});

export function makeDatabase() {
  const sqlite = new DatabaseSync(":memory:"); sqlite.exec("PRAGMA foreign_keys=ON");
  const journal = JSON.parse(readFileSync(path.join(root, "drizzle/meta/_journal.json"), "utf8"));
  for (const item of journal.entries) sqlite.exec(readFileSync(path.join(root, `drizzle/${item.tag}.sql`), "utf8").replaceAll("--> statement-breakpoint", ""));
  class Prepared {
    constructor(sql, values = []) { this.sql = sql; this.values = values; }
    bind(...values) { return new Prepared(this.sql, values); }
    async first(column) { const row = sqlite.prepare(this.sql).get(...this.values) ?? null; return column && row ? row[column] : row; }
    async all() { return { success: true, results: sqlite.prepare(this.sql).all(...this.values), meta: {} }; }
    async run() { const result = sqlite.prepare(this.sql).run(...this.values); return { success: true, results: [], meta: { changes: Number(result.changes) } }; }
  }
  return {
    sqlite,
    prepare(sql) { return new Prepared(sql); },
    async batch(statements) { sqlite.exec("BEGIN"); try { const result = []; for (const statement of statements) result.push(await statement.run()); sqlite.exec("COMMIT"); return result; } catch (error) { sqlite.exec("ROLLBACK"); throw error; } },
  };
}
export function fixture() {
  const db = makeDatabase(); Object.keys(globalThis.__academyEnv).forEach((key) => delete globalThis.__academyEnv[key]);
  Object.assign(globalThis.__academyEnv, {
    DB: db, APP_MODE: "pilot",
    NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: "pk_test_fixture_not_a_real_key",
    CLERK_SECRET_KEY: "sk_test_fixture_not_a_real_key",
  });
  identity("learner-a"); return db;
}
export function identity(id) {
  globalThis.__academyHeaders = new Headers();
  globalThis.__academyClerkAuth = { userId: id || null };
  globalThis.__academyClerkUser = id ? {
    id, primaryEmailAddress: { emailAddress: `${id}@example.test`, verification: { status: "verified" } },
    fullName: `Fixture ${id}`, firstName: "Fixture", lastName: id,
  } : null;
}
export function request(pathname, body, options = {}) {
  const method = body === undefined ? "GET" : "POST";
  return new Request(`https://academy.example.test${pathname}`, { method, headers: { ...(body === undefined ? {} : { "Content-Type": "application/json", Origin: "https://academy.example.test" }), ...options.headers }, body: body === undefined ? undefined : typeof body === "string" ? body : JSON.stringify(body) });
}
export function context(id) { return { params: Promise.resolve({ id }) }; }
export async function route(relative) { return import(pathToFileURL(path.join(root, `app/api/${relative}/route.ts`)).href); }
export const catalog = JSON.parse(readFileSync(path.join(root, "data/catalog.json"), "utf8"));
export const bank = JSON.parse(readFileSync(path.join(root, "data/assessments.json"), "utf8"));
export function correctAnswers(id) { const assessment = bank.assessments.find((item) => item.id === id); return Object.fromEntries(assessment.questionIds.map((questionId) => [questionId, bank.questions.find((item) => item.id === questionId).correctIndex])); }
