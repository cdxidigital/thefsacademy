import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInThisContext} from 'node:vm';
import ts from 'typescript';
import React from 'react';
import * as jsx from 'react/jsx-runtime';
import {renderToStaticMarkup} from 'react-dom/server';

// Render the actual demo components with controlled account context. This checks
// the three entry states; it does not simulate a browser, layout or hydration.
let context;
const ui = {
 useAcademy:()=>context,
 ButtonLink:({href,children})=>React.createElement('a',{href},children),
 ErrorPanel:({message})=>React.createElement('div',{role:'alert'},message),
 PageHeading:({title,description})=>React.createElement(React.Fragment,null,React.createElement('h1',null,title),React.createElement('p',null,description)),
};
const compiled = ts.transpileModule(readFileSync(new URL('../components/academy/demo.tsx',import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText;
const module={exports:{}};
runInThisContext(`(function(require,module,exports){${compiled}\n})`) (id=>{
 if(id==='react')return React;
 if(id==='react/jsx-runtime')return jsx;
 if(id==='next/link')return {__esModule:true,default:({href,children})=>React.createElement('a',{href},children)};
 if(id==='lucide-react')return new Proxy({},{get:()=>()=>React.createElement('svg',{'aria-hidden':'true'})});
 if(id==='./ui')return ui;
 if(id==='./demo.css')return {};
 if(id==='@/lib/academy/types')return {request:()=>{throw new Error('Render must not request account data')},post:()=>{throw new Error('Render must not create a demonstration')}};
 throw new Error(`Unexpected module ${id}`);
},module,module.exports);

test('anonymous demo entry uses secure sign-in with a return path and offers no shared credentials',()=>{
 context={identity:null,me:null};
 const html=renderToStaticMarkup(React.createElement(module.exports.DemoPage));
 assert.match(html,/<a[^>]*href="\/sign-in\?return_to=%2Fdemo"[^>]*target="_top"/);
 assert.match(html,/No shared password or payment details/);
 assert.doesNotMatch(html,/<form|type="password"/);
 assert.match(html,/Six sample lessons completed/);
});

test('signed-in demo setup requires both declarations before the start control is enabled',()=>{
 context={identity:{name:'Native visitor',email:'visitor@example.test'},me:{demo:null}};
 const html=renderToStaticMarkup(React.createElement(module.exports.DemoPage));
 assert.match(html,/<form/);
 assert.equal((html.match(/type="checkbox"/g)||[]).length,2);
 assert.equal((html.match(/required=""/g)||[]).length,2);
 assert.match(html,/<button[^>]*type="submit"[^>]*disabled=""/);
 assert.match(html,/Enter my Plus demo/);
 assert.doesNotMatch(html,/visitor@example.test/);
});

test('active demo exposes the actual member routes and labels the sample certificate',()=>{
 context={identity:{name:'Native visitor',email:'visitor@example.test'},me:{demo:{active:true,expiresAt:new Date(Date.now()+3600000).toISOString()}}};
 const html=renderToStaticMarkup(React.createElement(module.exports.DemoPage));
 for(const path of ['/dashboard','/assessment/C02-TEST','/learn/C03-L01','/resources','/tutor','/api/demo/certificate'])assert.ok(html.includes(`href="${path}"`),path);
 assert.doesNotMatch(html,/<form/);
 assert.match(html,/Preview sample certificate/);
 const banner=renderToStaticMarkup(React.createElement(module.exports.DemoBanner));
 assert.match(banner,/Academy Plus demo/);assert.match(banner,/Reset demo/);assert.match(banner,/Exit demo/);
});

test('expired demo shows setup again and a recovery banner instead of an active dashboard invitation',()=>{
 context={identity:{name:'Native visitor',email:'visitor@example.test'},me:{demo:{active:true,expiresAt:new Date(Date.now()-1000).toISOString()}}};
 const html=renderToStaticMarkup(React.createElement(module.exports.DemoPage));
 assert.match(html,/<form/);assert.doesNotMatch(html,/Open my demo dashboard/);
 const banner=renderToStaticMarkup(React.createElement(module.exports.DemoBanner));
 assert.match(banner,/Demo session ended/);assert.match(banner,/Restart demo/);assert.match(banner,/Exit demo/);
 assert.doesNotMatch(banner,/Reset demo/);
});
