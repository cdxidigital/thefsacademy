import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { runInThisContext } from "node:vm";
import ts from "typescript";

// Exercise the actual TSX handlers with isolated hook/navigation state.
// This is a component regression check, not a browser or accessibility test.
let active;
const element = (type, props) => ({ type, props: props || {} });
const hooks = {
  useRef(initial) {
    const owner = active, index = owner.cursor++;
    if (!owner.slots[index]) owner.slots[index] = { current: initial };
    return owner.slots[index];
  },
  useCallback(callback, deps) {
    const owner = active, index = owner.cursor++, previous = owner.slots[index];
    if (!previous || deps.some((value, i) => !Object.is(value, previous.deps[i]))) owner.slots[index] = { value: callback, deps };
    return owner.slots[index].value;
  },
  useState(initial) {
    const owner = active, index = owner.cursor++;
    if (!owner.slots[index]) owner.slots[index] = { value: typeof initial === "function" ? initial() : initial };
    return [owner.slots[index].value, value => {
      const next = typeof value === "function" ? value(owner.slots[index].value) : value;
      if (!Object.is(next, owner.slots[index].value)) { owner.slots[index].value = next; owner.dirty = true; }
    }];
  },
  useEffect(effect, deps) {
    const owner = active, index = owner.cursor++, previous = owner.slots[index];
    if (!previous || deps.some((value, i) => !Object.is(value, previous.deps[i]))) {
      owner.pending.push(() => { previous?.cleanup?.(); owner.slots[index].cleanup = effect(); });
      owner.slots[index] = { deps };
    }
  },
};
function compile(relativePath, requireModule) {
  const code = ts.transpileModule(readFileSync(new URL(relativePath, import.meta.url), "utf8"), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX, esModuleInterop: true },
  }).outputText;
  const module = { exports: {} };
  runInThisContext(`(function(require,module,exports){${code}\n})`, { filename: relativePath })(requireModule, module, module.exports);
  return module.exports;
}
const api = compile("../lib/academy/types.ts", id => { throw new Error(`Unexpected API dependency ${id}`); });
const assessmentOptions = compile("../lib/academy/assessment-options.ts", id => { throw new Error(`Unexpected option dependency ${id}`); });
const requireComponent = id => {
  if (id === "react") return hooks;
  if (id === "react/jsx-runtime") return { jsx: element, jsxs: element, Fragment: "Fragment" };
  if (id === "next/link") return { __esModule: true, default: "Link" };
  if (id === "next/navigation") return { useRouter: () => active.router };
  if (id === "./ui") return new Proxy({ useAcademy: () => active.context }, { get: (target, key) => target[key] || key });
  if (id === "lucide-react") return new Proxy({}, { get: (_target, key) => key });
  if (id === "@/lib/academy/types") return api;
  if (id === "@/lib/academy/display") return { moduleArt: {} };
  if (id === "@/lib/academy/assessment-options") return assessmentOptions;
  throw new Error(`Unexpected component dependency ${id}`);
};
const components = {
  ...compile("../components/academy/learning.tsx", requireComponent),
  ...compile("../components/academy/membership.tsx", requireComponent),
  ...compile("../components/academy/resources.tsx", requireComponent),
};
function harness(context) {
  const result = { context, slots: [], pending: [], cursor: 0, dirty: false, navigation: [], tree: null };
  result.router = { push: path => result.navigation.push(["push", path]), replace: path => result.navigation.push(["replace", path]) };
  result.render = (name, props = {}) => {
    let passes = 0;
    do {
      result.cursor = 0; result.dirty = false; result.pending = []; active = result;
      result.tree = components[name](props);
      for (const effect of result.pending) effect();
      assert.ok(++passes < 10, "component hooks settle");
    } while (result.dirty);
    return result.tree;
  };
  result.unmount = () => { for (const slot of result.slots) slot?.cleanup?.(); };
  return result;
}
function find(node, predicate) {
  if (!node || typeof node !== "object") return undefined;
  if (Array.isArray(node)) { for (const child of node) { const match = find(child, predicate); if (match) return match; } return undefined; }
  if (predicate(node)) return node;
  return find(node.props?.children, predicate);
}
const currentPolicy = "2026-10-17-v1";
const profile = { displayName: "Sam", weeklyGoal: 2, acceptedVersion: currentPolicy };
const context = me => ({ me, catalog: {modules: []}, loadError: "", checkout: () => {}, loading: false, identity: { name: "Sam", email: "sam@example.test" }, refresh: async () => {}, toast: () => {} });
const flush = () => new Promise(resolve => setImmediate(resolve));
function storage(t, value) {
  const original = Object.getOwnPropertyDescriptor(globalThis, "sessionStorage");
  Object.defineProperty(globalThis, "sessionStorage", { configurable: true, value });
  t.after(() => { if (original) Object.defineProperty(globalThis, "sessionStorage", original); else delete globalThis.sessionStorage; });
}

test("current-policy returning learner bypasses onboarding", () => {
  const view = harness(context({ profile, policyVersion: currentPolicy }));
  view.render("Onboarding");
  assert.deepEqual(view.navigation, [["replace", "/dashboard"]]);
  assert.equal(find(view.tree, node => node.type === "form"), undefined);
});

test("updated policy still requires acknowledgement and preserves the weekly goal", async t => {
  const view = harness(context({ profile: { ...profile, acceptedVersion: "older-policy" }, policyVersion: currentPolicy, progress: { orientationCompleted: true } }));
  let submitted;
  t.mock.method(globalThis, "fetch", async (_path, init) => { submitted = JSON.parse(init.body); return Response.json({}); });
  storage(t, { setItem() {} });
  view.render("Onboarding");
  assert.deepEqual(view.navigation, []);
  assert.ok(find(view.tree, node => node.type === "form"));
  assert.equal(find(view.tree, node => node.type === "input" && node.props.value === 2).props.checked, true);
  for (let index = 0; index < 2; index++) {
    find(view.tree, node => node.type === "input" && node.props.type === "checkbox" && !node.props.checked).props.onChange({ target: { checked: true } });
    view.render("Onboarding");
  }
  await find(view.tree, node => node.type === "form").props.onSubmit({ preventDefault() {} });
  assert.deepEqual(submitted, { displayName: "Sam", adultConfirmed: true, educationAcknowledged: true, weeklyGoal: 2 });
  assert.deepEqual(view.navigation, [["push", "/dashboard"]]);
});

test("unavailable session storage cannot interrupt saved new-learner onboarding", async t => {
  const state = context({ profile: null, policyVersion: currentPolicy, progress: { orientationCompleted: false } });
  let saved = 0, refreshed = 0;
  t.mock.method(globalThis, "fetch", async path => { assert.equal(path, "/api/profile"); saved++; return Response.json({}); });
  storage(t, { setItem() { throw new Error("Storage access blocked"); } });
  state.refresh = async () => { refreshed++; state.me = { ...state.me, profile }; };
  const view = harness(state);
  view.render("Onboarding");
  for (let index = 0; index < 2; index++) {
    find(view.tree, node => node.type === "input" && node.props.type === "checkbox" && !node.props.checked).props.onChange({ target: { checked: true } });
    view.render("Onboarding");
  }
  await find(view.tree, node => node.type === "form").props.onSubmit({ preventDefault() {} });
  view.render("Onboarding");
  assert.equal(saved, 1); assert.equal(refreshed, 1);
  assert.deepEqual(view.navigation, [["push", "/learn/orientation"]]);
  assert.equal(find(view.tree, node => node.type === "ErrorPanel"), undefined);
});

for (const [status, code, destination] of [[402, "membership_required", "/pricing"], [403, "agreement_required", "/onboarding"]]) {
  test(`lesson ${code} offers the correct recovery route`, async t => {
    t.mock.method(globalThis, "fetch", async () => Response.json({ error: "Access requires an action.", code }, { status }));
    const view = harness(context({ profile, policyVersion: currentPolicy }));
    view.render("LessonView", { id: "C02-L01" });
    await flush();
    view.render("LessonView", { id: "C02-L01" });
    assert.equal(find(view.tree, node => node.type === "ButtonLink").props.href, destination);
  });
}


function textOf(node) {
  if (node == null || typeof node === "boolean") return "";
  if (typeof node !== "object") return String(node);
  if (Array.isArray(node)) return node.map(textOf).join(" ");
  return textOf(node.props?.children);
}
function button(view, label) {
  const match = find(view.tree, node => node.type === "button" && textOf(node).includes(label));
  assert.ok(match, `button ${label} exists`);
  return match;
}
function browserStubs(t) {
  for (const [name, value] of Object.entries({
    window: {matchMedia: () => ({matches: true}), scrollTo() {}},
    document: {documentElement: {dataset: {motion: "off"}}},
  })) {
    const original = Object.getOwnPropertyDescriptor(globalThis, name);
    Object.defineProperty(globalThis, name, {configurable: true, value});
    t.after(() => {if (original) Object.defineProperty(globalThis, name, original); else delete globalThis[name];});
  }
}
const emptyProgress = {completedLessonIds: [], passedAssessmentIds: [], xp: 0, orientationCompleted: true};
const lesson = {id:"C01-L01", moduleId:"C01", title:"Consent is a choice", durationMinutes:15, content:"Learning text.", objectives:["Understand consent"], sourceIds:[]};
const module = {id:"C01", kind:"core", title:"Consent", summary:"Foundations", lessons:[lesson], lessonCount:1, assessmentId:"C01-TEST", durationMinutes:15};
const lessonPayload = {lesson, module, sources:[], nextLessonId:null, previousLessonId:null};
const assessmentPayload = {
  assessment:{id:"C01-L01-CHECK",title:"Consent practice",kind:"lesson_practice",passingScore:1,criticalQuestionIds:[],countsForCertificate:false,instructions:"Choose one answer."},
  questions:[{id:"Q01",prompt:"Choose the consent-focused response.",options:["Ask and listen","Assume"]}],
};
const savedResult = {assessmentId:"C01-L01-CHECK",score:1,total:1,passingScore:1,criticalPassed:true,passed:true,attemptId:"saved-attempt",countsForCertificate:false,progress:emptyProgress,feedback:[{questionId:"Q01",correct:true,selectedIndex:0,correctIndex:0,feedback:"Ask and listen to the response."}]};

test("saved onboarding retries a failed refresh without posting the profile twice", async t => {
  const state = context({profile:null,policyVersion:currentPolicy,progress:emptyProgress});
  let saves = 0, refreshes = 0;
  t.mock.method(globalThis, "fetch", async () => {saves++;return Response.json({});});
  storage(t, {setItem() {}});
  state.refresh = async () => {if (++refreshes === 1) throw new Error("Network unavailable");};
  const view = harness(state);
  view.render("Onboarding");
  for (let index = 0; index < 2; index++) {
    find(view.tree, node => node.type === "input" && node.props.type === "checkbox" && !node.props.checked).props.onChange({target:{checked:true}});
    view.render("Onboarding");
  }
  await find(view.tree, node => node.type === "form").props.onSubmit({preventDefault(){}});
  view.render("Onboarding");
  assert.match(find(view.tree, node => node.type === "ErrorPanel").props.message, /profile is saved/);
  await find(view.tree, node => node.type === "form").props.onSubmit({preventDefault(){}});
  assert.equal(saves, 1);
  assert.equal(refreshes, 2);
  assert.deepEqual(view.navigation, [["push", "/dashboard"]]);
});

test("lesson completion remains saved after refresh failure and cannot be submitted twice", async t => {
  const state = context({profile,policyVersion:currentPolicy,progress:emptyProgress});
  state.catalog = {modules:[module]};
  state.refresh = async () => {throw new Error("Refresh offline");};
  let releaseSave, saves = 0;
  t.mock.method(globalThis, "fetch", async (path, init) => {
    if (path.startsWith("/api/lessons/")) return Response.json(lessonPayload);
    assert.equal(path, "/api/progress");assert.deepEqual(JSON.parse(init.body), {lessonId:lesson.id});
    saves++;await new Promise(resolve => {releaseSave=resolve;});return Response.json({completed:true,progress:emptyProgress});
  });
  const view = harness(state);
  view.render("LessonView", {id:lesson.id});await flush();view.render("LessonView", {id:lesson.id});
  const mark = button(view, "Mark as complete").props.onClick;
  const first = mark();await mark();assert.equal(saves,1);
  releaseSave();await first;await flush();view.render("LessonView", {id:lesson.id});
  assert.equal(button(view, "Completed").props.disabled, true);
  assert.equal(find(view.tree, node => node.type === "ErrorPanel"), undefined);
  assert.match(textOf(view.tree), /Your chapter is saved/);
});

test("assessment locks pending answers, saves the submitted snapshot once, and keeps results after refresh failure", async t => {
  browserStubs(t);
  const state = context({profile,policyVersion:currentPolicy,progress:emptyProgress});
  state.refresh = async () => {throw new Error("Refresh offline");};
  let releaseSave, submitted, saves = 0;
  t.mock.method(globalThis, "fetch", async (path, init) => {
    if (!init.method) return Response.json(assessmentPayload);
    saves++;submitted=JSON.parse(init.body);await new Promise(resolve => {releaseSave=resolve;});return Response.json(savedResult);
  });
  const view = harness(state), props = {id:assessmentPayload.assessment.id};
  view.render("Assessment", props);await flush();view.render("Assessment", props);
  find(view.tree, node => node.type === "input" && node.props.value === 0).props.onChange();view.render("Assessment", props);
  const submit = find(view.tree, node => node.type === "form").props.onSubmit;
  const pending = submit({preventDefault(){}});await submit({preventDefault(){}});view.render("Assessment", props);
  const otherAnswer = find(view.tree, node => node.type === "input" && node.props.value === 1);
  assert.equal(otherAnswer.props.disabled, true);otherAnswer.props.onChange();
  assert.deepEqual(submitted, {answers:{Q01:0}});assert.equal(saves,1);
  releaseSave();await pending;await flush();view.render("Assessment", props);
  assert.equal(find(view.tree, node => node.props.className === "assessment-result passed").props.tabIndex, -1);
  assert.equal(find(view.tree, node => node.type === "input" && node.props.value === 0).props.checked, true);
  assert.equal(find(view.tree, node => node.type === "ErrorPanel"), undefined);
  assert.match(textOf(view.tree), /Your result is saved/);
});

test("an assessment response from the previous route cannot appear on the new check", async t => {
  browserStubs(t);
  let releaseSave;
  t.mock.method(globalThis, "fetch", async (path, init) => {
    if (init.method) {await new Promise(resolve => {releaseSave=resolve;});return Response.json(savedResult);}
    const id=path.split("/").at(-1);
    return Response.json({...assessmentPayload,assessment:{...assessmentPayload.assessment,id}});
  });
  const view = harness(context({profile,policyVersion:currentPolicy,progress:emptyProgress}));
  view.render("Assessment", {id:"C01-L01-CHECK"});await flush();view.render("Assessment", {id:"C01-L01-CHECK"});
  find(view.tree, node => node.type === "input" && node.props.value === 0).props.onChange();view.render("Assessment", {id:"C01-L01-CHECK"});
  const pending=find(view.tree, node => node.type === "form").props.onSubmit({preventDefault(){}});
  view.render("Assessment", {id:"C01-L02-CHECK"});await flush();view.render("Assessment", {id:"C01-L02-CHECK"});
  releaseSave();await pending;view.render("Assessment", {id:"C01-L02-CHECK"});
  assert.equal(find(view.tree, node => node.props.className === "assessment-result passed"), undefined);
  assert.equal(find(view.tree, node => node.type === "input" && node.props.value === 0).props.checked, false);
});

test("existing and newly issued certificates expose a direct download without a popup", async t => {
  const state=context({profile,policyVersion:currentPolicy,progress:emptyProgress,certificate:{eligible:true,issued:null}});
  state.catalog={modules:[module]};state.refresh=async()=>{throw new Error("Refresh offline");};
  let saves=0;
  t.mock.method(globalThis,"fetch",async path=>{assert.equal(path,"/api/certificate");saves++;return Response.json({downloadUrl:"/api/certificate?download=1"});});
  const view=harness(state);view.render("ProgressPage");await button(view,"Issue my certificate").props.onClick();await flush();view.render("ProgressPage");
  assert.equal(saves,1);
  const download=find(view.tree,node=>node.type==="a"&&node.props.href==="/api/certificate?download=1");
  assert.equal(download.props.download,"fleshsesh_academy_certificate.html");assert.equal(download.props.target,undefined);
  assert.equal(find(view.tree,node=>node.type==="ErrorPanel"),undefined);
  const existing=harness({...state,me:{...state.me,certificate:{eligible:false,issued:{id:"issued"}}}});existing.render("ProgressPage");
  assert.ok(find(existing.tree,node=>node.type==="a"&&node.props.href==="/api/certificate?download=1"));assert.equal(saves,1);
});

test("Plus demo has sample certificate and no real billing, export, deletion or paid checkout controls", () => {
  const state=context({profile,policyVersion:currentPolicy,progress:emptyProgress,billing:{mode:"demo",tier:"plus",hasCustomer:false,checkoutAvailable:false},certificate:{eligible:true,issued:null,demoOnly:true,sampleUrl:"/api/demo/certificate"}});
  state.catalog={modules:[module]};let checkouts=0;state.checkout=()=>{checkouts++;};
  const progress=harness(state);progress.render("ProgressPage");
  assert.ok(find(progress.tree,node=>node.type==="a"&&node.props.href==="/api/demo/certificate"));
  assert.equal(find(progress.tree,node=>node.type==="button"&&textOf(node).includes("Issue my certificate")),undefined);
  assert.match(textOf(progress.tree),/DEMONSTRATION · NOT VALID/);
  const account=harness(state);account.render("Account");
  for(const label of ["Manage membership","Export my learning data","Delete my learner profile"]){
    assert.equal(find(account.tree,node=>node.type==="button"&&textOf(node).includes(label)),undefined);
  }
  assert.match(textOf(account.tree),/Demo · no charges/);
  const pricing=harness(state);pricing.render("Pricing");
  button(pricing,"Explore your Plus demo").props.onClick();button(pricing,"Explore the demo guides").props.onClick();
  assert.equal(checkouts,0);assert.deepEqual(pricing.navigation,[["push","/library"],["push","/tutor"]]);
});

test("resources recheck toolkit access when the active entitlement changes", async t => {
  const state=context({user:{userId:"learner"},profile,policyVersion:currentPolicy,progress:emptyProgress,billing:{mode:"live",tier:"explore",entitlements:[]}});
  let reads=0;
  t.mock.method(globalThis,"fetch",async path=>{assert.equal(path,"/api/resources");reads++;return Response.json({toolkitAvailable:reads>1,worksheets:[],glossary:[],sources:[]});});
  const view=harness(state);view.render("Resources");await flush();view.render("Resources");assert.equal(reads,1);
  state.me={...state.me,billing:{...state.me.billing,tier:"academy",entitlements:[{key:"academy",active:true,expiresAt:null}]}};
  view.render("Resources");await flush();view.render("Resources");assert.equal(reads,2);
});

for(const [component,id] of [["LessonView","C01-L01"],["Assessment","C01-L01-CHECK"]]){
  test(`${component} provides a demo recovery link for an expired isolated session`,async t=>{
    t.mock.method(globalThis,"fetch",async()=>Response.json({error:"The demo has expired.",code:"demo_expired"},{status:409}));
    const view=harness(context({profile,policyVersion:currentPolicy,progress:emptyProgress}));
    view.render(component,{id});await flush();view.render(component,{id});
    assert.equal(find(view.tree,node=>node.type==="ButtonLink").props.href,"/demo");
  });
}

test("shuffled assessment choices, marking feedback and retry remain aligned in the actual component", async t => {
  const bank = JSON.parse(readFileSync(new URL("../data/assessments.json", import.meta.url), "utf8"));
  const form = bank.assessments.find(item => item.id === "PLAN01");
  const questions = form.questionIds.map(id => bank.questions.find(item => item.id === id));
  const { gradeAssessment } = compile("../lib/server/pure.ts", id => { throw new Error(`Unexpected grading dependency ${id}`); });
  const text = node => node == null ? "" : Array.isArray(node) ? node.map(text).join(" ") : typeof node === "object" ? text(node.props?.children) : String(node);
  for (const [key, value] of [["window", { scrollTo() {}, matchMedia: () => ({ matches: true }) }], ["document", { documentElement: { dataset: {} }, getElementById() { return null; } }]]) {
    const original = Object.getOwnPropertyDescriptor(globalThis, key);
    Object.defineProperty(globalThis, key, { configurable: true, value });
    t.after(() => { if (original) Object.defineProperty(globalThis, key, original); else delete globalThis[key]; });
  }
  let random = 0;
  t.mock.method(Math, "random", () => random);
  let submitted, releaseMarking;
  t.mock.method(globalThis, "fetch", async (path, init) => {
    if (!init?.method || init.method === "GET") return Response.json({ assessment: form, questions: questions.map(({ id, prompt, options }) => ({ id, prompt, options })), planning: { case: "A fictional planning case." } });
    if (path.endsWith("/start")) return Response.json({});
    submitted = JSON.parse(init.body).answers;
    return new Promise(resolve => { releaseMarking = () => resolve(Response.json(gradeAssessment(form, bank.questions, submitted))); });
  });
  const view = harness(context({ profile, policyVersion: currentPolicy }));
  view.render("Assessment", { id: "PLAN01" });
  await flush();
  view.render("Assessment", { id: "PLAN01" });
  await find(view.tree, node => node.type === "button" && text(node).includes("Begin knowledge check")).props.onClick();
  view.render("Assessment", { id: "PLAN01" });
  const labelFor = (questionId, index) => find(view.tree, node => node.type === "label" && Boolean(find(node, child => child.type === "input" && child.props.name === questionId && child.props.value === index)));
  assert.equal(find(labelFor(questions[0].id, 0), node => node.props.className === "answer-letter").props.children, "D", "Displayed letter must follow shuffled position");
  for (const [index, question] of questions.entries()) {
    const choice = index === questions.length - 1 ? (question.correctIndex + 1) % 4 : question.correctIndex;
    find(labelFor(question.id, choice), node => node.type === "input").props.onChange();
    view.render("Assessment", { id: "PLAN01" });
  }
  const marking = find(view.tree, node => node.type === "form").props.onSubmit({ preventDefault() {} });
  await flush();
  view.render("Assessment", { id: "PLAN01" });
  assert.equal(find(view.tree, node => node.type === "input" && !node.props.disabled), undefined, "Answers must be stable during submission");
  assert.equal(submitted[questions[0].id], questions[0].correctIndex, "Submit canonical index, not displayed letter position");
  releaseMarking(); await marking;
  view.render("Assessment", { id: "PLAN01" });
  assert.match(text(view.tree), /5\s+of\s+6\s+correct/);
  assert.match(text(view.tree), /All six applied planning decisions need to be correct/);
  assert.doesNotMatch(text(view.tree), /Every safety-critical capstone item also needs/);
  const last = questions.at(-1);
  assert.match(labelFor(last.id, last.correctIndex).props.className, /correct-answer/);
  assert.equal(find(labelFor(last.id, last.correctIndex), node => node.type === "input").props.checked, false);
  assert.equal(find(labelFor(last.id, (last.correctIndex + 1) % 4), node => node.type === "input").props.checked, true);
  random = 0.999;
  find(view.tree, node => node.type === "button" && text(node).includes("Try again")).props.onClick();
  view.render("Assessment", { id: "PLAN01" });
  await find(view.tree, node => node.type === "button" && text(node).includes("Begin knowledge check")).props.onClick();
  view.render("Assessment", { id: "PLAN01" });
  assert.equal(find(view.tree, node => node.type === "input" && node.props.checked), undefined, "Retry clears old selections");
  assert.equal(find(labelFor(questions[0].id, 0), node => node.props.className === "answer-letter").props.children, "A", "Retry recomputes presentation order");
});
