import test from "node:test";
import assert from "node:assert/strict";
import { fixture, identity, request, context, route, catalog, bank, correctAnswers } from "./backend-runtime.mjs";
const pure = await import("../lib/server/pure.ts");
const me = await route("me"), profile = await route("profile"), orientation = await route("orientation"), progress = await route("progress"), assessment = await route("assessments/[id]"), lesson = await route("lessons/[id]"), certificate = await route("certificate"), checkout = await route("billing/checkout"), tutor = await route("tutor"), remove = await route("account/delete"), start = await route("assessments/[id]/start"), end = await route("assessments/[id]/end"), webhook = await route("billing/webhook");
async function onboard() { const result = await profile.POST(request("/api/profile", { displayName: "Learner", weeklyGoal: 3, adultConfirmed: true, educationAcknowledged: true })); assert.equal(result.status, 200); await orientation.POST(request("/api/orientation", {})); }
async function completeModule(moduleId) { for (const item of catalog.modules.find((item) => item.id === moduleId).lessons) assert.equal((await progress.POST(request("/api/progress", { lessonId: item.id }))).status, 200); }
async function submit(id, answers = correctAnswers(id)) { return assessment.POST(request(`/api/assessments/${id}`, { answers }), context(id)); }
async function signature(payload, secret, timestamp = Math.floor(Date.now() / 1000)) { const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]); const bytes = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${timestamp}.${payload}`)); return `t=${timestamp},v1=${Buffer.from(bytes).toString("hex")}`; }

test("full source curriculum and deterministic grading preserve all 114 items", () => {
  assert.equal(catalog.modules.flatMap((item) => item.lessons).length, 48); assert.equal(bank.questions.length, 114);
  for (const item of bank.assessments) { const result = pure.gradeAssessment(item, bank.questions, correctAnswers(item.id)); assert.equal(result.passed, true, item.id); }
  const capstone = bank.assessments.find((item) => item.id === "CAP01"); const answers = correctAnswers("CAP01"); answers[capstone.criticalQuestionIds[0]] = (answers[capstone.criticalQuestionIds[0]] + 1) % 4;
  const failed = pure.gradeAssessment(capstone, bank.questions, answers); assert.equal(failed.score, 11); assert.equal(failed.passed, false); assert.equal(failed.criticalPassed, false);
  const plan = correctAnswers("PLAN01"); plan["PLAN01-Q01"] = (plan["PLAN01-Q01"] + 1) % 4; assert.equal(pure.gradeAssessment(bank.assessments.find((item) => item.id === "PLAN01"), bank.questions, plan).passed, false);
});

test("authentication, adult agreement, JSON bounds and CSRF reject unsafe calls", async () => {
  fixture(); identity(null); assert.equal((await me.GET()).status, 200); assert.equal((await lesson.GET(request("/api/lessons/C01-L01"), context("C01-L01"))).status, 401);
  identity("learner-a"); assert.equal((await profile.POST(request("/api/profile", { displayName: "Learner" }))).status, 400);
  assert.equal((await profile.POST(request("/api/profile", { displayName: "Learner", adultConfirmed: true, educationAcknowledged: true }, { headers: { Origin: "https://hostile.example" } }))).status, 403);
  assert.equal((await profile.POST(request("/api/profile", "{"))).status, 400);
  assert.equal((await tutor.POST(request("/api/tutor", { message: "x".repeat(7000) }))).status, 413);
  assert.equal((await lesson.GET(request("/api/lessons/C01-L01"), context("C01-L01"))).status, 403);
});

test("idempotent completion, scoped records, hidden answers and live entitlements", async () => {
  const db = fixture(); await onboard();
  for (let i = 0; i < 2; i++) assert.equal((await progress.POST(request("/api/progress", { lessonId: "C01-L01" }))).status, 200);
  let snapshot = await (await me.GET()).json(); assert.equal(snapshot.progress.xp, 25); assert.equal(snapshot.progress.completedLessonIds.length, 1);
  assert.equal((await submit("C01-TEST")).status, 403);
  await completeModule("C01");
  const safe = await (await assessment.GET(request("/api/assessments/C01-TEST"), context("C01-TEST"))).json(); assert.equal(safe.questions.length, 6); assert.equal(JSON.stringify(safe).includes("correctIndex"), false); assert.equal(JSON.stringify(safe).includes("correctOptionId"), false);
  const wrong = correctAnswers("C01-TEST"); wrong.extra = 0; assert.equal((await submit("C01-TEST", wrong)).status, 400);
  assert.equal((await submit("C01-TEST")).status, 200); assert.equal((await submit("C01-TEST")).status, 200);
  snapshot = await (await me.GET()).json(); assert.equal(snapshot.progress.xp, 175);
  identity("learner-b"); await onboard(); snapshot = await (await me.GET()).json(); assert.equal(snapshot.progress.xp, 0); assert.equal(snapshot.progress.completedLessonIds.length, 0);
  globalThis.__academyEnv.APP_MODE = "live";
  assert.equal((await lesson.GET(request("/api/lessons/C01-L01"), context("C01-L01"))).status, 200);
  assert.equal((await lesson.GET(request("/api/lessons/C02-L01"), context("C02-L01"))).status, 402);
  db.sqlite.prepare("INSERT INTO entitlements(user_id,key,source_id,active,updated_at)VALUES(?,?,?,1,?)").run("learner-b", "module:C02", "test-order", new Date().toISOString());
  assert.equal((await lesson.GET(request("/api/lessons/C02-L01"), context("C02-L01"))).status, 200);
  assert.equal((await lesson.GET(request("/api/lessons/C03-L01"), context("C03-L01"))).status, 402);
  assert.equal((await certificate.POST(request("/api/certificate", {}))).status, 403);
});

test("certificate issues only for all core requirements and is private and idempotent", async () => {
  fixture(); await onboard();
  for (const module of catalog.modules.filter((item) => item.kind === "core")) { await completeModule(module.id); assert.equal((await submit(module.assessmentId)).status, 200); }
  assert.equal((await certificate.POST(request("/api/certificate", {}))).status, 403);
  const failCritical = correctAnswers("CAP01"); failCritical["CAP01-Q01"] = (failCritical["CAP01-Q01"] + 1) % 4; const result = await (await submit("CAP01", failCritical)).json(); assert.equal(result.passed, false);
  assert.equal((await certificate.POST(request("/api/certificate", {}))).status, 403);
  await submit("CAP01"); assert.equal((await certificate.POST(request("/api/certificate", {}))).status, 403);
  await submit("PLAN01"); const issued = await (await certificate.POST(request("/api/certificate", {}))).json(); const repeated = await (await certificate.POST(request("/api/certificate", {}))).json(); assert.equal(issued.certificate.id, repeated.certificate.id);
  const download = await certificate.GET(request("/api/certificate?download=1")); assert.equal(download.status, 200); assert.match(download.headers.get("cache-control"), /no-store/); assert.match(await download.text(), /Non-accredited/);
  identity("learner-b"); await onboard(); assert.equal((await certificate.GET(request("/api/certificate?download=1"))).status, 404);
});

test("tutor is honest in pilot, respects assessment mode and rate limits; account delete cascades", async () => {
  const db = fixture(); await onboard(); await completeModule("C01");
  const response = await (await tutor.POST(request("/api/tutor", { message: "Explain consent", mode: "recap", consentToAI: false }))).json(); assert.equal(response.mode, "lesson-guide"); assert.equal(response.externalProcessing, false); assert.ok(response.sources.length);
  await start.POST(request("/api/assessments/C01-TEST/start", {}), context("C01-TEST"));
  const inAssessment = await (await tutor.POST(request("/api/tutor", { message: "Give me the answer to the first question" }))).json(); assert.equal(inAssessment.mode, "assessment-guide");
  await end.POST(request("/api/assessments/C01-TEST/end", {}), context("C01-TEST"));
  assert.equal((await checkout.POST(request("/api/billing/checkout", { product: "academy_monthly" }))).status, 503);
  for (let i = 0; i < 6; i++) assert.equal((await tutor.POST(request("/api/tutor", { message: "Explain boundaries" }))).status, 200);
  assert.equal((await tutor.POST(request("/api/tutor", { message: "Explain boundaries" }))).status, 429);
  assert.equal((await remove.POST(request("/api/account/delete", { confirmation: "DELETE" }))).status, 400);
  assert.equal((await remove.POST(request("/api/account/delete", { confirmation: "DELETE MY ACCOUNT" }))).status, 200);
  assert.equal(db.sqlite.prepare("SELECT COUNT(*) AS count FROM lesson_progress").get().count, 0); assert.equal(db.sqlite.prepare("SELECT COUNT(*) AS count FROM tutor_usage").get().count, 0);
});

test("Stripe verification rejects changed payloads, wrong secrets and stale signatures", async () => {
  const payload = '{"id":"evt_1"}'; const secret = "whsec_test"; const header = await signature(payload, secret);
  assert.equal(await pure.verifyStripeSignature(payload, header, secret), true); assert.equal(await pure.verifyStripeSignature(payload + " ", header, secret), false); assert.equal(await pure.verifyStripeSignature(payload, header, "other"), false);
  assert.equal(await pure.verifyStripeSignature(payload, await signature(payload, secret, Math.floor(Date.now() / 1000) - 600), secret), false);
});

test("verified payment webhooks grant once across duplicate event types and revoke refunded packs", async () => {
  const db = fixture(); await onboard(); const secret = "whsec_test";
  Object.assign(globalThis.__academyEnv, { STRIPE_WEBHOOK_SECRET: secret, STRIPE_SECRET_KEY: "sk_test_example", STRIPE_PRICE_TUTOR_PACK: "price_pack" });
  db.sqlite.prepare("INSERT INTO billing_customers(user_id,customer_id,updated_at)VALUES(?,?,?)").run("learner-a", "cus_a", new Date().toISOString());
  const session = { id: "cs_pack", mode: "payment", customer: "cus_a", subscription: null, payment_status: "paid", metadata: { academy_user_id: "learner-a", product: "tutor_pack", module_id: "" }, line_items: { data: [{ quantity: 1, price: { id: "price_pack", currency: "aud", unit_amount: 500, recurring: null } }] } };
  const originalFetch = globalThis.fetch; globalThis.fetch = async (url) => { assert.match(String(url), /^https:\/\/api\.stripe\.com\/v1\//); if (String(url).includes("invoice_payments?")) return Response.json({ data: [] }); if (String(url).includes("sessions?payment_intent")) return Response.json({ data: [session] }); return Response.json(session); };
  async function event(id, type, object) { const payload = JSON.stringify({ id, type, created: Math.floor(Date.now() / 1000), data: { object } }); return webhook.POST(new Request("https://academy.example.test/api/billing/webhook", { method: "POST", headers: { "stripe-signature": await signature(payload, secret) }, body: payload })); }
  try {
    assert.equal((await event("evt_one", "checkout.session.completed", { id: "cs_pack" })).status, 200);
    assert.equal((await event("evt_one", "checkout.session.completed", { id: "cs_pack" })).status, 200);
    assert.equal((await event("evt_two", "checkout.session.async_payment_succeeded", { id: "cs_pack" })).status, 200);
    assert.equal(db.sqlite.prepare("SELECT tutor_credits AS credits FROM profiles WHERE user_id='learner-a'").get().credits, 50);
    assert.equal((await event("evt_refund", "charge.refunded", { id: "ch_1", payment_intent: "pi_1", refunded: true })).status, 200);
    assert.equal(db.sqlite.prepare("SELECT tutor_credits AS credits FROM profiles WHERE user_id='learner-a'").get().credits, 0);
    assert.equal((await event("evt_late", "checkout.session.completed", { id: "cs_pack" })).status, 200);
    assert.equal(db.sqlite.prepare("SELECT tutor_credits AS credits FROM profiles WHERE user_id='learner-a'").get().credits, 0);
    assert.equal(db.sqlite.prepare("SELECT active FROM entitlements WHERE source_id='cs_pack'").get().active, 0);
  } finally { globalThis.fetch = originalFetch; }
});

test("subscription webhooks require paid canonical state and remove access after cancellation", async () => {
  const db = fixture(); await onboard(); const secret = "whsec_test";
  Object.assign(globalThis.__academyEnv, { APP_MODE: "live", STRIPE_WEBHOOK_SECRET: secret, STRIPE_SECRET_KEY: "sk_test_example", STRIPE_PRICE_ACADEMY_MONTHLY: "price_month" });
  db.sqlite.prepare("INSERT INTO billing_customers(user_id,customer_id,updated_at)VALUES(?,?,?)").run("learner-a", "cus_a", new Date().toISOString());
  let state = { id: "sub_a", customer: "cus_a", metadata: { academy_user_id: "learner-a" }, status: "active", cancel_at_period_end: false, latest_invoice: { id: "in_a", status: "open" }, items: { data: [{ current_period_end: Math.floor(Date.now() / 1000) + 86400, price: { id: "price_month", currency: "aud", unit_amount: 1900, recurring: { interval: "month", interval_count: 1 } } }] } };
  const originalFetch = globalThis.fetch; globalThis.fetch = async () => Response.json(state);
  async function event(id, type, object) { const payload = JSON.stringify({ id, type, created: Math.floor(Date.now() / 1000), data: { object } }); return webhook.POST(new Request("https://academy.example.test/api/billing/webhook", { method: "POST", headers: { "stripe-signature": await signature(payload, secret) }, body: payload })); }
  try {
    assert.equal((await event("evt_open", "customer.subscription.updated", { id: "sub_a" })).status, 200);
    assert.equal((await lesson.GET(request("/api/lessons/C02-L01"), context("C02-L01"))).status, 402);
    state.latest_invoice.status = "paid";
    assert.equal((await event("evt_paid", "invoice.paid", { id: "in_a", parent: { subscription_details: { subscription: "sub_a" } } })).status, 200);
    assert.equal((await lesson.GET(request("/api/lessons/C02-L01"), context("C02-L01"))).status, 200);
    state.status = "canceled";
    assert.equal((await event("evt_cancel", "customer.subscription.deleted", { id: "sub_a" })).status, 200);
    assert.equal((await lesson.GET(request("/api/lessons/C02-L01"), context("C02-L01"))).status, 402);
    // Even a delayed older 'paid' notification re-fetches the current canceled state.
    assert.equal((await event("evt_delayed", "invoice.paid", { id: "in_a", subscription: "sub_a" })).status, 200);
    assert.equal((await lesson.GET(request("/api/lessons/C02-L01"), context("C02-L01"))).status, 402);
  } finally { globalThis.fetch = originalFetch; }
});

test("checkout rejects duplicate access, altered prices and unsupported products", async () => {
  const db = fixture(); await onboard();
  Object.assign(globalThis.__academyEnv, { APP_MODE: "live", PROCESSOR_APPROVED: "true", RELEASE_APPROVED: "true", APP_ORIGIN: "https://academy.example.test", STRIPE_SECRET_KEY: "sk_test_example", STRIPE_WEBHOOK_SECRET: "whsec_example", STRIPE_PRICE_MODULE: "price_module", STRIPE_PRICE_ACADEMY_MONTHLY: "price_month" });
  db.sqlite.prepare("INSERT INTO entitlements(user_id,key,source_id,active,updated_at)VALUES(?,?,?,1,?)").run("learner-a", "module:C02", "order_two", new Date().toISOString());
  assert.equal((await checkout.POST(request("/api/billing/checkout", { product: "module", moduleId: "C02" }))).status, 409);
  assert.equal((await checkout.POST(request("/api/billing/checkout", { product: "module", moduleId: "C01" }))).status, 400);
  assert.equal((await checkout.POST(request("/api/billing/checkout", { product: "arbitrary_price" }))).status, 400);
  const originalFetch = globalThis.fetch; globalThis.fetch = async () => Response.json({ id: "price_month", active: true, currency: "usd", unit_amount: 1, recurring: { interval: "month", interval_count: 1 } });
  try { const response = await checkout.POST(request("/api/billing/checkout", { product: "academy_monthly", renewalConsent: true })); assert.equal(response.status, 503); assert.equal((await response.json()).code, "price_mismatch"); }
  finally { globalThis.fetch = originalFetch; }
});

test("AI consent, membership quota, purchased credits and failed-call refunds are server enforced", async () => {
  const db = fixture(); await onboard(); const bucket = new Date().toISOString().slice(0, 7);
  Object.assign(globalThis.__academyEnv, { AI_RELEASE_APPROVED: "true", OPENAI_API_KEY: "test-key-not-real", OPENAI_MODEL: "test-fixture-model" });
  db.sqlite.prepare("INSERT INTO entitlements(user_id,key,source_id,active,updated_at)VALUES(?,?,?,1,?)").run("learner-a", "academy", "sub_fixture", new Date().toISOString());
  db.sqlite.prepare("INSERT INTO tutor_usage(user_id,bucket,count)VALUES(?,?,49)").run("learner-a", bucket);
  db.sqlite.prepare("UPDATE profiles SET tutor_credits=1 WHERE user_id='learner-a'").run();
  let calls = 0; let fail = false; const originalFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    assert.equal(url, "https://api.openai.com/v1/responses"); const sent = JSON.parse(init.body); assert.equal(sent.store, false); assert.equal(sent.input.includes("learner-a@example"), false); assert.equal(sent.input.includes("correctIndex"), false); calls++;
    return fail ? Response.json({ error: "fixture failure" }, { status: 503 }) : Response.json({ output: [{ type: "message", content: [{ type: "output_text", text: "Consent is freely chosen and ongoing. [A01]" }] }] });
  };
  try {
    const noConsent = await (await tutor.POST(request("/api/tutor", { message: "Explain consent", consentToAI: false }))).json(); assert.equal(noConsent.mode, "lesson-guide"); assert.equal(calls, 0);
    const first = await (await tutor.POST(request("/api/tutor", { message: "Explain consent", consentToAI: true }))).json(); assert.equal(first.mode, "ai"); assert.equal(calls, 1);
    const second = await (await tutor.POST(request("/api/tutor", { message: "Explain consent", consentToAI: true }))).json(); assert.equal(second.mode, "ai"); assert.equal(db.sqlite.prepare("SELECT tutor_credits AS value FROM profiles").get().value, 0);
    const exhausted = await (await tutor.POST(request("/api/tutor", { message: "Explain consent", consentToAI: true }))).json(); assert.equal(exhausted.mode, "lesson-guide"); assert.equal(calls, 2);
    db.sqlite.prepare("UPDATE tutor_usage SET count=49 WHERE bucket=?").run(bucket); fail = true;
    const unavailable = await (await tutor.POST(request("/api/tutor", { message: "Explain consent", consentToAI: true }))).json(); assert.equal(unavailable.mode, "lesson-guide"); assert.equal(db.sqlite.prepare("SELECT count FROM tutor_usage WHERE bucket=?").get(bucket).count, 49);
    const revoked = await (await tutor.POST(request("/api/tutor", { message: "Explain consent", consentToAI: false }))).json(); assert.equal(revoked.mode, "lesson-guide"); assert.equal(db.sqlite.prepare("SELECT external_ai_consent_at AS value FROM profiles").get().value, null);
  } finally { globalThis.fetch = originalFetch; }
});

test("subscription refunds and disputes hold the affected invoice without cancelling or replay reactivation", async () => {
  const db = fixture(); await onboard(); const secret = "whsec_reversal";
  Object.assign(globalThis.__academyEnv, { APP_MODE: "live", STRIPE_WEBHOOK_SECRET: secret, STRIPE_SECRET_KEY: "sk_test_example", STRIPE_PRICE_ACADEMY_MONTHLY: "price_month" });
  db.sqlite.prepare("INSERT INTO billing_customers(user_id,customer_id,updated_at)VALUES(?,?,?)").run("learner-a", "cus_a", new Date().toISOString());
  const state = { id: "sub_a", customer: "cus_a", metadata: { academy_user_id: "learner-a" }, status: "active", cancel_at_period_end: false, latest_invoice: { id: "in_first", status: "paid" }, items: { data: [{ current_period_end: Math.floor(Date.now() / 1000) + 86400, price: { id: "price_month", currency: "aud", unit_amount: 1900, recurring: { interval: "month", interval_count: 1 } } }] } };
  let disputeStatus = "needs_response"; let invoiceForPayment = "in_first";
  const originalFetch = globalThis.fetch; globalThis.fetch = async (url, init) => {
    const path = new URL(url).pathname; assert.equal(init.method, "GET", "A reversal must not cancel or modify provider billing");
    if (path.startsWith("/v1/subscriptions/")) return Response.json(state);
    if (path === "/v1/checkout/sessions") return Response.json({ data: [] }); // Renewal charge: no Checkout Session.
    if (path === "/v1/invoice_payments") { const query = new URL(url).searchParams; assert.equal(query.get("payment[type]"), "payment_intent"); assert.equal(query.get("payment[payment_intent]"), "pi_period"); return Response.json({ data: [{ invoice: invoiceForPayment }], has_more: false }); }
    if (path.startsWith("/v1/invoices/")) return Response.json({ id: path.split("/").pop(), customer: "cus_a", status: "paid", parent: { subscription_details: { subscription: "sub_a" } } });
    if (path.startsWith("/v1/disputes/")) return Response.json({ id: "dp_period", charge: "ch_period", status: disputeStatus });
    if (path === "/v1/charges/ch_period") return Response.json({ id: "ch_period", payment_intent: "pi_period" });
    throw new Error(`Unexpected provider request ${path}`);
  };
  async function event(id, type, object) { const payload = JSON.stringify({ id, type, created: Math.floor(Date.now() / 1000), data: { object } }); const response = await webhook.POST(new Request("https://academy.example.test/api/billing/webhook", { method: "POST", headers: { "stripe-signature": await signature(payload, secret) }, body: payload })); assert.equal(response.status, 200, JSON.stringify(await response.json())); }
  async function access(expected) { assert.equal((await lesson.GET(request("/api/lessons/C02-L01"), context("C02-L01"))).status, expected); }
  try {
    await event("evt_initial_paid", "invoice.paid", { id: "in_first", subscription: "sub_a" }); await access(200);
    await event("evt_partial", "charge.refunded", { id: "ch_partial", payment_intent: "pi_period", refunded: false }); await access(200);
    await event("evt_full", "charge.refunded", { id: "ch_full", payment_intent: "pi_period", refunded: true }); await access(402);
    assert.equal(db.sqlite.prepare("SELECT subscription_status AS status FROM billing_customers").get().status, "active");
    await event("evt_same_invoice_again", "invoice.paid", { id: "in_first", subscription: "sub_a" }); await access(402);
    await event("evt_same_subscription_again", "customer.subscription.updated", { id: "sub_a" }); await access(402);
    state.latest_invoice.id = "in_next";
    await event("evt_new_paid_invoice", "invoice.paid", { id: "in_next", subscription: "sub_a" }); await access(200);
    await event("evt_delayed_old_refund", "charge.refunded", { id: "ch_full", payment_intent: "pi_period", refunded: true }); await access(200);
    invoiceForPayment = "in_next";
    await event("evt_dispute", "charge.dispute.created", { id: "dp_period", charge: "ch_period" }); await access(402);
    await event("evt_dispute_replay_paid", "invoice.paid", { id: "in_next", subscription: "sub_a" }); await access(402);
    disputeStatus = "won";
    await event("evt_dispute_won", "charge.dispute.closed", { id: "dp_period", charge: "ch_period" }); await access(200);
    await event("evt_late_dispute_open", "charge.dispute.created", { id: "dp_period", charge: "ch_period" }); await access(200);
    await event("evt_full_current", "charge.refunded", { id: "ch_full_current", payment_intent: "pi_period", refunded: true }); await access(402);
    await event("evt_won_after_refund", "charge.dispute.closed", { id: "dp_period", charge: "ch_period" }); await access(402);
    assert.equal(db.sqlite.prepare("SELECT cancel_at_period_end AS value FROM billing_customers").get().value, 0);
  } finally { globalThis.fetch = originalFetch; }
});
