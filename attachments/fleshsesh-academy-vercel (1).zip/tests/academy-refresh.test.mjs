import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInThisContext} from 'node:vm';
import ts from 'typescript';

// Actual AcademyApp and request() code, with deferred network responses and
// isolated hooks. These checks do not simulate a browser, layout or hydration.
let active;
const element=(type,props)=>({type,props:props||{}});
const hooks={
 useRef(value){const owner=active,index=owner.cursor++;if(!owner.slots[index])owner.slots[index]={current:value};return owner.slots[index];},
 useState(initial){const owner=active,index=owner.cursor++;if(!owner.slots[index])owner.slots[index]={value:typeof initial==='function'?initial():initial};return [owner.slots[index].value,value=>{const next=typeof value==='function'?value(owner.slots[index].value):value;if(!Object.is(next,owner.slots[index].value)){owner.slots[index].value=next;owner.dirty=true;}}];},
 useMemo(factory,deps){const owner=active,index=owner.cursor++,previous=owner.slots[index];if(!previous||deps.some((value,i)=>!Object.is(value,previous.deps[i])))owner.slots[index]={value:factory(),deps};return owner.slots[index].value;},
 useCallback(callback,deps){return hooks.useMemo(()=>callback,deps);},
 useEffect(effect,deps){const owner=active,index=owner.cursor++,previous=owner.slots[index];if(!previous||deps.some((value,i)=>!Object.is(value,previous.deps[i]))){owner.pending.push(()=>{previous?.cleanup?.();owner.slots[index].cleanup=effect();});owner.slots[index]={deps};}},
 lazy:()=> 'LazyPage',
 Suspense:'Suspense',
};
function compile(path,requireModule){
 const code=ts.transpileModule(readFileSync(new URL(path,import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText;
 const module={exports:{}};
 runInThisContext(`(function(require,module,exports){${code}\n})`,{filename:path})(requireModule,module,module.exports);
 return module.exports;
}
const api=compile('../lib/academy/types.ts',id=>{throw new Error(`Unexpected API dependency ${id}`);});
const ui=new Proxy({AcademyContext:{Provider:'AcademyProvider'}},{get:(target,key)=>target[key]||key});
const app=compile('../components/academy/app.tsx',id=>{
 if(id==='react')return hooks;
 if(id==='react/jsx-runtime')return {jsx:element,jsxs:element,Fragment:'Fragment'};
 if(id==='next/link')return {__esModule:true,default:'Link'};
 if(id==='next/navigation')return {useRouter:()=>({push(){},replace(){}})};
 if(id==='./ui')return ui;
 if(id==='lucide-react'||['./marketing','./motion','./demo','./learning','./membership'].includes(id))return new Proxy({},{get:(_target,key)=>key});
 if(id==='@/lib/academy/types')return api;
 throw new Error(`Unexpected app dependency ${id}`);
}).default;
const flush=()=>new Promise(resolve=>setImmediate(resolve));
const identity={name:'Learner',email:'learner@example.test'};
const snapshot=(id='learner',xp=0)=>({user:{userId:id},profile:{displayName:id},progress:{completedLessonIds:[],passedAssessmentIds:[],xp},billing:{mode:'pilot',tier:'explore'}});
function setup(t){
 const requests=[];
 for(const [key,value] of Object.entries({window:{},sessionStorage:{getItem:()=> 'yes',setItem(){}}})){
  const previous=Object.getOwnPropertyDescriptor(globalThis,key);
  Object.defineProperty(globalThis,key,{configurable:true,value});
  t.after(()=>{if(previous)Object.defineProperty(globalThis,key,previous);else delete globalThis[key];});
 }
 api.resetLearnerExpectation();
 t.mock.method(globalThis,'fetch',(path,init)=>new Promise((resolve,reject)=>{requests.push({path,init,resolve,reject});}));
 return {
  requests,
  at(path,index=0){const request=requests.filter(item=>item.path===path)[index];assert.ok(request,`${path} request ${index} exists`);return request;},
  respond(request,value){request.resolve(Response.json(value));},
 };
}
function harness(t,props={route:'/dashboard',identity}){
 const view={props,slots:[],cursor:0,pending:[],dirty:false,tree:null};
 view.render=(nextProps=view.props)=>{
  view.props=nextProps;let passes=0;
  do{active=view;view.cursor=0;view.pending=[];view.dirty=false;view.tree=app(view.props);for(const effect of view.pending)effect();assert.ok(++passes<12,'app effects settle');}while(view.dirty);
  return view.tree;
 };
 view.context=()=>view.tree.props.value;
 view.unmount=()=>{for(const slot of view.slots){slot?.cleanup?.();if(slot)slot.cleanup=undefined;}};
 t.after(view.unmount);
 return view;
}
function find(node,predicate){
 if(!node||typeof node!=='object')return undefined;
 if(Array.isArray(node)){for(const child of node){const found=find(child,predicate);if(found)return found;}return undefined;}
 if(predicate(node))return node;
 return find(node.props?.children,predicate);
}
async function boot(view,net,value=snapshot()){
 view.render();net.respond(net.at('/api/catalog'),{modules:[]});net.respond(net.at('/api/me'),value);await flush();view.render();
}
async function expectedHeader(net){
 const pending=api.post('/api/progress',{lessonId:'C01-L01'});
 const request=net.requests.at(-1);
 assert.equal(request.path,'/api/progress');
 const header=request.init.headers.get('X-Academy-Learner');
 net.respond(request,{completed:true});await pending;return header;
}

test('request helper ignores stale /me success when choosing the learner consistency header',async t=>{
 const net=setup(t);
 const older=api.request('/api/me'),newer=api.request('/api/me');
 net.respond(net.at('/api/me',1),snapshot('new-learner'));await newer;
 net.respond(net.at('/api/me',0),snapshot('old-learner'));await older;
 assert.equal(await expectedHeader(net),'new-learner');
});

test('a newer /me failure prevents an older response from replacing the last known learner',async t=>{
 const net=setup(t);
 const initial=api.request('/api/me');net.respond(net.at('/api/me'),snapshot('known-learner'));await initial;
 const older=api.request('/api/me'),newer=api.request('/api/me');
 const rejected=assert.rejects(newer,/Latest request failed/);
 net.at('/api/me',2).reject(new Error('Latest request failed'));await rejected;
 net.respond(net.at('/api/me',1),snapshot('stale-learner'));await older;
 assert.equal(await expectedHeader(net),'known-learner');
});

test('overlapping successful refreshes keep the newest displayed progress',async t=>{
 const net=setup(t),view=harness(t);await boot(view,net);
 const older=view.context().refresh(),newer=view.context().refresh();
 net.respond(net.at('/api/me',2),snapshot('learner',100));await newer;view.render();
 net.respond(net.at('/api/me',1),snapshot('learner',25));await older;view.render();
 assert.equal(view.context().me.progress.xp,100);
 assert.equal(find(view.tree,node=>node.type==='ErrorPanel'),undefined);
});

test('an obsolete refresh error cannot replace a newer successful snapshot or reject its saved-action caller',async t=>{
 const net=setup(t),view=harness(t);await boot(view,net);
 const older=view.context().refresh(),newer=view.context().refresh();
 net.respond(net.at('/api/me',2),snapshot('learner',200));await newer;
 net.at('/api/me',1).reject(new Error('Obsolete network error'));await older;view.render();
 assert.equal(view.context().me.progress.xp,200);
 assert.equal(find(view.tree,node=>node.type==='ErrorPanel'),undefined);
});

test('the newest refresh error is retained while an older success is ignored',async t=>{
 const net=setup(t),view=harness(t);await boot(view,net,snapshot('learner',75));
 const older=view.context().refresh(),newer=view.context().refresh();
 const rejected=assert.rejects(newer,/Latest account unavailable/);
 net.at('/api/me',2).reject(new Error('Latest account unavailable'));await rejected;
 net.respond(net.at('/api/me',1),snapshot('stale-learner',25));await older;view.render();
 assert.equal(view.context().me.progress.xp,75);
 assert.match(find(view.tree,node=>node.type==='ErrorPanel').props.message,/Latest account unavailable/);
 assert.equal(await expectedHeader(net),'learner');
});

test('identity changes invalidate the old initial loader, including catalogue errors and learner expectations',async t=>{
 const net=setup(t),view=harness(t);view.render();
 view.render({route:'/dashboard',identity:{name:'Second learner',email:'second@example.test'}});
 net.respond(net.at('/api/catalog',1),{modules:[]});net.respond(net.at('/api/me',1),snapshot('second-learner',50));await flush();view.render();
 net.at('/api/catalog',0).reject(new Error('Old identity catalogue failure'));net.respond(net.at('/api/me',0),snapshot('first-learner',10));await flush();view.render();
 assert.equal(view.context().me.user.userId,'second-learner');assert.equal(view.context().loadError,'');
 assert.equal(await expectedHeader(net),'second-learner');
});

test('retry loader and explicit refresh share ordering without an old failure replacing the refreshed record',async t=>{
 const net=setup(t),view=harness(t);view.render();
 net.at('/api/catalog').reject(new Error('Catalogue temporarily unavailable'));net.respond(net.at('/api/me'),snapshot('learner',25));await flush();view.render();
 find(view.tree,node=>node.type==='ErrorPanel').props.retry();view.render();
 const newer=view.context().refresh();net.respond(net.at('/api/me',2),snapshot('learner',125));await newer;
 net.respond(net.at('/api/catalog',1),{modules:[]});net.at('/api/me',1).reject(new Error('Obsolete retry error'));await flush();view.render();
 assert.equal(view.context().me.progress.xp,125);assert.equal(view.context().loading,false);
 assert.equal(find(view.tree,node=>node.type==='ErrorPanel'),undefined);
});

test('unmount invalidates a pending refresh and its learner header side effect',async t=>{
 const net=setup(t),view=harness(t);await boot(view,net);
 const pending=view.context().refresh();view.render();view.unmount();
 net.respond(net.at('/api/me',1),snapshot('old-component',300));await pending;
 assert.equal(view.dirty,false);
 assert.equal(await expectedHeader(net),null);
});

test('catalogue failure preserves the landing film and independent support, policy and demo routes with retry',async t=>{
 const net=setup(t);
 for(const [index,route] of ['/','/support','/privacy','/terms','/demo','/dashboard'].entries()){
  const view=harness(t,{route,identity});view.render();
  net.at('/api/catalog',index).reject(new Error('Catalogue unavailable'));net.respond(net.at('/api/me',index),snapshot());await flush();view.render();
  const page=find(view.tree,node=>node.type==='Suspense');
  if(route==='/'){
   assert.ok(page,'landing content and film stay mounted');
   assert.equal(typeof find(page,node=>node.type==='Landing').props.retryCatalog,'function');
   assert.equal(find(view.tree,node=>node.type==='ErrorPanel'),undefined);
  }
  else if(route==='/dashboard')assert.equal(page,undefined);
  else {assert.ok(page,`${route} content stays mounted`);assert.match(find(view.tree,node=>node.type==='ErrorPanel').props.message,/This page remains available/);}
  if(route!=='/')assert.equal(typeof find(view.tree,node=>node.type==='ErrorPanel').props.retry,'function');
  view.unmount();
 }
});
