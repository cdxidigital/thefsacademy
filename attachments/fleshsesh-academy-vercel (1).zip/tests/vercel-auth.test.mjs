import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync, existsSync} from 'node:fs';
import {dirname, resolve, extname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {runInThisContext} from 'node:vm';
import ts from 'typescript';

// Exercise the actual portable auth modules and button handlers with Clerk's
// transport mocked. This is not a live Clerk login or browser session test.
const root=fileURLToPath(new URL('../',import.meta.url));
const element=(type,props)=>({type,props:props||{}});
class Redirect extends Error {constructor(location){super(`Redirect to ${location}`);this.location=location;}}
function configure(t, publishable='test-publishable-key',secret='test-secret-key'){
  for(const [key,value] of Object.entries({NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY:publishable,CLERK_SECRET_KEY:secret})){
    const before=process.env[key];
    if(value===undefined)delete process.env[key];else process.env[key]=value;
    t.after(()=>{if(before===undefined)delete process.env[key];else process.env[key]=before;});
  }
}
function fixture(){
  const state={session:{userId:null},user:null,authCalls:[],profileCalls:0,headerReads:0,middlewareCalls:[],signOutCalls:[],legacy:new Headers({'oai-authenticated-user-id':'forged-user','oai-authenticated-user-email':'forged@example.test','oai-authenticated-user-full-name':'Forged name'})};
  let active;
  const hooks={
    useRef(initial){const owner=active,index=owner.cursor++;if(!owner.slots[index])owner.slots[index]={current:initial};return owner.slots[index];},
    useState(initial){const owner=active,index=owner.cursor++;if(!owner.slots[index])owner.slots[index]={value:initial};return [owner.slots[index].value,value=>{owner.slots[index].value=typeof value==='function'?value(owner.slots[index].value):value;}];},
  };
  state.signOut=async options=>{state.signOutCalls.push(options);};
  const overrides={
    'server-only':{},
    react:hooks,
    'react/jsx-runtime':{jsx:element,jsxs:element,Fragment:'Fragment'},
    'next/navigation':{redirect:location=>{throw new Redirect(location);}},
    'next/link':{__esModule:true,default:'Link'},
    'next/headers':{headers:async()=>{state.headerReads++;return state.legacy;}},
    'next/server':{NextResponse:{next:()=>({kind:'next'})}},
    '@clerk/nextjs/server':{
      auth:async options=>{state.authCalls.push(options);if(state.authError)throw state.authError;return state.session;},
      currentUser:async()=>{state.profileCalls++;return state.user;},
      clerkMiddleware:options=>(request,event)=>{state.middlewareCalls.push({options,request,event});return {kind:'verified-middleware'};},
    },
    '@clerk/nextjs':{SignIn:'ClerkSignIn',SignUp:'ClerkSignUp',ClerkProvider:'ClerkProvider',useClerk:()=>({signOut:options=>state.signOut(options)})},
  };
  const cache=new Map();
  function load(path){
    let absolute=resolve(root,path);
    if(!extname(absolute)){absolute=['.ts','.tsx'].map(extension=>absolute+extension).find(existsSync)||absolute;}
    if(absolute.endsWith('.css'))return {};
    if(cache.has(absolute))return cache.get(absolute).exports;
    const module={exports:{}};cache.set(absolute,module);
    const code=ts.transpileModule(readFileSync(absolute,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText;
    runInThisContext(`(function(require,module,exports){${code}\n})`,{filename:absolute})(id=>{
      if(Object.hasOwn(overrides,id))return overrides[id];
      if(id.startsWith('@/'))return load(id.slice(2));
      if(id.startsWith('.'))return load(resolve(dirname(absolute),id));
      throw new Error(`Unexpected auth dependency ${id}`);
    },module,module.exports);
    return module.exports;
  }
  state.signedIn=(id='verified-user')=>{state.session={userId:id};state.user={id,fullName:'Verified learner',firstName:'Verified',lastName:'learner',primaryEmailAddress:{emailAddress:'verified@example.test'},privateMetadata:{mustNotReachClient:true}};};
  state.buttonView=props=>{
    const component=load('components/auth/sign-out-action.tsx').SignOutAction;
    const view={slots:[],cursor:0,tree:null};
    view.render=()=>{active=view;view.cursor=0;view.tree=component(props);return view.tree;};
    view.render();return view;
  };
  return {state,load};
}
function find(node,predicate){
  if(!node||typeof node!=='object')return undefined;
  if(Array.isArray(node)){for(const child of node){const value=find(child,predicate);if(value)return value;}return undefined;}
  if(predicate(node))return node;
  return find(node.props?.children,predicate);
}
function textOf(node){if(node==null||typeof node==='boolean')return '';if(Array.isArray(node))return node.map(textOf).join(' ');if(typeof node==='object')return textOf(node.props?.children);return String(node);}
const params=value=>({searchParams:Promise.resolve(value||{})});
const redirected=(action,expected)=>assert.rejects(action,error=>error instanceof Redirect&&error.location===expected);

test('missing either Clerk key keeps the public identity anonymous without invoking the SDK',async t=>{
  configure(t,'','');
  const {state,load}=fixture(),auth=load('app/chatgpt-auth.ts');
  for(const [publishable,secret] of [['',''],['public-only',''],['','secret-only'],[' ','secret-only']]){
    process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=publishable;process.env.CLERK_SECRET_KEY=secret;
    assert.equal(await auth.getChatGPTUser(),null);
  }
  assert.equal(state.authCalls.length,0);assert.equal(state.profileCalls,0);assert.equal(state.headerReads,0);
});

test('spoofed legacy identity headers cannot authenticate a signed-out request',async t=>{
  configure(t);
  const {state,load}=fixture();
  assert.equal(await load('app/chatgpt-auth.ts').getChatGPTUser(),null);
  assert.deepEqual(state.authCalls,[{acceptsToken:'session_token',treatPendingAsSignedOut:true}]);
  assert.equal(state.profileCalls,0);assert.equal(state.headerReads,0);
});

test('the identity uses only a verified matching Clerk profile and omits private metadata',async t=>{
  configure(t);
  const {state,load}=fixture();state.signedIn();
  assert.deepEqual(await load('app/chatgpt-auth.ts').getChatGPTUser(),{userId:'verified-user',displayName:'Verified learner',email:'verified@example.test',fullName:'Verified learner'});
  assert.equal(state.headerReads,0);
});

test('missing or mismatched server profiles do not inherit a session identity',async t=>{
  configure(t);
  const {state,load}=fixture();state.session={userId:'signed-session'};
  const auth=load('app/chatgpt-auth.ts');
  for(const user of [null,{id:'other-user',fullName:'Other learner'}]){state.user=user;assert.equal(await auth.getChatGPTUser(),null);}
});

test('a Clerk verification error never falls back to legacy headers',async t=>{
  configure(t);
  const {state,load}=fixture();state.authError=new Error('Verification unavailable');
  await assert.rejects(load('app/chatgpt-auth.ts').getChatGPTUser(),/Verification unavailable/);
  assert.equal(state.headerReads,0);assert.equal(state.profileCalls,0);
});

test('return paths reject external, encoded, control-character and auth-loop destinations',()=>{
  const {load}=fixture(),{safeRelativeReturnPath}=load('lib/auth/paths.ts');
  for(const value of ['https://evil.example','//evil.example','/\\evil.example','/%2f%2fevil.example','/%5cevil.example','/%252f%252fevil.example','/../%2f/evil.example','/dashboard\n','/dashboard%0a',' /dashboard','/sign-in','/sign-in/verify','/%73ign-out','/signin-with-chatgpt?return_to=/dashboard','/signout-with-chatgpt','/login','/signup','/callback','/api/account/delete','javascript:alert(1)','/unknown','/%',null,['/dashboard']]){
    assert.equal(safeRelativeReturnPath(value),'/');
  }
  for(const value of ['/','/dashboard','/demo','/learn/C01-L01','/tutor?lesson=C03-L01#reply','/resources?tab=glossary'])assert.equal(safeRelativeReturnPath(value),value);
});

test('the proxy bypasses unconfigured auth and delegates configured requests to Clerk',async t=>{
  configure(t,'','');
  const {state,load}=fixture(),proxy=load('proxy.ts').default,request={url:'https://academy.example/dashboard'},event={};
  assert.deepEqual(await proxy(request,event),{kind:'next'});assert.equal(state.middlewareCalls.length,0);
  process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY='test-public';process.env.CLERK_SECRET_KEY='test-secret';
  assert.deepEqual(await proxy(request,event),{kind:'verified-middleware'});
  assert.deepEqual(state.middlewareCalls,[{options:{signInUrl:'/sign-in',signUpUrl:'/sign-up'},request,event}]);
});

test('ClerkProvider is inside body only when both keys are configured',t=>{
  configure(t,'','');
  const {load}=fixture(),layout=load('app/layout.tsx').default;
  let tree=layout({children:'Public landing'});
  assert.equal(find(tree,node=>node.type==='ClerkProvider'),undefined);assert.match(textOf(tree),/Public landing/);
  process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY='test-public';process.env.CLERK_SECRET_KEY='test-secret';
  tree=layout({children:'Public landing'});
  const body=find(tree,node=>node.type==='body');
  assert.equal(body.props.children.type,'ClerkProvider');assert.match(textOf(body),/Public landing/);
});

test('sign-in and sign-up mount their distinct Clerk flows with safe forced destinations',async t=>{
  configure(t);
  const {load}=fixture();
  const signIn=await load('app/sign-in/[[...sign-in]]/page.tsx').default(params({return_to:'/demo',redirect_url:'https://evil.example'}));
  const signUp=await load('app/sign-up/[[...sign-up]]/page.tsx').default(params({return_to:'//evil.example',redirect_url:'https://evil.example'}));
  const inControl=find(signIn,node=>node.type==='ClerkSignIn'),upControl=find(signUp,node=>node.type==='ClerkSignUp');
  assert.equal(inControl.props.path,'/sign-in');assert.equal(inControl.props.withSignUp,false);
  assert.equal(inControl.props.forceRedirectUrl,'/demo');assert.equal(inControl.props.signUpForceRedirectUrl,'/demo');
  assert.equal(inControl.props.signUpUrl,'/sign-up?return_to=%2Fdemo');
  assert.equal(upControl.props.path,'/sign-up');assert.equal(upControl.props.forceRedirectUrl,'/onboarding');
  assert.equal(upControl.props.signInForceRedirectUrl,'/onboarding');assert.equal(upControl.props.signInUrl,'/sign-in?return_to=%2Fonboarding');
});

test('unconfigured auth pages show setup-unavailable content instead of a fake account flow',async t=>{
  configure(t,'','');
  const {state,load}=fixture(),{AuthUnavailable}=load('components/auth/auth-shell.tsx');
  for(const route of ['app/sign-in/[[...sign-in]]/page.tsx','app/sign-up/[[...sign-up]]/page.tsx','app/sign-out/page.tsx']){
    const tree=await load(route).default(params());
    assert.ok(find(tree,node=>node.type===AuthUnavailable));
    assert.equal(find(tree,node=>['ClerkSignIn','ClerkSignUp','ClerkProvider'].includes(node.type)),undefined);
  }
  assert.match(textOf(AuthUnavailable()),/Account setup is not available yet/);
  assert.equal(state.authCalls.length,0);assert.equal(state.signOutCalls.length,0);
});

test('login/signup and compatibility aliases retain distinct flows without mutating sessions on GET',async t=>{
  configure(t);
  const {state,load}=fixture();
  for(const [route,query,destination] of [
    ['app/login/page.tsx',{},'/sign-in?return_to=%2Fdashboard'],
    ['app/signup/page.tsx',{},'/sign-up?return_to=%2Fonboarding'],
    ['app/signin-with-chatgpt/page.tsx',{return_to:'/demo'},'/sign-in?return_to=%2Fdemo'],
    ['app/signout-with-chatgpt/page.tsx',{return_to:'https://evil.example'},'/sign-out?return_to=%2F'],
  ])await redirected(()=>load(route).default(params(query)),destination);
  assert.equal(state.signOutCalls.length,0);assert.equal(state.authCalls.length,0);
});

test('verified users return to local content and protected-page redirects remain local',async t=>{
  configure(t);
  const {state,load}=fixture();state.signedIn();
  await redirected(()=>load('app/sign-in/[[...sign-in]]/page.tsx').default(params({return_to:'/progress'})),'/progress');
  await redirected(()=>load('app/sign-up/[[...sign-up]]/page.tsx').default(params({return_to:'//evil.example'})),'/onboarding');
  state.session={userId:null};
  await redirected(()=>load('app/chatgpt-auth.ts').requireChatGPTUser('/learn/C02-L01'),'/sign-in?return_to=%2Flearn%2FC02-L01');
});

test('sign-out runs the SDK only after a button action, once per in-flight attempt',async t=>{
  configure(t);
  const {state}=fixture();let finish;
  state.signOut=options=>{state.signOutCalls.push(options);return new Promise(resolve=>{finish=resolve;});};
  const view=state.buttonView({returnTo:'//evil.example'});
  assert.equal(state.signOutCalls.length,0);
  const button=find(view.tree,node=>node.type==='button');assert.equal(button.props.type,'button');
  const pending=button.props.onClick();await button.props.onClick();view.render();
  assert.deepEqual(state.signOutCalls,[{redirectUrl:'/'}]);
  assert.equal(find(view.tree,node=>node.type==='button').props.disabled,true);
  finish();await pending;
});

test('failed SDK sign-out reports the failure and permits a deliberate retry',async t=>{
  configure(t);
  const {state}=fixture();let attempts=0;
  state.signOut=async()=>{if(++attempts===1)throw new Error('Network unavailable');};
  const view=state.buttonView({returnTo:'/'});
  await find(view.tree,node=>node.type==='button').props.onClick();view.render();
  assert.match(textOf(find(view.tree,node=>node.props.role==='alert')),/couldn’t complete sign-out/);
  assert.equal(find(view.tree,node=>node.type==='button').props.disabled,false);
  await find(view.tree,node=>node.type==='button').props.onClick();assert.equal(attempts,2);
});
