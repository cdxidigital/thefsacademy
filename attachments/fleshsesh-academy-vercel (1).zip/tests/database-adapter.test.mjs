import './backend-runtime.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { cp, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createConfiguredClient, databaseConfiguration, DatabaseConfigurationError } from '../lib/server/database-config.mjs';
import { applyMigrations, loadMigrations } from '../scripts/migrate.mjs';

const { LibsqlDatabase, configuredDatabase } = await import('../lib/server/database.ts');

const sourceMigrations = resolve(dirname(fileURLToPath(import.meta.url)), '../drizzle');
const localEnvironment = { TURSO_DATABASE_URL: ':memory:', LIBSQL_ALLOW_LOCAL: 'true', NODE_ENV: 'test' };
async function fixture(t) {
  const client = createConfiguredClient(databaseConfiguration(localEnvironment));
  t.after(() => client.close());
  await applyMigrations(client);
  return new LibsqlDatabase(client);
}
function profile(db, userId, displayName = 'Test learner') {
  return db.prepare('INSERT INTO profiles (user_id,display_name,accepted_version,adult_confirmed_at,education_acknowledged_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?)').bind(userId, displayName, 'test-policy', '2026-10-17', '2026-10-17', '2026-10-17', '2026-10-17');
}

test('database configuration fails closed and production selects HTTP without creating local storage', t => {
  assert.equal(configuredDatabase({}), null);
  for (const environment of [
    { TURSO_DATABASE_URL: 'file:/tmp/academy.db' },
    { ...localEnvironment, NODE_ENV: 'production' },
    { ...localEnvironment, VERCEL: '1' },
    { TURSO_DATABASE_URL: 'http://database.example.test', TURSO_AUTH_TOKEN: 'test-token' },
    { TURSO_DATABASE_URL: 'libsql://database.example.test' },
    { TURSO_DATABASE_URL: 'libsql://database.example.test?tls=0', TURSO_AUTH_TOKEN: 'test-token' },
    { TURSO_DATABASE_URL: 'https://user:password@database.example.test', TURSO_AUTH_TOKEN: 'test-token' },
  ]) assert.throws(() => databaseConfiguration(environment), DatabaseConfigurationError);
  assert.equal(databaseConfiguration(localEnvironment).local, true);
  const fetch = t.mock.method(globalThis, 'fetch', async () => { throw new Error('Configuration must not contact a database'); });
  const remote = createConfiguredClient(databaseConfiguration({ NODE_ENV: 'production', VERCEL: '1', TURSO_DATABASE_URL: 'libsql://database.example.test', TURSO_AUTH_TOKEN: 'test-token' }));
  assert.equal(remote.protocol, 'http'); remote.close(); assert.equal(fetch.mock.callCount(), 0);
});

test('actual libSQL statements preserve bound values, named rows, first-column reads, and changes metadata', async t => {
  const db = await fixture(t); const name = "Alex'); DROP TABLE profiles; --";
  assert.equal((await profile(db, 'learner-a', name).run()).meta.changes, 1);
  await profile(db, 'learner-b').run();
  const select = db.prepare('SELECT user_id AS userId, display_name AS displayName FROM profiles WHERE user_id=?');
  assert.deepEqual(await select.bind('learner-a').first(), { userId: 'learner-a', displayName: name });
  assert.equal(await select.bind('learner-b').first('userId'), 'learner-b');
  assert.equal(await select.bind('missing').first(), null);
  await assert.rejects(select.bind('learner-a').first('missing'));
  assert.throws(() => select.bind(undefined), TypeError); assert.throws(() => select.bind(NaN), TypeError);
  const result = await db.prepare('SELECT user_id AS id FROM profiles ORDER BY user_id').all();
  assert.deepEqual(result.results, [{ id: 'learner-a' }, { id: 'learner-b' }]); assert.equal(result.success, true);
  const insert = db.prepare("INSERT INTO lesson_progress (user_id,lesson_id,completed_at) VALUES (?,'C01-L01','2026-10-17') ON CONFLICT(user_id,lesson_id) DO NOTHING").bind('learner-a');
  assert.equal((await insert.run()).meta.changes, 1); assert.equal((await insert.run()).meta.changes, 0);
});

test('payment-style batches commit once and roll back every statement when a later write fails', async t => {
  const db = await fixture(t); await profile(db, 'learner-a').run();
  const event = db.prepare("INSERT INTO payment_events(id,type,created_at) VALUES (?,'test','2026-10-17')");
  const credit = db.prepare('UPDATE profiles SET tutor_credits=tutor_credits+50 WHERE user_id=?').bind('learner-a');
  const successful = await db.batch([event.bind('event-1'), credit]);
  assert.deepEqual(successful.map(item => item.meta.changes), [1, 1]);
  await assert.rejects(db.batch([credit, event.bind('event-1')]));
  assert.equal(await db.prepare('SELECT tutor_credits FROM profiles WHERE user_id=?').bind('learner-a').first('tutor_credits'), 50);
  await assert.rejects(db.batch([event.bind('event-2'), db.prepare("INSERT INTO lesson_progress VALUES ('missing','C01-L01','2026-10-17')")]));
  assert.equal(await db.prepare('SELECT id FROM payment_events WHERE id=?').bind('event-2').first(), null);
  const other = await fixture(t); await assert.rejects(db.batch([profile(other, 'wrong-database')]), TypeError);
  assert.deepEqual(await db.batch([]), []);
});

test('conditional RETURNING writes enforce tutor quota and credits without read-modify-write races', async t => {
  const db = await fixture(t); await profile(db, 'learner-a').run();
  const reserve = db.prepare("INSERT INTO tutor_usage(user_id,bucket,count) VALUES (?,'month',1) ON CONFLICT(user_id,bucket) DO UPDATE SET count=tutor_usage.count+1 WHERE tutor_usage.count<3 RETURNING count").bind('learner-a');
  const attempts = await Promise.all(Array.from({ length: 12 }, () => reserve.first()));
  assert.equal(attempts.filter(Boolean).length, 3); assert.equal(await db.prepare("SELECT count FROM tutor_usage WHERE bucket='month'").first('count'), 3);
  await db.prepare('UPDATE profiles SET tutor_credits=2 WHERE user_id=?').bind('learner-a').run();
  const debit = db.prepare('UPDATE profiles SET tutor_credits=tutor_credits-1 WHERE user_id=? AND tutor_credits>0 RETURNING tutor_credits').bind('learner-a');
  assert.equal((await Promise.all(Array.from({ length: 8 }, () => debit.first()))).filter(Boolean).length, 2);
  assert.equal(await db.prepare('SELECT tutor_credits FROM profiles WHERE user_id=?').bind('learner-a').first('tutor_credits'), 0);
});

test('real libSQL foreign keys preserve per-learner delete cascades and reject orphan records', async t => {
  const db = await fixture(t); await db.batch([profile(db, 'learner-a'), profile(db, 'learner-b')]);
  for (const userId of ['learner-a', 'learner-b']) await db.prepare("INSERT INTO lesson_progress VALUES (?,'C01-L01','2026-10-17')").bind(userId).run();
  await db.prepare("INSERT INTO demo_sessions VALUES ('token-hash','owner','learner-a','2026-10-17','2026-10-18')").run();
  await db.prepare('DELETE FROM profiles WHERE user_id=?').bind('learner-a').run();
  assert.deepEqual((await db.prepare('SELECT user_id FROM lesson_progress').all()).results, [{ user_id: 'learner-b' }]);
  assert.equal(await db.prepare('SELECT COUNT(*) AS count FROM demo_sessions').first('count'), 0);
  await assert.rejects(db.prepare("INSERT INTO lesson_progress VALUES ('learner-a','C01-L02','2026-10-17')").run());
});

test('committed migrations apply in journal order, repeat safely, and reject changed applied files', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'fsa-libsql-migrations-')); t.after(() => rm(directory, { recursive: true, force: true }));
  await cp(sourceMigrations, directory, { recursive: true });
  const client = createConfiguredClient(databaseConfiguration(localEnvironment)); t.after(() => client.close());
  const expected = (await loadMigrations(directory)).map(item => item.tag);
  assert.deepEqual((await applyMigrations(client, directory)).applied, expected);
  assert.deepEqual(await applyMigrations(client, directory), { applied: [], skipped: expected });
  assert.ok((await client.execute('PRAGMA table_info(profiles)')).rows.some(row => row.name === 'active_assessment_id'));
  const changed = join(directory, `${expected[0]}.sql`); await writeFile(changed, `${await readFile(changed, 'utf8')}\n-- edited after application\n`);
  await assert.rejects(applyMigrations(client, directory), /history differs/);
  assert.equal((await client.execute('SELECT COUNT(*) AS count FROM __academy_migrations')).rows[0].count, expected.length);
});

test('a failed later migration rolls back the entire pending schema and checksum ledger', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'fsa-libsql-rollback-')); t.after(() => rm(directory, { recursive: true, force: true }));
  await cp(sourceMigrations, directory, { recursive: true });
  const migrations = await loadMigrations(directory); const last = join(directory, `${migrations.at(-1).tag}.sql`); const original = await readFile(last, 'utf8');
  await writeFile(last, `${original}\n--> statement-breakpoint\nTHIS IS INVALID SQL;`);
  const client = createConfiguredClient(databaseConfiguration(localEnvironment)); t.after(() => client.close());
  await client.execute('CREATE TABLE preserved (id INTEGER PRIMARY KEY)'); await client.execute('INSERT INTO preserved VALUES (1)');
  await assert.rejects(applyMigrations(client, directory));
  assert.equal((await client.execute("SELECT COUNT(*) AS count FROM sqlite_master WHERE name IN ('profiles','__academy_migrations')")).rows[0].count, 0);
  assert.equal((await client.execute('SELECT COUNT(*) AS count FROM preserved')).rows[0].count, 1);
  await writeFile(last, original); assert.equal((await applyMigrations(client, directory)).applied.length, migrations.length);
});
