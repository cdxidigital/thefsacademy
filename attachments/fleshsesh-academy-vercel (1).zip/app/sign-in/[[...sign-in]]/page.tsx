import { SignIn } from "@clerk/nextjs";
import { redirect } from "next/navigation";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { AuthShell, AuthUnavailable } from "@/components/auth/auth-shell";
import { hasClerkConfiguration } from "@/lib/auth/config";
import { safeRelativeReturnPath, signUpPath, type AuthPageProps } from "@/lib/auth/paths";

export const dynamic = "force-dynamic";
export default async function SignInPage({ searchParams }: AuthPageProps) {
  const params = await searchParams;
  const returnTo = safeRelativeReturnPath(params.return_to, "/dashboard");
  const configured = hasClerkConfiguration();
  if (configured && await getChatGPTUser()) redirect(returnTo);
  return <AuthShell title="Welcome back." description="Step back into your learning with your secure Academy account.">
    {configured ? <>
      <SignIn routing="path" path="/sign-in" signUpUrl={signUpPath(returnTo)} forceRedirectUrl={returnTo} signUpForceRedirectUrl={returnTo} withSignUp={false} fallback={<p role="status">Opening secure sign-in…</p>} />
      <noscript><p>Enable JavaScript to use secure sign-in.</p></noscript>
    </> : <AuthUnavailable />}
  </AuthShell>;
}
