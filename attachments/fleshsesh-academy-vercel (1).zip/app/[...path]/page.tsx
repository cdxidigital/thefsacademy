import { getChatGPTUser, requireChatGPTUser } from '../chatgpt-auth';
import AcademyApp from '@/components/academy/app';
import { notFound } from 'next/navigation';
export const dynamic = 'force-dynamic';
const publicRoutes = new Set(['library','courses','pricing','about','login','signup','privacy','terms','support','demo','resources']);
const validRoutes = new Set([...publicRoutes,'dashboard','onboarding','learn','courses','assessment','tutor','progress','resources','account','business']);
async function Screen({route,isPublic}:{route:string,isPublic:boolean}) {
 const user = isPublic ? await getChatGPTUser() : await requireChatGPTUser(route);
 return <AcademyApp route={route} identity={user ? {name:user.displayName,email:user.email} : null} />;
}
export default async function Page({params}:{params:Promise<{path:string[]}>}) {
 const {path} = await params;
 if (!path?.length || !validRoutes.has(path[0])) notFound();
 const detailRoutes=new Set(['learn','courses','assessment']);
 if(path.length>(detailRoutes.has(path[0])?2:1))notFound();
 if(detailRoutes.has(path[0])&&path.length!==2)notFound();
 const route = '/' + path.join('/');
 return <Screen route={route} isPublic={publicRoutes.has(path[0])} />;
}
