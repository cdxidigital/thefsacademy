import Link from "next/link";
import { AuthShell, AuthUnavailable } from "@/components/auth/auth-shell";
import { SignOutAction } from "@/components/auth/sign-out-action";
import { hasClerkConfiguration } from "@/lib/auth/config";
import { safeRelativeReturnPath, type AuthPageProps } from "@/lib/auth/paths";

export const dynamic = "force-dynamic";
export default async function SignOutPage({ searchParams }: AuthPageProps) {
  const params = await searchParams;
  const returnTo = safeRelativeReturnPath(params.return_to);
  return <AuthShell title="Taking a break?" description="Use the button below to sign out on this browser. Your saved Academy learning remains in your account.">
    {hasClerkConfiguration() ? <>
      <SignOutAction returnTo={returnTo} />
      <Link className="text-link auth-cancel" href="/account">Stay signed in</Link>
    </> : <AuthUnavailable />}
  </AuthShell>;
}
