import { redirect } from "next/navigation";
import { signUpPath, type AuthPageProps } from "@/lib/auth/paths";

export const dynamic = "force-dynamic";
export default async function Signup({ searchParams }: AuthPageProps) {
  redirect(signUpPath((await searchParams).return_to));
}
