import Link from 'next/link';
export default function NotFound(){return <main className="not-found"><span className="eyebrow">A LITTLE OFF THE PATH</span><h1>Let’s find your<br/><em>next chapter.</em></h1><p>This page isn’t in the Academy. Your learning is still right where you left it.</p><Link href="/" className="button primary">Back to the Academy</Link></main>}
