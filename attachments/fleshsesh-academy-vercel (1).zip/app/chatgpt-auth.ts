import { auth, currentUser } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { hasClerkConfiguration } from "@/lib/auth/config";
import { signInPath, signOutPath } from "@/lib/auth/paths";

// Compatibility names keep the Academy API contract intact in this portable
// edition. Identity comes only from Clerk, never from caller-supplied headers.
export type ChatGPTUser = {
  userId: string;
  displayName: string;
  email: string;
  fullName: string | null;
};

export async function getChatGPTUser(): Promise<ChatGPTUser | null> {
  if (!hasClerkConfiguration()) return null;
  const session = await auth({ acceptsToken: "session_token", treatPendingAsSignedOut: true });
  if (!session.userId) return null;
  const user = await currentUser();
  if (!user || user.id !== session.userId) return null;
  const email = user.primaryEmailAddress?.emailAddress ?? "";
  const fullName = user.fullName?.trim() || [user.firstName, user.lastName].filter(Boolean).join(" ").trim() || null;
  return { userId: user.id, displayName: fullName || email || "Academy learner", email, fullName };
}

export async function requireChatGPTUser(returnTo: string): Promise<ChatGPTUser> {
  const user = await getChatGPTUser();
  if (user) return user;
  redirect(chatGPTSignInPath(returnTo));
}

export function chatGPTSignInPath(returnTo: string): string {
  return signInPath(returnTo);
}

export function chatGPTSignOutPath(returnTo = "/"): string {
  return signOutPath(returnTo);
}
