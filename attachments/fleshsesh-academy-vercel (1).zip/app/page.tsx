import { getChatGPTUser } from './chatgpt-auth';
import AcademyApp from '@/components/academy/app';
export const dynamic = 'force-dynamic';
export default async function Home() {
 const user = await getChatGPTUser();
 return <AcademyApp route="/" identity={user ? {name:user.displayName,email:user.email} : null} />;
}
