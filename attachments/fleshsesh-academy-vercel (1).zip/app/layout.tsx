import type { Metadata } from 'next';
import { ClerkProvider } from '@clerk/nextjs';
import { hasClerkConfiguration } from '@/lib/auth/config';
import './globals.css';
import './brand.css';
import '@/components/academy/motion.css';
import '@/components/academy/promo-video.css';
import '@/components/academy/release-polish.css';
import '@/components/academy/tutor.css';
import '@/components/auth/auth.css';
export const metadata: Metadata = {
 title: { default: 'fleshsesh academy — Know more. Feel more. Be you.', template: '%s | fleshsesh academy' },
 description: 'An adult learning space for consent, connection and sexual wellbeing. Explore 48 thoughtful lessons, learn at your own pace and grow your confidence.',
 robots: {index:false,follow:false},
 icons: {icon:'/favicon.svg',shortcut:'/favicon.svg',apple:'/apple-touch-icon.png'},
 manifest:'/site.webmanifest',
 applicationName:'fleshsesh academy',
 openGraph:{title:'fleshsesh academy',description:'Your curiosity belongs here. Adult learning about consent, bodies, connection and personal choice.',images:[{url:'/brand/social-open-graph.png',width:1200,height:630,alt:'fleshsesh academy — learn at your own pace'}]},
};
export default function RootLayout({children}:{children:React.ReactNode}){
 const content=hasClerkConfiguration()?<ClerkProvider
  signInUrl="/sign-in"
  signUpUrl="/sign-up"
  signInFallbackRedirectUrl="/dashboard"
  signUpFallbackRedirectUrl="/onboarding"
  appearance={{
   variables:{
    colorPrimary:'#E6A7BB',
    colorPrimaryForeground:'#0D1014',
    colorBackground:'#17191F',
    colorForeground:'#F4EEE6',
    colorMutedForeground:'#CEC3CA',
    colorNeutral:'#F4EEE6',
    colorInput:'#0D1014',
    colorInputForeground:'#F4EEE6',
    borderRadius:'12px',
   },
   elements:{
    rootBox:{width:'100%'},
    cardBox:{width:'100%',maxWidth:'100%'},
    card:{background:'transparent',boxShadow:'none'},
    formButtonPrimary:{minHeight:'44px'},
   },
  }}
 >{children}</ClerkProvider>:children;
 return <html lang="en-AU"><body>{content}</body></html>;
}
