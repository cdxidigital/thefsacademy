import { SignUp } from "@clerk/nextjs";
import { redirect } from "next/navigation";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { AuthShell, AuthUnavailable } from "@/components/auth/auth-shell";
import { hasClerkConfiguration } from "@/lib/auth/config";
import { safeRelativeReturnPath, signInPath, type AuthPageProps } from "@/lib/auth/paths";

export const dynamic = "force-dynamic";
export default async function SignUpPage({ searchParams }: AuthPageProps) {
  const params = await searchParams;
  const returnTo = safeRelativeReturnPath(params.return_to, "/onboarding");
  const configured = hasClerkConfiguration();
  if (configured && await getChatGPTUser()) redirect(returnTo);
  return <AuthShell title="A new chapter. All yours." description="Create a secure account, then set up your learner profile. No payment details are needed to join.">
    {configured ? <>
      <SignUp routing="path" path="/sign-up" signInUrl={signInPath(returnTo)} forceRedirectUrl={returnTo} signInForceRedirectUrl={returnTo} fallback={<p role="status">Opening secure account setup…</p>} />
      <noscript><p>Enable JavaScript to create your secure account.</p></noscript>
    </> : <AuthUnavailable />}
  </AuthShell>;
}
