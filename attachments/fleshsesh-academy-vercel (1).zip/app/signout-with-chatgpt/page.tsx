import { redirect } from "next/navigation";
import { signOutPath, type AuthPageProps } from "@/lib/auth/paths";

export const dynamic = "force-dynamic";
export default async function LegacySignOut({ searchParams }: AuthPageProps) {
  // Visiting this URL only opens the sign-out confirmation. It changes no session.
  redirect(signOutPath((await searchParams).return_to));
}
