import { appOrigin, stripeRequest } from "@/lib/server/billing";
import { getBilling, requireProfile } from "@/lib/server/repository";
import { ApiError, assertRealAccount, handle, json, readJson, requireUser } from "@/lib/server/runtime";
export async function POST(request: Request) { return handle(async () => {
  await readJson(request, 1000); const user = await requireUser(); assertRealAccount(user); await requireProfile(user.userId);
  const billing = await getBilling(user.userId); if (!billing) throw new ApiError(404, "There is no billing account to manage yet.", "billing_account_missing");
  const session = await stripeRequest<{ url: string }>("/billing_portal/sessions", "POST", new URLSearchParams({ customer: billing.customerId, return_url: `${appOrigin()}/account` }));
  if (!session.url?.startsWith("https://billing.stripe.com/")) throw new ApiError(503, "The billing portal could not be opened.", "payment_provider_unavailable");
  return json({ url: session.url });
}); }
