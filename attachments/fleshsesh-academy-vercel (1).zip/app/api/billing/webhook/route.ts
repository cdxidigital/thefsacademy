import { processStripeEvent, type StripeEvent } from "@/lib/server/billing";
import { verifyStripeSignature } from "@/lib/server/pure";
import { ApiError, handle, json, readBoundedText, settings } from "@/lib/server/runtime";
export async function POST(request: Request) { return handle(async () => {
  const secret = settings().STRIPE_WEBHOOK_SECRET;
  if (!secret) throw new ApiError(503, "Payment events are not configured.", "billing_not_configured");
  const payload = await readBoundedText(request, 256000);
  if (!await verifyStripeSignature(payload, request.headers.get("stripe-signature"), secret)) throw new ApiError(400, "Invalid payment event signature.", "invalid_signature");
  let event: StripeEvent;
  try { event = JSON.parse(payload) as StripeEvent; } catch { throw new ApiError(400, "Invalid payment event.", "invalid_event"); }
  if (!event.id?.startsWith("evt_") || !event.type || !event.data?.object?.id || !Number.isFinite(event.created)) throw new ApiError(400, "Invalid payment event.", "invalid_event");
  return json(await processStripeEvent(event));
}); }
