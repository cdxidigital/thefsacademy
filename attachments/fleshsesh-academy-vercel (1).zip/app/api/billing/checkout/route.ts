import { createCheckout } from "@/lib/server/billing";
import { requireProfile } from "@/lib/server/repository";
import { handle, json, readJson, requireUser } from "@/lib/server/runtime";
export async function POST(request: Request) { return handle(async () => { const body = await readJson(request, 2000); const user = await requireUser(); await requireProfile(user.userId); return json(await createCheckout(user, body.product, body.moduleId, body.renewalConsent)); }); }
