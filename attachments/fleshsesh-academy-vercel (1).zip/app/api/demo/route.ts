import { demoStatus, manageDemo } from "@/lib/server/demo";
import { handle, json, readJson } from "@/lib/server/runtime";
export const dynamic = "force-dynamic";
export async function GET() { return handle(async () => json(await demoStatus())); }
export async function POST(request: Request) { return handle(async () => manageDemo(await readJson(request, 2000))); }
