import { accountSnapshot, requireProfile } from "@/lib/server/repository";
import { assertRealAccount, database, handle, requireUser } from "@/lib/server/runtime";
export async function GET() { return handle(async () => {
  const user = await requireUser(); assertRealAccount(user); await requireProfile(user.userId);
  const [snapshot, attempts, usage] = await Promise.all([
    accountSnapshot(user.userId),
    database().prepare("SELECT assessment_id AS assessmentId, score, total, passed, critical_passed AS criticalPassed, created_at AS createdAt FROM assessment_attempts WHERE user_id=? ORDER BY created_at").bind(user.userId).all(),
    database().prepare("SELECT bucket, count FROM tutor_usage WHERE user_id=?").bind(user.userId).all(),
  ]);
  return new Response(JSON.stringify({ exportedAt: new Date().toISOString(), user, ...snapshot, assessmentAttempts: attempts.results, tutorUsage: usage.results, privacyNote: "The Academy does not retain tutor messages, private reflections or payment-card data. Payment processor records are managed separately." }, null, 2), { headers: { "Content-Type": "application/json; charset=utf-8", "Content-Disposition": 'attachment; filename="Fleshsesh_Academy_Learning_Record.json"', "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
}); }
