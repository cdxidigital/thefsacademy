import { stripeRequest } from "@/lib/server/billing";
import { getBilling, requireProfile } from "@/lib/server/repository";
import { ApiError, assertRealAccount, database, handle, json, readJson, requireUser } from "@/lib/server/runtime";
export async function POST(request: Request) { return handle(async () => {
  const body = await readJson(request, 2000); const user = await requireUser(); assertRealAccount(user); await requireProfile(user.userId);
  if (body.confirmation !== "DELETE MY ACCOUNT") throw new ApiError(400, "Type DELETE MY ACCOUNT to delete your learning record and certificates.", "confirmation_required");
  const billing = await getBilling(user.userId);
  if (billing?.subscriptionId && billing.subscriptionStatus !== "canceled" && billing.subscriptionStatus !== "incomplete_expired") {
    await stripeRequest(`/subscriptions/${encodeURIComponent(billing.subscriptionId)}`, "DELETE");
  }
  // Foreign keys cascade through progress, attempts, access, usage and certificates.
  await database().batch([
    database().prepare("DELETE FROM profiles WHERE user_id IN (SELECT demo_user_id FROM demo_sessions WHERE owner_user_id=?)").bind(user.userId),
    database().prepare("DELETE FROM profiles WHERE user_id=?").bind(user.userId),
  ]);
  return json({ deleted: true, message: "Your Academy learning record has been deleted and any linked recurring subscription was cancelled. This does not delete your secure sign-in account. The payment provider retains its legally required transaction records." });
}); }
