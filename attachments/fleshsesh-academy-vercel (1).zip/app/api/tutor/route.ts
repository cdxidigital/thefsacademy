import { answerTutor } from '@/lib/server/tutor';
import { DEFAULT_TUTOR_ROLE, isTutorRole, type GuideMode, type PracticeChoice, type TutorHistoryTurn } from '@/lib/academy/tutor-personas';
import { ApiError, handle, json, readJson, requireUser, textValue } from '@/lib/server/runtime';

export async function POST(request: Request) { return handle(async () => {
  const body = await readJson(request, 6000);
  const user = await requireUser();
  const message = textValue(body.message, 'Question', 1200);
  const lessonId = body.lessonId == null ? undefined : textValue(body.lessonId, 'Lesson', 40);
  const assessmentId = body.assessmentId == null ? undefined : textValue(body.assessmentId, 'Assessment', 40);
  if (body.consentToAI !== undefined && typeof body.consentToAI !== 'boolean') throw new ApiError(400, 'Choose whether to allow external AI processing.', 'invalid_input');
  const role = body.role ?? DEFAULT_TUTOR_ROLE;
  if (!isTutorRole(role)) throw new ApiError(400, 'Choose one of the three Academy tutors.', 'invalid_role');
  const mode = body.mode ?? 'explain';
  if (typeof mode !== 'string' || !['explain', 'scenario', 'recap'].includes(mode)) throw new ApiError(400, 'Choose an explanation, scenario or recap.', 'invalid_input');

  const history: TutorHistoryTurn[] = [];
  if (body.history !== undefined) {
    if (!Array.isArray(body.history) || body.history.length > 4) throw new ApiError(400, 'Conversation context can include up to four short previous messages.', 'invalid_history');
    for (const turn of body.history) {
      if (!turn || typeof turn !== 'object' || Array.isArray(turn) || !['user', 'assistant'].includes(turn.role)) throw new ApiError(400, 'Conversation context contains an invalid message.', 'invalid_history');
      history.push({ role: turn.role, content: textValue(turn.content, 'Previous message', 500) });
    }
  }
  let practice: PracticeChoice | undefined;
  if (body.practice !== undefined) {
    const value = body.practice as Record<string, unknown>;
    if (role !== 'practice_coach' || !value || typeof value !== 'object' || Array.isArray(value) || !Number.isInteger(value.choiceIndex) || ![0, 1].includes(value.choiceIndex as number)) throw new ApiError(400, 'Choose one of the two practice responses.', 'invalid_practice');
    practice = { scenarioId: textValue(value.scenarioId, 'Practice scenario', 60), choiceIndex: value.choiceIndex as number };
  }
  return json(await answerTutor(user.userId, message, lessonId, body.consentToAI as boolean | undefined, mode as GuideMode, { role, history, practice, assessmentId }));
}); }
