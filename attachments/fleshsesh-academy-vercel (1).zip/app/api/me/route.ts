import { accountSnapshot, checkoutAvailable } from "@/lib/server/repository";
import { getLearnerUser, handle, isPilot, json, POLICY_VERSION } from "@/lib/server/runtime";
export const dynamic = "force-dynamic";
export async function GET() { return handle(async () => {
  const user = await getLearnerUser();
  if (!user) return json({ user: null, profile: null, progress: null, billing: { mode: isPilot() ? "pilot" : "live", tier: "explore", checkoutAvailable: checkoutAvailable() }, policyVersion: POLICY_VERSION });
  return json({ user, ...await accountSnapshot(user.userId), policyVersion: POLICY_VERSION, demo: user.demo ?? null });
}); }
