import { getLesson } from "@/lib/server/content";
import { getProgress, requireModuleAccess, requireProfile } from "@/lib/server/repository";
import { ApiError, database, handle, json, readJson, requireUser, textValue } from "@/lib/server/runtime";
export async function POST(request: Request) { return handle(async () => {
  const body = await readJson(request, 1000); const user = await requireUser(); const profile = await requireProfile(user.userId);
  if (!profile.orientationCompletedAt) throw new ApiError(403, "Complete your welcome orientation first.", "orientation_required");
  const lesson = getLesson(textValue(body.lessonId, "Lesson", 40)); await requireModuleAccess(user.userId, lesson.moduleId);
  await database().prepare("INSERT INTO lesson_progress (user_id, lesson_id, completed_at) VALUES (?, ?, ?) ON CONFLICT(user_id, lesson_id) DO NOTHING").bind(user.userId, lesson.id, new Date().toISOString()).run();
  return json({ completed: true, progress: { ...await getProgress(user.userId), orientationCompleted: true } });
}); }
