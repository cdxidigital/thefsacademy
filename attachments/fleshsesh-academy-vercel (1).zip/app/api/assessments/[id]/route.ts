import { assessmentBank, getAssessment, questions, sourcesFor } from "@/lib/server/content";
import { getProgress, requireAssessmentAccess } from "@/lib/server/repository";
import { gradeAssessment } from "@/lib/server/pure";
import { ApiError, database, handle, json, readJson, requireUser } from "@/lib/server/runtime";
type Context = { params: Promise<{ id: string }> };
export async function GET(_request: Request, context: Context) { return handle(async () => {
  const user = await requireUser(); const { id } = await context.params; const assessment = getAssessment(id); await requireAssessmentAccess(user.userId, assessment);
  const selected = questions.filter((question) => assessment.questionIds.includes(question.id));
  const original = assessmentBank.assessments.find((item) => item.id === id)!;
  const details = original as unknown as Record<string, unknown>;
  return json({ assessment: { ...assessment, instructions: details.instructions ?? null, case: details.case ?? null, task: details.task ?? null }, planning: id === "PLAN01" ? { case: details.case, task: details.task } : null, questions: assessment.questionIds.map((questionId) => { const question = selected.find((item) => item.id === questionId)!; return { id: question.id, prompt: question.prompt, options: question.options, critical: assessment.criticalQuestionIds.includes(question.id), sourceIds: question.sourceIds }; }), sources: sourcesFor([...new Set(selected.flatMap((question) => question.sourceIds ?? []))]) });
}); }
export async function POST(request: Request, context: Context) { return handle(async () => {
  const body = await readJson(request, 8000); const user = await requireUser(); const { id } = await context.params; const assessment = getAssessment(id); await requireAssessmentAccess(user.userId, assessment);
  if (!body.answers || typeof body.answers !== "object" || Array.isArray(body.answers)) throw new ApiError(400, "Submit an answer for each question.", "invalid_answers");
  let result;
  try { result = gradeAssessment(assessment, questions, body.answers as Record<string, number>); } catch (error) { throw new ApiError(400, error instanceof Error ? error.message : "Check your answers.", "invalid_answers"); }
  const now = new Date().toISOString(); const attemptId = crypto.randomUUID(); const db = database();
  await db.batch([
    db.prepare("INSERT INTO assessment_attempts (id,user_id,assessment_id,score,total,passed,critical_passed,created_at) VALUES (?,?,?,?,?,?,?,?)").bind(attemptId, user.userId, id, result.score, result.total, result.passed ? 1 : 0, result.criticalPassed ? 1 : 0, now),
    db.prepare(`INSERT INTO assessment_results (user_id,assessment_id,best_score,total,passed_at,last_attempt_at) VALUES (?,?,?,?,?,?) ON CONFLICT(user_id,assessment_id) DO UPDATE SET best_score=MAX(assessment_results.best_score,excluded.best_score), total=excluded.total, passed_at=COALESCE(assessment_results.passed_at,excluded.passed_at), last_attempt_at=excluded.last_attempt_at`).bind(user.userId, id, result.score, result.total, result.passed ? now : null, now),
    db.prepare("UPDATE profiles SET active_assessment_id=NULL WHERE user_id=? AND active_assessment_id=?").bind(user.userId, id),
  ]);
  return json({ ...result, attemptId, progress: { ...await getProgress(user.userId), orientationCompleted: true }, countsForCertificate: assessment.countsForCertificate });
}); }
