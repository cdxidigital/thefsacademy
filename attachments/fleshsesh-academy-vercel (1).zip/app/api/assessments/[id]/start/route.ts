import { getAssessment } from "@/lib/server/content";
import { requireAssessmentAccess } from "@/lib/server/repository";
import { handle, json, readJson, requireUser, database } from "@/lib/server/runtime";
export async function POST(request: Request, context: { params: Promise<{ id: string }> }) { return handle(async () => {
  await readJson(request, 1000); const user = await requireUser(); const { id } = await context.params; const assessment = getAssessment(id);
  await requireAssessmentAccess(user.userId, assessment);
  if (assessment.kind !== "lesson_practice") await database().prepare("UPDATE profiles SET active_assessment_id=? WHERE user_id=?").bind(id, user.userId).run();
  return json({ started: true, activeAssessmentId: assessment.kind === "lesson_practice" ? null : id });
}); }
