import { handle, json, readJson, requireUser, database } from "@/lib/server/runtime";
export async function POST(request: Request, context: { params: Promise<{ id: string }> }) { return handle(async () => {
  await readJson(request, 1000); const user = await requireUser(); const { id } = await context.params;
  await database().prepare("UPDATE profiles SET active_assessment_id=NULL WHERE user_id=? AND active_assessment_id=?").bind(user.userId, id).run();
  return json({ ended: true, message: "Assessment closed. You can return to the teaching tutor and retry when ready." });
}); }
