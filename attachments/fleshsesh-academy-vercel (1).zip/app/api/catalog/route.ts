import { publicCatalog } from "@/lib/server/content";
import { handle, isPilot, json } from "@/lib/server/runtime";
export async function GET() { return handle(async () => json({ ...publicCatalog(), mode: isPilot() ? "pilot" : "live" })); }
