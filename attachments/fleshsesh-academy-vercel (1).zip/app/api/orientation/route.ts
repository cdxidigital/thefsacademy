import { catalog } from "@/lib/server/content";
import { getProgress, requireProfile } from "@/lib/server/repository";
import { database, handle, json, readJson, requireUser } from "@/lib/server/runtime";
export async function GET() { return json({ orientation: catalog.orientation }); }
export async function POST(request: Request) { return handle(async () => {
  await readJson(request, 1000); const user = await requireUser(); await requireProfile(user.userId);
  const now = new Date().toISOString();
  await database().prepare("UPDATE profiles SET orientation_completed_at=COALESCE(orientation_completed_at, ?), updated_at=? WHERE user_id=?").bind(now, now, user.userId).run();
  return json({ completed: true, progress: { ...await getProgress(user.userId), orientationCompleted: true } });
}); }
