import { catalog } from "@/lib/server/content";
import { getEntitlements, requireProfile } from "@/lib/server/repository";
import { activeEntitlements, membership } from "@/lib/server/pure";
import { handle, isPilot, json, requireUser } from "@/lib/server/runtime";
export async function GET() { return handle(async () => {
  const user = await requireUser(); await requireProfile(user.userId); const items = await getEntitlements(user.userId);
  const toolkitAvailable = isPilot() || membership(items) !== "explore" || activeEntitlements(items).some((item) => item.key === "toolkit");
  return json({ toolkitAvailable, worksheets: toolkitAvailable ? catalog.worksheets : catalog.worksheets.map(({ id, title }) => ({ id, title, locked: true })), glossary: catalog.glossary, sources: catalog.sources });
}); }
