import { getProfile, accountSnapshot } from "@/lib/server/repository";
import { ApiError, database, handle, isDemoUserId, json, POLICY_VERSION, readJson, requireUser, textValue } from "@/lib/server/runtime";
export async function POST(request: Request) { return handle(async () => {
  const body = await readJson(request, 4000); const user = await requireUser(); const old = await getProfile(user.userId);
  const displayName = textValue(body.displayName ?? old?.displayName, "Display name", 80);
  if (/[\u0000-\u001f\u007f]/.test(displayName)) throw new ApiError(400, "Use a display name without control characters.", "invalid_input");
  const weeklyGoal = body.weeklyGoal ?? old?.weeklyGoal ?? 3;
  if (![2, 3, 5].includes(weeklyGoal as number)) throw new ApiError(400, "Choose a weekly goal of 2, 3 or 5 lessons.", "invalid_input");
  if ((!old || old.acceptedVersion !== POLICY_VERSION) && (body.adultConfirmed !== true || body.educationAcknowledged !== true)) throw new ApiError(400, "Confirm that you are 18 or older and understand this is non-accredited adult education.", "agreement_required");
  if (body.adultConfirmed === false || body.educationAcknowledged === false) throw new ApiError(400, "The Academy requires the adult learner agreement.", "agreement_required");
  if (body.externalAiConsent !== undefined && typeof body.externalAiConsent !== "boolean") throw new ApiError(400, "Choose whether you consent to external AI processing.", "invalid_input");
  const now = new Date().toISOString(); const aiConsent = isDemoUserId(user.userId) ? null : body.externalAiConsent === true ? now : body.externalAiConsent === false ? null : old?.externalAiConsentAt ?? null;
  await database().prepare(`INSERT INTO profiles (user_id, display_name, weekly_goal, accepted_version, adult_confirmed_at, education_acknowledged_at, external_ai_consent_at, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET display_name=excluded.display_name, weekly_goal=excluded.weekly_goal, accepted_version=excluded.accepted_version, external_ai_consent_at=excluded.external_ai_consent_at, updated_at=excluded.updated_at`).bind(user.userId, displayName, weeklyGoal, POLICY_VERSION, old?.adultConfirmedAt ?? now, old?.educationAcknowledgedAt ?? now, aiConsent, old?.createdAt ?? now, now).run();
  return json({ user, ...await accountSnapshot(user.userId) });
}); }
