import { catalog, rules } from "@/lib/server/content";
import { CERTIFICATE_LOGO_DATA_URI, CERTIFICATE_INTER_REGULAR_DATA_URI, CERTIFICATE_INTER_BOLD_DATA_URI } from "@/lib/server/certificate-brand";
import { getCertificate, getProgress, requireProfile } from "@/lib/server/repository";
import { certificateEligibility, safeCertificateName as escape } from "@/lib/server/pure";
import { ApiError, assertRealAccount, database, handle, isPilot, json, readJson, requireUser } from "@/lib/server/runtime";
export async function POST(request: Request) { return handle(async () => {
  await readJson(request, 1000); const user = await requireUser(); assertRealAccount(user); const profile = await requireProfile(user.userId); const progress = await getProgress(user.userId);
  const eligibility = certificateEligibility({ orientationCompleted: Boolean(profile.orientationCompletedAt), ...progress }, rules);
  if (!eligibility.eligible) return json({ error: "Finish the core lessons, module checks, capstone and applied planning assessment to receive your certificate.", code: "requirements_incomplete", ...eligibility }, 403);
  const now = new Date().toISOString(); const id = `FSA-${crypto.randomUUID()}`;
  await database().prepare("INSERT INTO certificates (user_id,id,display_name,course_version,issued_at) VALUES (?,?,?,?,?) ON CONFLICT(user_id) DO NOTHING").bind(user.userId, id, profile.displayName, `${catalog.course.version}${isPilot() ? "-pilot" : ""}`, now).run();
  return json({ certificate: await getCertificate(user.userId), downloadUrl: "/api/certificate?download=1" });
}); }
export async function GET(request: Request) { return handle(async () => {
  const user = await requireUser(); assertRealAccount(user); const profile = await requireProfile(user.userId); const certificate = await getCertificate(user.userId);
  if (!new URL(request.url).searchParams.has("download")) return json({ certificate, ...certificateEligibility({ orientationCompleted: Boolean(profile.orientationCompletedAt), ...await getProgress(user.userId) }, rules) });
  if (!certificate) throw new ApiError(404, "Your certificate has not been issued yet.", "not_found");
  const html = `<!doctype html>
<html lang="en-AU">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>fleshsesh academy · certificate of completion</title>
<style>
@font-face{font-family:Inter;src:url("${CERTIFICATE_INTER_REGULAR_DATA_URI}") format("woff");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:Inter;src:url("${CERTIFICATE_INTER_BOLD_DATA_URI}") format("woff");font-weight:700;font-style:normal;font-display:swap}
@page{size:A4 landscape;margin:10mm}
*{box-sizing:border-box}
:root{color-scheme:light;--ink:#0D1014;--paper:#F4EEE6;--berry:#9D3A5C;--blush:#E6A7BB;--brass:#C7A86D}
body{margin:0;padding:32px;background:var(--paper);color:var(--ink);font-family:Inter,Arial,sans-serif;font-size:14px;font-weight:400;line-height:1.5;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.sheet{position:relative;max-width:1080px;margin:0 auto;padding:36px 56px 30px;border:1px solid var(--ink);background:var(--paper);text-align:center}
.sheet:before{position:absolute;inset:9px;border:1px solid var(--brass);content:"";pointer-events:none}
.logo{display:block;width:244px;max-width:70%;height:auto;margin:0 auto 12px}
.eyebrow{margin:0 0 12px;color:var(--berry);font-size:10px;font-weight:700;letter-spacing:2.4px;text-transform:uppercase}
h1{margin:0 0 20px;font-size:31px;line-height:1.15;font-weight:700;letter-spacing:-.9px}
p{margin:0}
.intro{font-size:13px}
h2{max-width:900px;margin:10px auto 12px;font-size:40px;font-weight:700;line-height:1.12;letter-spacing:-1px;overflow-wrap:anywhere}
.name-rule{width:132px;height:2px;margin:0 auto 18px;background:var(--berry)}
.course-intro{font-size:13px}
.course{margin:8px 0 14px;font-size:23px;font-weight:700;line-height:1.25;letter-spacing:-.45px}
.requirements{font-size:12px;line-height:1.6}
.ornament{display:flex;align-items:center;justify-content:center;gap:9px;margin:19px 0 17px}
.ornament:before,.ornament:after{display:block;width:58px;height:1px;background:var(--brass);content:""}
.ornament span{display:block;width:6px;height:6px;border:1px solid var(--berry);background:var(--blush);transform:rotate(45deg)}
.issue-details{display:flex;justify-content:center;gap:50px;font-size:12px}
.issue-details span{display:block;margin-bottom:4px;color:var(--berry);font-size:9px;font-weight:700;letter-spacing:1.6px;text-transform:uppercase}
.statement{max-width:850px;margin:22px auto 0;font-size:10.5px;line-height:1.55}
.record{margin:12px auto 0;font-size:9px;line-height:1.5;overflow-wrap:anywhere}
.record strong{font-weight:700}
.print-note{max-width:820px;margin:18px auto 0;font-size:11px;line-height:1.6;text-align:center}
@media(max-width:640px){body{padding:12px}.sheet{padding:28px 20px}.logo{width:210px}h1{font-size:25px}h2{font-size:31px}.course{font-size:20px}.issue-details{gap:22px}.statement{font-size:11px}}
@media print{body{padding:0}.sheet{width:100%;max-width:none;padding:25px 38px 22px;break-inside:avoid}.logo{width:215px;margin-bottom:9px}.eyebrow{margin-bottom:9px}h1{font-size:28px;margin-bottom:16px}h2{font-size:35px;margin-top:9px;margin-bottom:10px}.name-rule{margin-bottom:15px}.course{font-size:21px;margin:7px 0 11px}.ornament{margin:15px 0}.statement{margin-top:18px;font-size:10px}.record{margin-top:10px}.print-note{display:none}}
</style>
</head>
<body>
<article class="sheet" aria-label="fleshsesh academy assessed certificate of completion">
  <header>
    <img class="logo" src="${CERTIFICATE_LOGO_DATA_URI}" width="244" height="74" alt="fleshsesh academy">
    <p class="eyebrow">Your learning, recognised</p>
    <h1>Assessed Certificate of Completion</h1>
  </header>
  <p class="intro">This recognises that</p>
  <h2>${escape(certificate.displayName)}</h2>
  <div class="name-rule" aria-hidden="true"></div>
  <p class="course-intro">has completed the core learning and passed the required assessments for</p>
  <p class="course">${escape(catalog.course.shortTitle)}</p>
  <p class="requirements">36 core lessons · 12 module assessments · Capstone · Applied planning</p>
  <div class="ornament" aria-hidden="true"><span></span></div>
  <div class="issue-details">
    <p><span>Issued</span>${escape(new Date(certificate.issuedAt).toLocaleDateString("en-AU", { day: "numeric", month: "long", year: "numeric", timeZone: "Australia/Perth" }))}</p>
    <p><span>Course version</span>${escape(certificate.courseVersion)}</p>
  </div>
  <p class="statement">${escape(catalog.course.credential.statement)} Completion does not certify anyone as a safe partner or qualified practitioner.${certificate.courseVersion.endsWith("-pilot") ? " Issued for the private pilot curriculum; specialist release review remains pending." : ""}</p>
  <p class="record"><strong>Certificate ID:</strong> ${escape(certificate.id)}</p>
</article>
<p class="print-note">Save this file privately. To save a PDF, open the browser Print menu and choose Save as PDF. This certificate is private and there is no public learner directory.</p>
</body>
</html>`;
  return new Response(html, { headers: { "Content-Type": "text/html; charset=utf-8", "Content-Disposition": 'attachment; filename="fleshsesh_academy_certificate.html"', "Cache-Control": "private, no-store", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; img-src data:; font-src data:; base-uri 'none'; form-action 'none'", "X-Content-Type-Options": "nosniff" } });
}); }
