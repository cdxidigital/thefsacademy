import { assessmentBank, getLesson, getModule, lessons, sourcesFor } from "@/lib/server/content";
import { requireModuleAccess, requireProfile } from "@/lib/server/repository";
import { handle, json, requireUser } from "@/lib/server/runtime";
export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) { return handle(async () => {
  const user = await requireUser(); await requireProfile(user.userId); const { id } = await context.params; const lesson = getLesson(id);
  await requireModuleAccess(user.userId, lesson.moduleId);
  const { lessons: moduleLessons, ...module } = getModule(lesson.moduleId);
  const index = lessons.findIndex((item) => item.id === id);
  const scenario = assessmentBank.scenarios.find((item) => item.id === lesson.scenarioId);
  return json({ lesson, module: { ...module, lessonIds: moduleLessons.map((item) => item.id) }, scenario: scenario ? { ...scenario, countsForCertificate: false } : null, sources: sourcesFor(lesson.sourceIds), previousLessonId: lessons[index - 1]?.id ?? null, nextLessonId: lessons[index + 1]?.id ?? null });
}); }
