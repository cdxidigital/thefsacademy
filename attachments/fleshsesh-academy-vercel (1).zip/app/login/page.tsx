import { redirect } from "next/navigation";
import { signInPath, type AuthPageProps } from "@/lib/auth/paths";

export const dynamic = "force-dynamic";
export default async function Login({ searchParams }: AuthPageProps) {
  redirect(signInPath((await searchParams).return_to));
}
