import { getModule } from "./content";
import { aiAvailable, checkoutAvailable, getBilling, getEntitlements, getProfile } from "./repository";
import { activeEntitlements, membership } from "./pure";
import { ApiError, assertRealAccount, database, settings } from "./runtime";

type StripeMetadata = Record<string, string>;
type Price = { id: string; active: boolean; currency: string; unit_amount: number; recurring?: { interval: string; interval_count: number } | null };
type Invoice = { id: string; status?: string; customer?: string | { id: string }; subscription?: string | { id: string } | null; parent?: { subscription_details?: { subscription?: string | { id: string } } } };
type Subscription = { id: string; customer: string | { id: string }; status: string; metadata: StripeMetadata; cancel_at_period_end: boolean; current_period_end?: number; latest_invoice?: string | Invoice | null; items: { data: { price: Price; current_period_end?: number }[] } };
type CheckoutSession = { id: string; mode: string; customer: string | { id: string } | null; subscription: string | Subscription | null; invoice?: string | Invoice | null; payment_status: string; payment_intent?: string | { id: string } | null; metadata: StripeMetadata; line_items?: { data: { price: Price; quantity: number }[] }; url?: string };
export type StripeEvent = { id: string; type: string; created: number; data: { object: { id: string; object?: string; subscription?: string | { id: string }; parent?: Invoice["parent"]; payment_intent?: string | { id: string }; refunded?: boolean; amount_refunded?: number; amount?: number; charge?: string | { id: string } } } };
export type ProductKey = "academy_monthly" | "academy_yearly" | "plus_monthly" | "plus_yearly" | "module" | "toolkit" | "tutor_pack";
export type Product = { key: ProductKey; priceId: string | undefined; amount: number; interval?: "month" | "year"; entitlement: string };
export function products(): Record<ProductKey, Product> {
  const e = settings();
  return {
    academy_monthly: { key: "academy_monthly", priceId: e.STRIPE_PRICE_ACADEMY_MONTHLY, amount: 1900, interval: "month", entitlement: "academy" },
    academy_yearly: { key: "academy_yearly", priceId: e.STRIPE_PRICE_ACADEMY_YEARLY, amount: 19000, interval: "year", entitlement: "academy" },
    plus_monthly: { key: "plus_monthly", priceId: e.STRIPE_PRICE_PLUS_MONTHLY, amount: 2900, interval: "month", entitlement: "plus" },
    plus_yearly: { key: "plus_yearly", priceId: e.STRIPE_PRICE_PLUS_YEARLY, amount: 29000, interval: "year", entitlement: "plus" },
    module: { key: "module", priceId: e.STRIPE_PRICE_MODULE, amount: 700, entitlement: "module" },
    toolkit: { key: "toolkit", priceId: e.STRIPE_PRICE_TOOLKIT, amount: 500, entitlement: "toolkit" },
    tutor_pack: { key: "tutor_pack", priceId: e.STRIPE_PRICE_TUTOR_PACK, amount: 500, entitlement: "tutor-pack" },
  };
}
export function productFor(value: unknown) {
  if (typeof value !== "string" || !Object.hasOwn(products(), value)) throw new ApiError(400, "Choose one of the available plans or learning purchases.", "invalid_product");
  return products()[value as ProductKey];
}
export function requireBillingConfiguration() {
  if (!checkoutAvailable()) throw new ApiError(503, "Payments are not enabled during the private pilot. No charge has been made. You can explore the learning content now.", "billing_not_configured");
}
export function appOrigin() {
  const raw = settings().APP_ORIGIN;
  if (!raw) throw new ApiError(503, "The payment return address is not configured.", "billing_not_configured");
  const url = new URL(raw);
  if (url.protocol !== "https:" || url.pathname !== "/" || url.username || url.password || url.search || url.hash) throw new ApiError(503, "The payment return address requires configuration.", "billing_not_configured");
  return url.origin;
}
export async function stripeRequest<T>(path: string, method = "GET", data?: URLSearchParams, idempotencyKey?: string): Promise<T> {
  const secret = settings().STRIPE_SECRET_KEY;
  if (!secret) throw new ApiError(503, "The payment provider is not configured.", "billing_not_configured");
  if (!path.startsWith("/") || path.includes("://")) throw new Error("Invalid provider path");
  const headers: Record<string, string> = { Authorization: `Bearer ${secret}` };
  if (data) headers["Content-Type"] = "application/x-www-form-urlencoded";
  if (idempotencyKey) headers["Idempotency-Key"] = idempotencyKey;
  const response = await fetch(`https://api.stripe.com/v1${path}`, { method, headers, body: data, signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new ApiError(503, "The payment provider could not complete this request. Please try again shortly.", "payment_provider_unavailable");
  return response.json() as Promise<T>;
}
export function objectId(value: string | { id: string } | null | undefined) { return typeof value === "string" ? value : value?.id ?? null; }
function validatePrice(price: Price, product: Product) {
  return price.id === product.priceId && price.currency === "aud" && price.unit_amount === product.amount && (product.interval ? price.recurring?.interval === product.interval && price.recurring.interval_count === 1 : !price.recurring);
}
export async function createCheckout(user: { userId: string; email: string }, productValue: unknown, moduleValue: unknown, renewalConsent?: unknown) {
  assertRealAccount(user);
  requireBillingConfiguration(); const product = productFor(productValue);
  if (product.interval && renewalConsent !== true) throw new ApiError(400, "Confirm the recurring price and billing period before continuing to checkout.", "renewal_consent_required");
  if (product.key === "tutor_pack" && !aiAvailable()) throw new ApiError(503, "AI question packs are unavailable until the AI tutor is enabled. No charge has been made.", "ai_not_configured");
  if (!product.priceId || !/^price_[A-Za-z0-9]+$/.test(product.priceId)) throw new ApiError(503, "This purchase is not configured yet. No charge has been made.", "product_not_configured");
  const moduleId = product.key === "module" ? getModule(typeof moduleValue === "string" ? moduleValue : "").id : "";
  if (moduleId === "C01") throw new ApiError(400, "Consent and autonomy is already free.", "already_available");
  const owned = activeEntitlements(await getEntitlements(user.userId));
  if (product.key === "module" && (membership(owned) !== "explore" || owned.some((item) => item.key === `module:${moduleId}`))) throw new ApiError(409, "This module is already included in your access. You do not need to purchase it again.", "already_available");
  if (product.key === "toolkit" && (membership(owned) !== "explore" || owned.some((item) => item.key === "toolkit"))) throw new ApiError(409, "The toolkit is already included in your access.", "already_available");
  const price = await stripeRequest<Price>(`/prices/${product.priceId}`);
  if (!price.active || !validatePrice(price, product)) throw new ApiError(503, "The payment price needs review before this purchase can be made.", "price_mismatch");
  let billing = await getBilling(user.userId); let customerId = billing?.customerId;
  if (!customerId) {
    const customer = await stripeRequest<{ id: string }>("/customers", "POST", new URLSearchParams({ email: user.email, "metadata[academy_user_id]": user.userId }), `academy-customer-${user.userId}`);
    customerId = customer.id;
    await database().prepare("INSERT INTO billing_customers (user_id,customer_id,updated_at) VALUES (?,?,?) ON CONFLICT(user_id) DO NOTHING").bind(user.userId, customerId, new Date().toISOString()).run();
    billing = await getBilling(user.userId); customerId = billing!.customerId;
  }
  if (product.interval) {
    const subscriptions = await stripeRequest<{ data: Subscription[] }>(`/subscriptions?customer=${encodeURIComponent(customerId)}&status=all&limit=100`);
    if (subscriptions.data.some((subscription) => !["canceled", "incomplete_expired"].includes(subscription.status))) throw new ApiError(409, "You already have a subscription or a pending subscription. Manage it in your account to change plans.", "subscription_exists");
  }
  const origin = appOrigin();
  const params = new URLSearchParams({ mode: product.interval ? "subscription" : "payment", customer: customerId, client_reference_id: user.userId, "line_items[0][price]": product.priceId, "line_items[0][quantity]": "1", success_url: `${origin}/account?checkout=returned`, cancel_url: `${origin}/pricing?checkout=cancelled`, "metadata[academy_user_id]": user.userId, "metadata[product]": product.key, "metadata[module_id]": moduleId, "payment_method_types[0]": "card" });
  const prefix = product.interval ? "subscription_data" : "payment_intent_data";
  params.set(`${prefix}[metadata][academy_user_id]`, user.userId); params.set(`${prefix}[metadata][product]`, product.key); params.set(`${prefix}[metadata][module_id]`, moduleId);
  const session = await stripeRequest<CheckoutSession>("/checkout/sessions", "POST", params, `academy-checkout-${user.userId}-${product.key}-${moduleId}-${Math.floor(Date.now() / 1800000)}`);
  if (!session.url || !session.url.startsWith("https://checkout.stripe.com/")) throw new ApiError(503, "The secure checkout could not be opened.", "payment_provider_unavailable");
  return { url: session.url };
}

/** All mutations in one D1 transaction; a duplicate event rolls back every mutation. */
async function commitEvent(event: StripeEvent, statements: D1PreparedStatement[]) {
  const db = database();
  try {
    await db.batch([db.prepare("INSERT INTO payment_events (id,type,created_at) VALUES (?,?,?)").bind(event.id, event.type, new Date().toISOString()), ...statements]);
  } catch (error) {
    if (await db.prepare("SELECT id FROM payment_events WHERE id=?").bind(event.id).first()) return;
    throw error;
  }
}
async function subscriptionStatements(subscriptionId: string, current?: Subscription) {
  const subscription = current ?? await stripeRequest<Subscription>(`/subscriptions/${encodeURIComponent(subscriptionId)}?expand[]=latest_invoice&expand[]=items.data.price`);
  const userId = subscription.metadata?.academy_user_id; const customerId = objectId(subscription.customer);
  if (!userId || !customerId || !await getProfile(userId)) return [];
  const billing = await getBilling(userId);
  if (!billing || billing.customerId !== customerId) return [];
  const item = subscription.items.data[0];
  const product = Object.values(products()).find((candidate) => candidate.interval && item?.price && validatePrice(item.price, candidate));
  const invoice = typeof subscription.latest_invoice === "object" ? subscription.latest_invoice : null;
  const periodEnd = item?.current_period_end ?? subscription.current_period_end;
  const active = subscription.status === "active" && invoice?.status === "paid" && Boolean(periodEnd && periodEnd * 1000 > Date.now()) && Boolean(product);
  const expiresAt = periodEnd ? new Date(periodEnd * 1000).toISOString() : null; const now = new Date().toISOString(); const db = database();
  const statements = [
    db.prepare("UPDATE billing_customers SET subscription_id=?, subscription_status=?, cancel_at_period_end=?, period_end=?, updated_at=? WHERE user_id=? AND customer_id=?").bind(subscription.id, subscription.status, subscription.cancel_at_period_end ? 1 : 0, expiresAt, now, userId, customerId),
    db.prepare("UPDATE entitlements SET active=0, updated_at=? WHERE user_id=? AND key IN ('academy','plus') AND source_id=?").bind(now, userId, subscription.id),
  ];
  // Evaluate invoice holds inside the transaction, including a hold added by this event.
  // An unrelated later paid invoice can grant a new period; replaying this invoice cannot.
  if (product) statements.push(db.prepare("INSERT INTO entitlements (user_id,key,source_id,expires_at,active,updated_at) VALUES (?,?,?,?,CASE WHEN ?=1 AND NOT EXISTS(SELECT 1 FROM entitlements WHERE user_id=? AND key=? AND active=1) THEN 1 ELSE 0 END,?) ON CONFLICT(user_id,key,source_id) DO UPDATE SET expires_at=excluded.expires_at, active=excluded.active, updated_at=excluded.updated_at").bind(userId, product.entitlement, subscription.id, expiresAt, active ? 1 : 0, userId, `invoice-hold:${invoice?.id ?? ""}`, now));
  return statements;
}
async function invoiceHoldStatements(invoiceId: string, reason: "refund" | "dispute", referenceId: string, release = false) {
  const invoice = await stripeRequest<Invoice>(`/invoices/${encodeURIComponent(invoiceId)}`);
  const subscriptionId = objectId(invoice.subscription ?? invoice.parent?.subscription_details?.subscription);
  if (!subscriptionId) return [];
  const subscription = await stripeRequest<Subscription>(`/subscriptions/${encodeURIComponent(subscriptionId)}?expand[]=latest_invoice&expand[]=items.data.price`);
  const userId = subscription.metadata?.academy_user_id; const customerId = objectId(subscription.customer);
  if (!userId || !customerId || !await getProfile(userId)) return [];
  const billing = await getBilling(userId);
  if (!billing || billing.customerId !== customerId || (invoice.customer && objectId(invoice.customer) !== customerId)) return [];
  const now = new Date().toISOString(); const db = database();
  const hold = db.prepare("INSERT INTO entitlements (user_id,key,source_id,expires_at,active,updated_at) VALUES (?,?,?,NULL,?,?) ON CONFLICT(user_id,key,source_id) DO UPDATE SET active=excluded.active,updated_at=excluded.updated_at").bind(userId, `invoice-hold:${invoiceId}`, `${subscriptionId}:${reason}:${referenceId}`, release ? 0 : 1, now);
  return [hold, ...await subscriptionStatements(subscriptionId, subscription)];
}
async function sessionStatements(sessionId: string, revoke = false) {
  const session = await stripeRequest<CheckoutSession>(`/checkout/sessions/${encodeURIComponent(sessionId)}?expand[]=line_items`);
  if (session.mode === "subscription") {
    if (revoke) {
      const invoiceId = objectId(session.invoice);
      if (!invoiceId) throw new ApiError(503, "The subscription reversal could not be linked to its invoice.", "invoice_link_missing");
      return invoiceHoldStatements(invoiceId, "refund", session.id);
    }
    const subscriptionId = objectId(session.subscription); return subscriptionId ? subscriptionStatements(subscriptionId) : [];
  }
  const userId = session.metadata?.academy_user_id; const productName = session.metadata?.product; const customerId = objectId(session.customer);
  if (!userId || !customerId || !productName || !Object.hasOwn(products(), productName) || !await getProfile(userId)) return [];
  const billing = await getBilling(userId); if (!billing || billing.customerId !== customerId) return [];
  const product = productFor(productName); const line = session.line_items?.data[0];
  if (product.interval || !line || session.line_items?.data.length !== 1 || line.quantity !== 1 || !validatePrice(line.price, product) || (!revoke && session.payment_status !== "paid")) return [];
  let entitlement = product.entitlement;
  if (product.key === "module") {
    const moduleId = session.metadata.module_id;
    try { getModule(moduleId); } catch { return []; }
    entitlement = `module:${moduleId}`;
  }
  const db = database(); const now = new Date().toISOString(); const statements: D1PreparedStatement[] = [];
  if (revoke) {
    if (product.key === "tutor_pack") statements.push(db.prepare("UPDATE profiles SET tutor_credits=MAX(0,tutor_credits-50), updated_at=? WHERE user_id=? AND EXISTS(SELECT 1 FROM entitlements WHERE user_id=? AND source_id=? AND key='tutor-pack' AND active=1)").bind(now, userId, userId, session.id));
    statements.push(db.prepare("UPDATE entitlements SET active=0, updated_at=? WHERE user_id=? AND key=? AND source_id=?").bind(now, userId, entitlement, session.id));
  } else {
    if (product.key === "tutor_pack") statements.push(db.prepare("UPDATE profiles SET tutor_credits=tutor_credits+50, updated_at=? WHERE user_id=? AND NOT EXISTS(SELECT 1 FROM entitlements WHERE user_id=? AND source_id=? AND key='tutor-pack')").bind(now, userId, userId, session.id));
    statements.push(db.prepare("INSERT INTO entitlements (user_id,key,source_id,expires_at,active,updated_at) VALUES (?,?,?,NULL,1,?) ON CONFLICT(user_id,key,source_id) DO NOTHING").bind(userId, entitlement, session.id, now));
  }
  return statements;
}
async function paymentReversalStatements(intent: string, reason: "refund" | "dispute", referenceId: string, release = false) {
  const statements: D1PreparedStatement[] = []; const invoiceIds = new Set<string>();
  const sessions = await stripeRequest<{ data: CheckoutSession[] }>(`/checkout/sessions?payment_intent=${encodeURIComponent(intent)}&limit=100`);
  for (const session of sessions.data) {
    if (session.mode === "subscription") { const id = objectId(session.invoice); if (id) invoiceIds.add(id); }
    else if (!release) statements.push(...await sessionStatements(session.id, true));
  }
  // Renewal payments generally have no Checkout Session; resolve their invoice directly.
  const params = new URLSearchParams({ "payment[type]": "payment_intent", "payment[payment_intent]": intent, limit: "100" });
  const payments = await stripeRequest<{ data: { invoice: string | Invoice }[]; has_more?: boolean }>(`/invoice_payments?${params}`);
  if (payments.has_more) throw new ApiError(503, "This payment needs invoice reconciliation before its event can finish.", "invoice_reconciliation_required");
  for (const payment of payments.data) { const id = objectId(payment.invoice); if (id) invoiceIds.add(id); }
  for (const invoiceId of invoiceIds) statements.push(...await invoiceHoldStatements(invoiceId, reason, referenceId, release));
  return statements;
}
export async function processStripeEvent(event: StripeEvent) {
  const db = database(); if (await db.prepare("SELECT id FROM payment_events WHERE id=?").bind(event.id).first()) return { received: true, duplicate: true };
  let statements: D1PreparedStatement[] = []; const object = event.data.object;
  if (["checkout.session.completed", "checkout.session.async_payment_succeeded"].includes(event.type)) statements = await sessionStatements(object.id);
  else if (["customer.subscription.created", "customer.subscription.updated", "customer.subscription.deleted"].includes(event.type)) statements = await subscriptionStatements(object.id);
  else if (["invoice.paid", "invoice.payment_failed", "invoice.payment_action_required"].includes(event.type)) {
    const id = objectId(object.subscription ?? object.parent?.subscription_details?.subscription);
    if (id) statements = await subscriptionStatements(id);
  } else if (event.type === "charge.refunded" && object.refunded) {
    const intent = objectId(object.payment_intent);
    if (intent) statements = await paymentReversalStatements(intent, "refund", object.id);
  } else if (["charge.dispute.created", "charge.dispute.closed"].includes(event.type)) {
    const dispute = await stripeRequest<{ id: string; charge: string | { id: string }; status: string }>(`/disputes/${encodeURIComponent(object.id)}`);
    const chargeId = objectId(dispute.charge);
    if (chargeId) {
      const charge = await stripeRequest<{ payment_intent?: string }>(`/charges/${encodeURIComponent(chargeId)}`);
      if (charge.payment_intent) statements = await paymentReversalStatements(charge.payment_intent, "dispute", dispute.id, dispute.status === "won");
    }
  }
  await commitEvent(event, statements); return { received: true };
}
import type { AcademyPreparedStatement as D1PreparedStatement } from './database';
