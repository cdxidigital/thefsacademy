import { getChatGPTUser } from "@/app/chatgpt-auth";
import { modules, getAssessment } from "./content";
import { getProfile } from "./repository";
import { ApiError, database, DEMO_COOKIE, demoDetails, demoToken, findDemoSession, hashDemoToken, json, POLICY_VERSION, type DemoSession } from "./runtime";

const SESSION_HOURS = 2;
// The marker deliberately outlives its authority. After expiration, old tabs fail
// closed instead of accidentally writing their next demo action to a real learner.
const COOKIE_SECONDS = 7 * 24 * 60 * 60;
export function demoCookieHeader(token: string | null) {
  return `${DEMO_COOKIE}=${token ?? ""}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${token ? COOKIE_SECONDS : 0}`;
}
export async function demoStatus() {
  const owner = await getChatGPTUser();
  const token = await demoToken();
  const session = owner ? await findDemoSession(owner.userId, token) : null;
  const active = Boolean(session && session.expiresAt > new Date().toISOString());
  return { authenticated: Boolean(owner), active, expired: token !== null && !active, expiresAt: session?.expiresAt ?? null, tier: "plus", signInUrl: "/sign-in?return_to=%2Fdemo" };
}
async function createDemo(ownerUserId: string) {
  const db = database();
  const now = new Date().toISOString();
  const expiresAt = new Date(Date.now() + SESSION_HOURS * 60 * 60 * 1000).toISOString();
  const token = Array.from(crypto.getRandomValues(new Uint8Array(32)), (value) => value.toString(16).padStart(2, "0")).join("");
  const tokenHash = await hashDemoToken(token);
  const demoUserId = `demo:${crypto.randomUUID()}`;
  const assessment = getAssessment("C01-TEST");
  const sampleLessons = modules.filter((module) => ["C01", "C02"].includes(module.id)).flatMap((module) => module.lessons);
  await db.batch([
    // One demonstration per native visitor account bounds storage. Cascades also
    // remove expired sample progress, assessments, entitlements and guide usage.
    db.prepare("DELETE FROM profiles WHERE user_id IN (SELECT demo_user_id FROM demo_sessions WHERE expires_at<=? OR owner_user_id=?)").bind(now, ownerUserId),
    db.prepare("INSERT INTO profiles (user_id,display_name,weekly_goal,accepted_version,adult_confirmed_at,education_acknowledged_at,orientation_completed_at,created_at,updated_at) VALUES (?,?,3,?,?,?,?,?,?)").bind(demoUserId, "Alex · demo learner", POLICY_VERSION, now, now, now, now, now),
    db.prepare("INSERT INTO demo_sessions (token_hash,owner_user_id,demo_user_id,created_at,expires_at) VALUES (?,?,?,?,?)").bind(tokenHash, ownerUserId, demoUserId, now, expiresAt),
    db.prepare("INSERT INTO entitlements (user_id,key,source_id,expires_at,active,updated_at) VALUES (?,'plus','isolated-demo',?,1,?)").bind(demoUserId, expiresAt, now),
    ...sampleLessons.map((lesson) => db.prepare("INSERT INTO lesson_progress (user_id,lesson_id,completed_at) VALUES (?,?,?)").bind(demoUserId, lesson.id, now)),
    db.prepare("INSERT INTO assessment_results (user_id,assessment_id,best_score,total,passed_at,last_attempt_at) VALUES (?,?,?,?,?,?)").bind(demoUserId, assessment.id, assessment.questionIds.length, assessment.questionIds.length, now, now),
  ]);
  const session: DemoSession = { tokenHash, ownerUserId, demoUserId, createdAt: now, expiresAt };
  const response = json({ started: true, demo: demoDetails(session), redirectTo: "/dashboard" });
  response.headers.set("Set-Cookie", demoCookieHeader(token));
  return response;
}
export async function manageDemo(body: Record<string, unknown>) {
  const owner = await getChatGPTUser();
  const token = await demoToken();
  const session = owner ? await findDemoSession(owner.userId, token) : null;
  if (body.action === "exit") {
    if (session) await database().prepare("DELETE FROM profiles WHERE user_id=?").bind(session.demoUserId).run();
    const response = json({ exited: true, redirectTo: owner ? "/demo" : "/" });
    response.headers.set("Set-Cookie", demoCookieHeader(null));
    return response;
  }
  if (!["start", "reset"].includes(String(body.action))) throw new ApiError(400, "Choose start, reset or exit for the demonstration.", "invalid_demo_action");
  if (!owner) throw new ApiError(401, "Sign in to your Academy account to open your private demonstration.", "authentication_required");
  if (body.action === "start" && session && session.expiresAt > new Date().toISOString()) return json({ started: true, demo: demoDetails(session), redirectTo: "/dashboard" });
  const previous = session ? await getProfile(session.demoUserId) : null;
  if ((!previous || previous.acceptedVersion !== POLICY_VERSION) && (body.adultConfirmed !== true || body.educationAcknowledged !== true)) throw new ApiError(400, "Confirm that you are 18 or older and understand this is a demonstration of non-accredited adult education.", "agreement_required");
  return createDemo(owner.userId);
}
