import catalogData from "@/data/catalog.json";
import assessmentData from "@/data/assessments.json";
import { ApiError } from "./runtime";
import type { Assessment, Question } from "./pure";

export const catalog = catalogData;
export const assessmentBank = assessmentData;
export const modules = catalog.modules;
export const lessons = modules.flatMap((module) => module.lessons);
export const assessments = assessmentBank.assessments as Assessment[];
export const questions = assessmentBank.questions as Question[];
export const rules = assessmentBank.rules;
export function getLesson(id: string) {
  const lesson = lessons.find((item) => item.id === id);
  if (!lesson) throw new ApiError(404, "This lesson could not be found.", "not_found");
  return lesson;
}
export function getModule(id: string) {
  const module = modules.find((item) => item.id === id);
  if (!module) throw new ApiError(404, "This module could not be found.", "not_found");
  return module;
}
export function getAssessment(id: string) {
  const assessment = assessments.find((item) => item.id === id);
  if (!assessment) throw new ApiError(404, "This assessment could not be found.", "not_found");
  return assessment;
}
export function sourcesFor(ids: string[]) { return catalog.sources.filter((source) => ids.includes(source.id)); }
export function publicCatalog() {
  return {
    course: catalog.course,
    modules: modules.map(({ lessons: moduleLessons, ...module }) => ({ ...module, lessons: moduleLessons.map(({ id, title, moduleId, durationMinutes, objectives, order, topicNote, assessmentId, moduleAssessmentId, sourceIds, formatStatus }) => ({ id, title, moduleId, durationMinutes, objectives, order, topicNote, assessmentId, moduleAssessmentId, sourceIds, formatStatus })) })),
    assessments: assessments.filter((item) => item.kind !== "lesson_practice").map(({ id, title, kind, moduleId, questionIds, passingScore, criticalQuestionIds, countsForCertificate }) => ({ id, title, kind, moduleId, questionCount: questionIds.length, passingScore, criticalCount: criticalQuestionIds.length, countsForCertificate })),
    orientation: { id: catalog.orientation.id, title: catalog.orientation.title, durationMinutes: catalog.orientation.durationMinutes },
    glossary: catalog.glossary,
    sources: catalog.sources,
    worksheets: catalog.worksheets.map((worksheet) => ({ id: worksheet.id, title: worksheet.title })),
  };
}
