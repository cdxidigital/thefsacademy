import type { Client, InValue, ResultSet } from '@libsql/client';
import { createConfiguredClient, databaseConfiguration } from './database-config.mjs';

export type DatabaseRow = Record<string, unknown>;
export type DatabaseResult<T = DatabaseRow> = {
  success: true;
  results: T[];
  meta: { changes: number };
};
export interface AcademyPreparedStatement {
  bind(...values: unknown[]): AcademyPreparedStatement;
  first<T = DatabaseRow>(column?: string): Promise<T | null>;
  all<T = DatabaseRow>(): Promise<DatabaseResult<T>>;
  run<T = DatabaseRow>(): Promise<DatabaseResult<T>>;
}
export interface AcademyDatabase {
  prepare(sql: string): AcademyPreparedStatement;
  batch<T = DatabaseRow>(statements: AcademyPreparedStatement[]): Promise<DatabaseResult<T>[]>;
}

function parameter(value: unknown): InValue {
  if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
  if (value === null || typeof value === 'string' || typeof value === 'bigint' || (typeof value === 'number' && Number.isFinite(value)) || value instanceof ArrayBuffer) return value;
  throw new TypeError('Database parameters must be null, finite numbers, strings, integers, or binary data.');
}
function result<T>(value: ResultSet): DatabaseResult<T> {
  // libSQL rows also expose numeric properties; API responses keep D1's named
  // column objects and number-valued counters rather than leaking driver rows.
  const rows = value.rows.map((row) => Object.fromEntries(value.columns.map((column) => [column, row[column]])) as T);
  return { success: true, results: rows, meta: { changes: value.rowsAffected } };
}

class PreparedStatement implements AcademyPreparedStatement {
  constructor(readonly owner: LibsqlDatabase, readonly sql: string, readonly args: InValue[] = []) {}
  bind(...values: unknown[]) { return new PreparedStatement(this.owner, this.sql, values.map(parameter)); }
  async first<T = DatabaseRow>(column?: string): Promise<T | null> {
    const query = await this.owner.client.execute({ sql: this.sql, args: this.args });
    const row = result<DatabaseRow>(query).results[0];
    if (!row) return null;
    if (column === undefined) return row as T;
    if (!query.columns.includes(column)) throw new Error('The requested database column does not exist.');
    return row[column] as T;
  }
  async all<T = DatabaseRow>() { return result<T>(await this.owner.client.execute({ sql: this.sql, args: this.args })); }
  async run<T = DatabaseRow>() { return this.all<T>(); }
}

export class LibsqlDatabase implements AcademyDatabase {
  constructor(readonly client: Client) {}
  prepare(sql: string) { return new PreparedStatement(this, sql); }
  async batch<T = DatabaseRow>(statements: AcademyPreparedStatement[]): Promise<DatabaseResult<T>[]> {
    if (!statements.length) return [];
    const queries = statements.map((statement) => {
      if (!(statement instanceof PreparedStatement) || statement.owner !== this) throw new TypeError('A transaction can only contain statements from this database.');
      return { sql: statement.sql, args: statement.args };
    });
    // A write batch is one server-side transaction: sequential success commits;
    // any failed statement rolls back the event marker and all related writes.
    return (await this.client.batch(queries, 'write')).map((value) => result<T>(value));
  }
}

let cached: { key: string; database: LibsqlDatabase } | null = null;
export function configuredDatabase(environment: NodeJS.ProcessEnv = process.env): AcademyDatabase | null {
  const configuration = databaseConfiguration(environment);
  if (!configuration) return null;
  const key = JSON.stringify(configuration);
  if (!cached || cached.key !== key) {
    cached?.database.client.close();
    cached = { key, database: new LibsqlDatabase(createConfiguredClient(configuration)) };
  }
  return cached.database;
}
export function configuredClient(environment: NodeJS.ProcessEnv = process.env): Client | null {
  const database = configuredDatabase(environment);
  return database instanceof LibsqlDatabase ? database.client : null;
}
