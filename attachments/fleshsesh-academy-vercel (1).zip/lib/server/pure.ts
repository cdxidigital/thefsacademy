/** Pure policy functions; no credentials, runtime bindings, or client-provided scores. */
export type Question = { id: string; prompt: string; options: string[]; correctIndex: number; feedback: string; sourceIds?: string[]; critical?: boolean };
export type Assessment = { id: string; kind: string; title: string; moduleId?: string | null; lessonId?: string | null; questionIds: string[]; passingScore: number; criticalQuestionIds: string[]; countsForCertificate: boolean; requiredModuleAssessmentIds?: string[] };
export type Entitlement = { key: string; active: boolean | number; expiresAt: string | null };
export function gradeAssessment(assessment: Assessment, questions: Question[], answers: Record<string, number>) {
  if (Object.keys(answers).length !== assessment.questionIds.length || Object.keys(answers).some((id) => !assessment.questionIds.includes(id))) throw new Error("Answer each question in this assessment exactly once.");
  const feedback = assessment.questionIds.map((id) => {
    const question = questions.find((item) => item.id === id);
    if (!question) throw new Error("Assessment configuration is incomplete.");
    const answer = answers[id];
    if (!Number.isInteger(answer) || answer < 0 || answer >= question.options.length) throw new Error("Choose a valid answer to every question.");
    return { questionId: id, correct: answer === question.correctIndex, selectedIndex: answer, correctIndex: question.correctIndex, feedback: question.feedback, sourceIds: question.sourceIds ?? [] };
  });
  const score = feedback.filter((item) => item.correct).length;
  const criticalPassed = assessment.criticalQuestionIds.every((id) => feedback.some((item) => item.questionId === id && item.correct));
  return { assessmentId: assessment.id, score, total: feedback.length, passingScore: assessment.passingScore, criticalPassed, passed: score >= assessment.passingScore && criticalPassed, feedback };
}
export function activeEntitlements(items: Entitlement[], now = new Date()) {
  return items.filter((item) => Boolean(item.active) && (!item.expiresAt || new Date(item.expiresAt).getTime() > now.getTime()));
}
export function membership(items: Entitlement[], now = new Date()): "explore" | "academy" | "plus" {
  const active = activeEntitlements(items, now);
  return active.some((item) => item.key === "plus") ? "plus" : active.some((item) => item.key === "academy") ? "academy" : "explore";
}
export function canAccessModule(moduleId: string, items: Entitlement[], pilot: boolean, now = new Date()) {
  if (pilot || moduleId === "C01") return true;
  return activeEntitlements(items, now).some((item) => ["academy", "plus", `module:${moduleId}`].includes(item.key));
}
export function certificateEligibility(input: { orientationCompleted: boolean; completedLessonIds: string[]; passedAssessmentIds: string[] }, rules: { coreLessonIds: string[]; coreAssessmentIds: string[]; capstoneAssessmentId: string; planningAssessmentId: string }) {
  const missingLessonIds = rules.coreLessonIds.filter((id) => !input.completedLessonIds.includes(id));
  const missingAssessmentIds = [...rules.coreAssessmentIds, rules.capstoneAssessmentId, rules.planningAssessmentId].filter((id) => !input.passedAssessmentIds.includes(id));
  return { eligible: input.orientationCompleted && !missingLessonIds.length && !missingAssessmentIds.length, orientationCompleted: input.orientationCompleted, missingLessonIds, missingAssessmentIds };
}
export function calculateXp(completedLessonIds: string[], passedAssessmentIds: string[]) {
  return new Set(completedLessonIds).size * 25 + [...new Set(passedAssessmentIds)].filter((id) => /^[CE]\d{2}-TEST$/.test(id)).length * 100 + (passedAssessmentIds.includes("CAP01") ? 150 : 0);
}
export function sameOrigin(requestUrl: string, origin: string | null) {
  if (!origin || origin === "null") return false;
  try { return new URL(origin).origin === new URL(requestUrl).origin; } catch { return false; }
}
export function safeCertificateName(name: string) {
  return name.replace(/[<>&"']/g, (character) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&#39;" })[character]!);
}
export async function verifyStripeSignature(payload: string, header: string | null, secret: string, nowSeconds = Math.floor(Date.now() / 1000)) {
  if (!header || !secret) return false;
  const parts = header.split(","); const stamp = parts.find((part) => part.startsWith("t="))?.slice(2);
  if (!stamp || !/^\d+$/.test(stamp) || Math.abs(nowSeconds - Number(stamp)) > 300) return false;
  const signatures = parts.filter((part) => part.startsWith("v1=")).map((part) => part.slice(3)).filter((signature) => /^[0-9a-f]{64}$/.test(signature));
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  for (const signature of signatures) {
    const bytes = Uint8Array.from(signature.match(/../g)!, (pair) => Number.parseInt(pair, 16));
    if (await crypto.subtle.verify("HMAC", key, bytes, new TextEncoder().encode(`${stamp}.${payload}`))) return true;
  }
  return false;
}
