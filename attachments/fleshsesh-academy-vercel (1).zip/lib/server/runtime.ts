import { configuredDatabase, type AcademyDatabase } from "./database";
import { DatabaseConfigurationError } from "./database-config.mjs";
import { getChatGPTUser, type ChatGPTUser } from "@/app/chatgpt-auth";
import { headers } from "next/headers";
import { sameOrigin } from "./pure";
export const POLICY_VERSION = "2026-10-17-v1";
export function settings() { return process.env; }
export function isPilot() { return settings().APP_MODE !== "live"; }
export function database(): AcademyDatabase {
  try {
    const db = configuredDatabase();
    if (db) return db;
  } catch (error) {
    if (!(error instanceof DatabaseConfigurationError)) throw error;
  }
  throw new ApiError(503, "Learning records are temporarily unavailable. Please try again shortly.", "storage_unavailable");
}
export class ApiError extends Error {
  constructor(public status: number, message: string, public code = "request_failed") { super(message); }
}
export function json(value: unknown, status = 200) {
  return Response.json(value, { status, headers: { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
}
export async function handle(action: () => Promise<Response>): Promise<Response> {
  try { return await action(); } catch (error) {
    if (error instanceof ApiError) return json({ error: error.message, code: error.code }, error.status);
    console.error("Academy API operation failed", error instanceof Error ? error.name : "UnknownError");
    return json({ error: "This request could not be completed. Please try again.", code: "internal_error" }, 500);
  }
}
export const DEMO_COOKIE = "__Host-fsa-demo";
export type DemoSession = { tokenHash: string; ownerUserId: string; demoUserId: string; createdAt: string; expiresAt: string };
export type LearnerUser = ChatGPTUser & { demo?: { active: true; expiresAt: string; source: "isolated-demo"; tier: "plus" } };
export function isDemoUserId(userId: string) { return userId.startsWith("demo:"); }
export function assertRealAccount(user: { userId: string }) {
  if (isDemoUserId(user.userId)) throw new ApiError(403, "This action is unavailable in the demo. Exit the demo to manage your own account.", "demo_action_unavailable");
}
export async function demoToken() {
  const cookie = (await headers()).get("cookie") ?? "";
  const value = cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${DEMO_COOKIE}=`))?.slice(DEMO_COOKIE.length + 1);
  return value === undefined ? null : value;
}
export async function hashDemoToken(token: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token));
  return Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2, "0")).join("");
}
export async function findDemoSession(ownerUserId: string, token: string | null) {
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  return database().prepare("SELECT token_hash AS tokenHash, owner_user_id AS ownerUserId, demo_user_id AS demoUserId, created_at AS createdAt, expires_at AS expiresAt FROM demo_sessions WHERE token_hash=? AND owner_user_id=?").bind(await hashDemoToken(token), ownerUserId).first<DemoSession>();
}
export function demoDetails(session: DemoSession) {
  return { active: true as const, expiresAt: session.expiresAt, source: "isolated-demo" as const, tier: "plus" as const };
}
export async function getLearnerUser(): Promise<LearnerUser | null> {
  const user = await getChatGPTUser();
  if (!user) return null;
  const token = await demoToken();
  if (token === null) return user;
  const session = await findDemoSession(user.userId, token);
  // Never silently fall back to a real learner when a stale demonstration is open.
  if (!session || session.expiresAt <= new Date().toISOString()) throw new ApiError(409, "Your demo session has ended. Restart or exit the demo to continue.", "demo_expired");
  return { userId: session.demoUserId, displayName: "Alex · demo learner", email: "", fullName: null, demo: demoDetails(session) };
}
export async function requireUser() {
  const user = await getLearnerUser();
  if (!user) throw new ApiError(401, "Sign in to continue.", "authentication_required");
  const expectedLearner = (await headers()).get("x-academy-learner");
  if (expectedLearner && expectedLearner !== user.userId) throw new ApiError(409, "Your learner session changed in another tab. Refresh this page before continuing.", "learner_session_changed");
  return user;
}
export function assertMutation(request: Request) {
  if (!sameOrigin(request.url, request.headers.get("origin"))) throw new ApiError(403, "This action must be submitted from the Academy.", "invalid_origin");
  if (request.headers.get("sec-fetch-site") === "cross-site") throw new ApiError(403, "Cross-site actions are not accepted.", "invalid_origin");
}
export async function readJson(request: Request, maxBytes = 16000): Promise<Record<string, unknown>> {
  assertMutation(request);
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) throw new ApiError(415, "Send a JSON request.", "invalid_content_type");
  const text = await readBoundedText(request, maxBytes); let parsed: unknown;
  try { parsed = JSON.parse(text); } catch { throw new ApiError(400, "The request is not valid JSON.", "invalid_json"); }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new ApiError(400, "The request must be a JSON object.", "invalid_json");
  return parsed as Record<string, unknown>;
}
export async function readBoundedText(request: Request, limit: number) {
  const size = Number(request.headers.get("content-length"));
  if (Number.isFinite(size) && size > limit) throw new ApiError(413, "The request is too large.", "request_too_large");
  const reader = request.body?.getReader(); if (!reader) return "";
  let length = 0; const chunks: Uint8Array[] = [];
  while (true) { const { value, done } = await reader.read(); if (done) break; length += value.length; if (length > limit) { await reader.cancel(); throw new ApiError(413, "The request is too large.", "request_too_large"); } chunks.push(value); }
  const combined = new Uint8Array(length); let cursor = 0;
  for (const chunk of chunks) { combined.set(chunk, cursor); cursor += chunk.length; }
  return new TextDecoder().decode(combined);
}
export function textValue(value: unknown, name: string, max = 100) {
  if (typeof value !== "string" || !value.trim() || value.trim().length > max) throw new ApiError(400, `${name} must be between 1 and ${max} characters.`, "invalid_input");
  return value.trim();
}
