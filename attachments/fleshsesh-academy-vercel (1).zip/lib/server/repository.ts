import { ApiError, database, isDemoUserId, isPilot, POLICY_VERSION, settings } from "./runtime";
import { canAccessModule, certificateEligibility, calculateXp, membership, type Assessment, type Entitlement } from "./pure";
import { modules, lessons, rules } from "./content";

export type Profile = { userId: string; displayName: string; weeklyGoal: number; acceptedVersion: string; adultConfirmedAt: string; educationAcknowledgedAt: string; orientationCompletedAt: string | null; externalAiConsentAt: string | null; activeAssessmentId: string | null; tutorCredits: number; createdAt: string; updatedAt: string };
export type ProgressRow = { lessonId: string; completedAt: string };
export type ResultRow = { assessmentId: string; bestScore: number; total: number; passedAt: string | null; lastAttemptAt: string };
export type CertificateRow = { id: string; displayName: string; courseVersion: string; issuedAt: string };
export type BillingRow = { customerId: string; subscriptionId: string | null; subscriptionStatus: string | null; cancelAtPeriodEnd: number; periodEnd: string | null };
const PROFILE_FIELDS = `user_id AS userId, display_name AS displayName, weekly_goal AS weeklyGoal, accepted_version AS acceptedVersion, adult_confirmed_at AS adultConfirmedAt, education_acknowledged_at AS educationAcknowledgedAt, orientation_completed_at AS orientationCompletedAt, external_ai_consent_at AS externalAiConsentAt, active_assessment_id AS activeAssessmentId, tutor_credits AS tutorCredits, created_at AS createdAt, updated_at AS updatedAt`;
export async function getProfile(userId: string) { return database().prepare(`SELECT ${PROFILE_FIELDS} FROM profiles WHERE user_id = ?`).bind(userId).first<Profile>(); }
export async function requireProfile(userId: string) {
  const profile = await getProfile(userId);
  if (!profile) throw new ApiError(403, "Complete your adult learner welcome before starting.", "onboarding_required");
  if (profile.acceptedVersion !== POLICY_VERSION) throw new ApiError(403, "Please review the updated learner agreement.", "agreement_required");
  return profile;
}
export async function getEntitlements(userId: string) {
  const result = await database().prepare("SELECT key, active, expires_at AS expiresAt, source_id AS sourceId FROM entitlements WHERE user_id = ?").bind(userId).all<Entitlement & { sourceId: string }>();
  return result.results;
}
export async function getBilling(userId: string) { return database().prepare("SELECT customer_id AS customerId, subscription_id AS subscriptionId, subscription_status AS subscriptionStatus, cancel_at_period_end AS cancelAtPeriodEnd, period_end AS periodEnd FROM billing_customers WHERE user_id = ?").bind(userId).first<BillingRow>(); }
export async function requireModuleAccess(userId: string, moduleId: string) {
  if (!canAccessModule(moduleId, await getEntitlements(userId), isPilot())) throw new ApiError(402, "This module is included with Academy membership or an individual module pass.", "membership_required");
}
export function checkoutAvailable() {
  const e = settings();
  return !isPilot() && e.PROCESSOR_APPROVED === "true" && e.RELEASE_APPROVED === "true" && Boolean(e.STRIPE_SECRET_KEY && e.STRIPE_WEBHOOK_SECRET && e.APP_ORIGIN);
}
export function aiAvailable() { const e = settings(); return e.AI_RELEASE_APPROVED === "true" && (isPilot() || e.RELEASE_APPROVED === "true") && Boolean(e.OPENAI_API_KEY && e.OPENAI_MODEL); }
export function tutorLimit(tier: string) { return tier === "plus" ? 200 : tier === "academy" ? 50 : 0; }
export function monthBucket() { return new Date().toISOString().slice(0, 7); }
export async function getProgress(userId: string) {
  const db = database();
  const [lessonRows, assessmentRows] = await Promise.all([
    db.prepare("SELECT lesson_id AS lessonId, completed_at AS completedAt FROM lesson_progress WHERE user_id = ? ORDER BY completed_at").bind(userId).all<ProgressRow>(),
    db.prepare("SELECT assessment_id AS assessmentId, best_score AS bestScore, total, passed_at AS passedAt, last_attempt_at AS lastAttemptAt FROM assessment_results WHERE user_id = ?").bind(userId).all<ResultRow>(),
  ]);
  const completedLessonIds = lessonRows.results.map((item) => item.lessonId).filter((id) => lessons.some((lesson) => lesson.id === id));
  const passedAssessmentIds = assessmentRows.results.filter((item) => item.passedAt).map((item) => item.assessmentId);
  const xp = calculateXp(completedLessonIds, passedAssessmentIds);
  const thisWeek = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const weeklyCompleted = lessonRows.results.filter((item) => new Date(item.completedAt).getTime() >= thisWeek).length;
  const coreCompleted = completedLessonIds.filter((id) => rules.coreLessonIds.includes(id)).length;
  const badges = [
    ...(completedLessonIds.length ? [{ id: "first-step", title: "First step", description: "Completed your first lesson." }] : []),
    ...(passedAssessmentIds.includes("C01-TEST") ? [{ id: "consent-champion", title: "Consent foundations", description: "Passed Consent and autonomy." }] : []),
    ...(completedLessonIds.length >= 10 ? [{ id: "curious-mind", title: "Curious mind", description: "Completed ten lessons." }] : []),
    ...(rules.coreAssessmentIds.every((id) => passedAssessmentIds.includes(id)) ? [{ id: "foundations", title: "Foundations complete", description: "Passed all twelve core module checks." }] : []),
    ...(passedAssessmentIds.includes("CAP01") && passedAssessmentIds.includes("PLAN01") ? [{ id: "informed-choices", title: "Informed choices", description: "Passed the capstone and applied planning assessment." }] : []),
  ];
  return { completedLessonIds, passedAssessmentIds, xp, level: Math.floor(xp / 300) + 1, nextLevelXp: (Math.floor(xp / 300) + 1) * 300, weeklyCompleted, coreCompleted, coreTotal: rules.coreLessonIds.length, completionPercent: Math.round(coreCompleted / rules.coreLessonIds.length * 100), completedLessons: lessonRows.results, assessmentResults: assessmentRows.results, badges };
}
export async function getCertificate(userId: string) { return database().prepare("SELECT id, display_name AS displayName, course_version AS courseVersion, issued_at AS issuedAt FROM certificates WHERE user_id = ?").bind(userId).first<CertificateRow>(); }
export async function accountSnapshot(userId: string) {
  const [profile, progress, entitlements, billing, certificate, usage] = await Promise.all([
    getProfile(userId), getProgress(userId), getEntitlements(userId), getBilling(userId), getCertificate(userId),
    database().prepare("SELECT count FROM tutor_usage WHERE user_id = ? AND bucket = ?").bind(userId, monthBucket()).first<{ count: number }>(),
  ]);
  const tier = membership(entitlements);
  const demo = isDemoUserId(userId);
  return {
    profile,
    progress: { ...progress, orientationCompleted: Boolean(profile?.orientationCompletedAt) },
    billing: { mode: demo ? "demo" : isPilot() ? "pilot" : "live", tier, checkoutAvailable: !demo && checkoutAvailable(), hasCustomer: !demo && Boolean(billing), subscriptionStatus: demo ? null : billing?.subscriptionStatus ?? null, cancelAtPeriodEnd: !demo && Boolean(billing?.cancelAtPeriodEnd), periodEnd: demo ? null : billing?.periodEnd ?? null, entitlements: entitlements.map(({ key, expiresAt, active }) => ({ key, expiresAt, active: Boolean(active) })) },
    tutor: { mode: !demo && aiAvailable() ? "ai" : "lesson-guide", monthlyLimit: tutorLimit(tier), monthlyUsed: usage?.count ?? 0, extraQuestions: profile?.tutorCredits ?? 0, externalProcessingConsent: !demo && Boolean(profile?.externalAiConsentAt), bucket: monthBucket() },
    certificate: { ...certificateEligibility({ orientationCompleted: Boolean(profile?.orientationCompletedAt), completedLessonIds: progress.completedLessonIds, passedAssessmentIds: progress.passedAssessmentIds }, rules), issued: demo ? null : certificate, accreditation: demo ? "Demonstration only — no certificate is issued" : "Non-accredited certificate of completion", ...(demo ? { demoOnly: true, sampleUrl: "/api/demo/certificate" } : {}) },
  };
}
export async function requireAssessmentAccess(userId: string, assessment: Assessment) {
  const profile = await requireProfile(userId);
  if (!profile.orientationCompletedAt) throw new ApiError(403, "Complete the welcome orientation first.", "orientation_required");
  if (assessment.moduleId) await requireModuleAccess(userId, assessment.moduleId);
  const progress = await getProgress(userId);
  let requiredLessonIds: string[] = [];
  if (assessment.kind.endsWith("_module")) requiredLessonIds = modules.find((module) => module.id === assessment.moduleId)?.lessons.map((lesson) => lesson.id) ?? [];
  if (assessment.kind === "capstone" || assessment.kind === "applied_planning") {
    requiredLessonIds = rules.coreLessonIds;
    const missingModules = rules.coreAssessmentIds.filter((id) => !progress.passedAssessmentIds.includes(id));
    if (missingModules.length) throw new ApiError(403, "Pass all twelve core module checks before the final assessment.", "prerequisites_required");
  }
  if (requiredLessonIds.some((id) => !progress.completedLessonIds.includes(id))) throw new ApiError(403, "Complete the lessons in this module before its assessment.", "prerequisites_required");
  return progress;
}
