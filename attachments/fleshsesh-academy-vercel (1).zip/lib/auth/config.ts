import "server-only";

/** Server-side configuration check. Never return either key to a browser. */
export function hasClerkConfiguration(): boolean {
  return Boolean(
    process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY?.trim() &&
    process.env.CLERK_SECRET_KEY?.trim(),
  );
}
