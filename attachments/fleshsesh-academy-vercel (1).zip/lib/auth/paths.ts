const LOCAL_ORIGIN = "https://academy.invalid";
const DESTINATIONS = new Set([
  "", "library", "courses", "pricing", "about", "privacy", "terms", "support",
  "demo", "resources", "dashboard", "onboarding", "learn", "assessment", "tutor",
  "progress", "account", "business",
]);
type Fallback = "/" | "/dashboard" | "/onboarding";
export type AuthSearchParams = Record<string, string | string[] | undefined>;
export type AuthPageProps = { searchParams: Promise<AuthSearchParams> };

/** Only local Academy content is a valid post-auth destination. */
export function safeRelativeReturnPath(value: unknown, fallback: Fallback = "/"): string {
  if (typeof value !== "string" || value.length > 2048 || value !== value.trim()) return fallback;
  if (!value.startsWith("/") || value.startsWith("//") || /[\\\u0000-\u0020\u007f]/.test(value)) return fallback;
  try {
    const decoded = decodeURIComponent(value);
    if (decoded.startsWith("//") || /[\\\u0000-\u001f\u007f]/.test(decoded)) return fallback;
    const url = new URL(value, LOCAL_ORIGIN);
    const pathname = decodeURIComponent(url.pathname);
    if (url.origin !== LOCAL_ORIGIN || pathname.startsWith("//") || /[\\%]/.test(pathname)) return fallback;
    // Excludes API endpoints and auth/redirect routes, including their subpaths.
    const section = pathname.split("/")[1];
    if (!DESTINATIONS.has(section)) return fallback;
    return `${url.pathname}${url.search}${url.hash}`;
  } catch {
    return fallback;
  }
}

export function signInPath(returnTo: unknown = "/dashboard"): string {
  return `/sign-in?return_to=${encodeURIComponent(safeRelativeReturnPath(returnTo, "/dashboard"))}`;
}
export function signUpPath(returnTo: unknown = "/onboarding"): string {
  return `/sign-up?return_to=${encodeURIComponent(safeRelativeReturnPath(returnTo, "/onboarding"))}`;
}
export function signOutPath(returnTo: unknown = "/"): string {
  return `/sign-out?return_to=${encodeURIComponent(safeRelativeReturnPath(returnTo))}`;
}
