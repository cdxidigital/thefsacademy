import { drizzle } from "drizzle-orm/libsql";
import { configuredClient } from "../lib/server/database";
import * as schema from "./schema";

export function getDb() {
  const client = configuredClient();
  if (!client) throw new Error("Database storage is not configured. Set TURSO_DATABASE_URL and TURSO_AUTH_TOKEN.");
  return drizzle(client, { schema });
}
