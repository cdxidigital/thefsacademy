import { integer, primaryKey, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const profiles = sqliteTable("profiles", {
  userId: text("user_id").primaryKey(),
  displayName: text("display_name").notNull(),
  weeklyGoal: integer("weekly_goal").notNull().default(3),
  acceptedVersion: text("accepted_version").notNull(),
  adultConfirmedAt: text("adult_confirmed_at").notNull(),
  educationAcknowledgedAt: text("education_acknowledged_at").notNull(),
  orientationCompletedAt: text("orientation_completed_at"),
  externalAiConsentAt: text("external_ai_consent_at"),
  activeAssessmentId: text("active_assessment_id"),
  tutorCredits: integer("tutor_credits").notNull().default(0),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});
// Demo learners have their own records. The native account owns the session,
// but is never granted a paid entitlement by entering the demonstration.
export const demoSessions = sqliteTable("demo_sessions", {
  tokenHash: text("token_hash").primaryKey(),
  ownerUserId: text("owner_user_id").notNull(),
  demoUserId: text("demo_user_id").notNull().references(() => profiles.userId, { onDelete: "cascade" }),
  createdAt: text("created_at").notNull(),
  expiresAt: text("expires_at").notNull(),
}, (t) => [uniqueIndex("demo_owner_unique").on(t.ownerUserId), uniqueIndex("demo_learner_unique").on(t.demoUserId)]);
export const lessonProgress = sqliteTable("lesson_progress", {
  userId: text("user_id").notNull().references(() => profiles.userId, { onDelete: "cascade" }),
  lessonId: text("lesson_id").notNull(),
  completedAt: text("completed_at").notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.lessonId] })]);
export const assessmentAttempts = sqliteTable("assessment_attempts", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => profiles.userId, { onDelete: "cascade" }),
  assessmentId: text("assessment_id").notNull(),
  score: integer("score").notNull(),
  total: integer("total").notNull(),
  passed: integer("passed", { mode: "boolean" }).notNull(),
  criticalPassed: integer("critical_passed", { mode: "boolean" }).notNull(),
  createdAt: text("created_at").notNull(),
});
export const assessmentResults = sqliteTable("assessment_results", {
  userId: text("user_id").notNull().references(() => profiles.userId, { onDelete: "cascade" }),
  assessmentId: text("assessment_id").notNull(),
  bestScore: integer("best_score").notNull(),
  total: integer("total").notNull(),
  passedAt: text("passed_at"),
  lastAttemptAt: text("last_attempt_at").notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.assessmentId] })]);
export const entitlements = sqliteTable("entitlements", {
  userId: text("user_id").notNull().references(() => profiles.userId, { onDelete: "cascade" }),
  key: text("key").notNull(),
  sourceId: text("source_id").notNull(),
  expiresAt: text("expires_at"),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  updatedAt: text("updated_at").notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.key, t.sourceId] })]);
export const billingCustomers = sqliteTable("billing_customers", {
  userId: text("user_id").primaryKey().references(() => profiles.userId, { onDelete: "cascade" }),
  customerId: text("customer_id").notNull(),
  subscriptionId: text("subscription_id"),
  subscriptionStatus: text("subscription_status"),
  cancelAtPeriodEnd: integer("cancel_at_period_end", { mode: "boolean" }).notNull().default(false),
  periodEnd: text("period_end"),
  updatedAt: text("updated_at").notNull(),
}, (t) => [uniqueIndex("billing_customer_unique").on(t.customerId)]);
export const paymentEvents = sqliteTable("payment_events", {
  id: text("id").primaryKey(),
  type: text("type").notNull(),
  createdAt: text("created_at").notNull(),
});
export const tutorUsage = sqliteTable("tutor_usage", {
  userId: text("user_id").notNull().references(() => profiles.userId, { onDelete: "cascade" }),
  bucket: text("bucket").notNull(),
  count: integer("count").notNull().default(0),
}, (t) => [primaryKey({ columns: [t.userId, t.bucket] })]);
export const certificates = sqliteTable("certificates", {
  userId: text("user_id").primaryKey().references(() => profiles.userId, { onDelete: "cascade" }),
  id: text("id").notNull(),
  displayName: text("display_name").notNull(),
  courseVersion: text("course_version").notNull(),
  issuedAt: text("issued_at").notNull(),
}, (t) => [uniqueIndex("certificate_id_unique").on(t.id)]);
